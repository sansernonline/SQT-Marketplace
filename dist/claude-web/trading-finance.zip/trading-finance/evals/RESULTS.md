# ผล eval ของ trading-finance

## 2026-10-28 · เตรียมรอบถัดไป (ยังไม่ได้รัน)

- ทุกเคสติดป้าย `capability` (วัดว่า skill ช่วยได้ไหม) หรือ `regression` (กันอาการที่เคยพลาดกลับมา) ใน `tags`
- เคสละ 3 รอบแยกผลไม่ได้: ผ่าน 1/3 กับ 3/3 ช่วงความเชื่อมั่น 95% ยังทับกัน · เคสที่จะใช้ตัดสินแก้ skill ให้รัน 10 รอบขึ้นไป และรายงาน pass^3 (ผ่านครบ 3 รอบติด) คู่กับค่าเฉลี่ย
- ผู้ตัดสิน haiku ยังไม่เคยเทียบกับคน · รอบหน้าสุ่ม 10 คำตอบให้คนให้คะแนน แล้วจดอัตราที่ตรงกันไว้ที่นี่ · เกณฑ์ `llm` ที่แก้หลังเห็นผล (0.13.2) ต้องเทียบใหม่
- 7 เคสยังไม่มีผลบันทึก: `copy-trade-check` ×3 · `position-sizing-behaviour` · `scam-check-guard` · `tax-deduction-planner` ×2
- เพิ่ม 8 เคสใหม่ (ยังไม่ได้รัน): ฝั่ง "ไม่ควรเปิด" 2 เคส · `tax-basics-th` · `debt-payoff` · `retirement-plan` ตัวละ 2 · เคส behaviour ที่มีสคริปต์ตรวจ `tool_used` Bash ว่ารันสคริปต์จริง

## 2026-10-26 · skill ใหม่ 4 ตัว · Claude Code 2.1.310 · เคสละ 3 รอบ · ผู้ตัดสิน haiku · 6.23 ดอลลาร์

รันที่สำเนาที่ลบ `dependencies` ออก เพราะ eval โหลด plugin ที่มี dependency ไม่ขึ้น (`skill-authoring` `eval-format.md`) · skill กลางของ superuser จึงไม่อยู่ในรอบนี้ · คะแนนคือ 0–1 ของ grader ที่นับคะแนน

| เคส | มี skill | ไม่มี skill | ต่าง | อ่านผล |
|---|---|---|---|---|
| `bonds-and-deposits-trigger` | 0.67 | 1.00 | -0.33 | skill เปิด 3/3 แต่เกณฑ์เทียบความเสี่ยงผ่านแค่ 1/3 ส่วนรอบไม่มี skill ผ่าน 3/3 · ต้องดูว่า skill ทำให้คำตอบแคบลงไหม |
| `bonds-and-deposits-behaviour` | 1.00 | 0.83 | +0.17 | |
| `credit-bureau-trigger` | 1.00 | 1.00 | 0 | skill เปิด 3/3 |
| `credit-bureau-behaviour` | 1.00 | 0.50 | +0.50 | ไม่มี skill พลาดข้อเท็จจริงและเรื่องรับลบประวัติทั้ง 3 รอบ |
| `home-refinance-trigger` | 0.50 | 0.50 | 0 | เกณฑ์เทียบค่าธรรมเนียมผ่าน 0/3 ทั้ง 2 รอบ เกณฑ์อาจเข้มเกิน |
| `home-refinance-behaviour` | 1.00 | 0.50 | +0.50 | ไม่มี skill ไม่คิดค่าปรับและไม่เทียบรีเทนชั่นทั้ง 3 รอบ |
| `rebalance-and-dca-trigger` | 1.00 | 1.00 | 0 | skill เปิด 3/3 |
| `rebalance-and-dca-behaviour` | 0.50 | 0.50 | 0 | เกณฑ์ RMF ผ่าน 0/3 ทั้ง 2 รอบ เกณฑ์อาจเข้มเกิน |

## ยังไม่ได้รันรอบแดง/เขียว (2026-11-10)

skill ใหม่ด้านล่างมีเคสครบ 3 ชุดแล้ว แต่**ยังไม่ได้รันรอบแดง/เขียว** ตาม `skill-authoring` · รอผู้ใช้อนุมัติค่า eval ก่อนรัน · ใช้ `-guard` ไม่ใช่ `-regression` เพราะยังไม่เคยเห็นอาการพลาดจริง

| skill | เคสที่มี | สถานะ | คำสั่งเมื่ออนุมัติ |
|---|---|---|---|
| `stock-fundamentals` | `-trigger` · `-behaviour` · `-guard` | ยังไม่ได้รัน | `node scripts/evals/plugin-eval.mjs trading-finance --only "^stock-fundamentals-" --max-cost-usd 5` |
