---
name: portfolio
description: Show the portfolio snapshot — allocation, P/L, concentration flags, top contributors — at current prices.
argument-hint: '[--file <path>]'
disable-model-invocation: true
---

Run the `portfolio-snapshot` skill: **$ARGUMENTS**

If no portfolio file is known, ask where holdings are tracked. Mark stale prices honestly when a data plugin is missing for a market.
