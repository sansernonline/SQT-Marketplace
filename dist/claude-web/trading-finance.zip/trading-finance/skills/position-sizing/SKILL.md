---
name: position-sizing
description: Use before a trade to set share size and stop placement
---

# Position Sizing (คำนวณขนาดไม้)

Size every trade from risk, not from conviction. General information, not investment advice.

## The formula — fixed-fractional

```
risk budget (บาท)   = capital × risk%            (default 1%, max 2%; higher only if the user writes it in CONTEXT.md)
risk per share      = |entry − stop|              (+ round-trip cost per share)
raw size (shares)   = risk budget ÷ risk per share
size                = round DOWN to the board lot (100 shares on SET)
position value      = size × entry
```

If there is no stop, stop and ask for one — no sizing without a stop. Get the stop from the invalidation price in `technical-signals`.

Forex, CFDs (gold, indices), crypto or a prop-firm account → lots, pip value, margin, swap and daily loss limits are in [references/forex-cfd-crypto.md](references/forex-cfd-crypto.md). The rest of this file is SET shares.

## SET trading rules that change the answer

| Rule | Value |
|---|---|
| Board lot (ล็อต) | **100 shares**; 50 shares for a stock priced ≥ 500 baht for 6 consecutive months. Fewer shares trade on the odd-lot board (worse liquidity) |
| Daily price limit (ceiling/floor) | ±30% of previous close |
| Settlement | T+2 |
| ETFs / unit trusts tick | 0.01 baht at every price |

Tick size (ช่วงราคา) for SET/mai shares, in force from 16 Nov 2569 (2026) · SET cancels every order carried over from earlier days before Pre-open that day:

| Price (baht) | < 2 | 2–<5 | 5–<10 | 10–<25 | 25–<50 | 50–<100 | 100–<200 | 200–<400 | ≥ 400 |
|---|---|---|---|---|---|---|---|---|---|
| Tick | 0.01 | 0.02 | 0.02 | 0.05 | 0.10 | 0.25 | 0.50 | 1.00 | 2.00 |

Source: SET circular ปก.(ว) 4/2569 (15 Oct 2026, checked 2026-11-12) https://media.set.or.th/rulebook/circular-letter/attachment-file/379.pdf (unofficial English translation; Thai original not read) · SET tick page https://www.set.or.th/en/trading-units-tick-sizes-price-limits · SET changes ticks rarely (the SET tick page dated the previous table 30 Mar 2009), so check the SET page only when a user says the tick changed or a broker rejects a price, then update this table and `scripts/ticks.json` together.

Why ticks matter: stop and entry must sit on a valid tick, and on a 9.90-baht stock one tick (0.02) is 0.2% — a "1-tick" stop is not a real stop.

## Workflow

1. Collect: capital in the trading account (not net worth), risk % (default 1%), entry, stop, and the user's broker commission (typical internet rate around 0.15–0.25% + 7% VAT on commission (รอยืนยัน — use the user's own broker statement)).
2. Snap entry and stop to valid ticks; put the stop just beyond the invalidation level, not on it.
3. Compute risk budget, risk per share (add round-trip cost per share), raw size, round down to 100.
4. **Sanity checks**
   - Concentration: position ≤ 10% of capital by default (≤ 20% for an ETF). If larger, reduce size — never widen the risk %.
   - Liquidity: position ≤ 5% of the stock's average daily value traded, so it can be exited in a day.
   - Gap risk: if the stock can gap past the stop (earnings, XD, news), assume the loss could be 1.5–2× planned.
   - Total open risk across all positions ≤ 5–6% of capital.
5. If rounding to 100 shares makes the risk exceed the budget, round down again; if size becomes 0, the stop is too wide for this account — skip the trade.

## Script

`size.mjs` does the arithmetic so the number is not worked out in the model's head: risk budget, risk per share (with cost), raw size, round down to the board lot, then the concentration cap (10% of capital, 20% for an ETF) and the liquidity cap (5% of average daily value, only when `avgDailyValue` is given). It reports which rule bound the size. Entry and stop must sit on a valid tick from `scripts/ticks.json` (the table above, with `checked` and `source`); an off-tick price stops the script.

```
node size.mjs <file.json> [--json]     # example file: scripts/example.json
node size.mjs --self-test
```

Input file: `{ "type": "share", "capital": 100000, "riskPct": 1, "entry": 48.5, "stop": 47.5, "costPerShare": 0.19 }` · `type` is `share` (default), `etf` (tick 0.01), `crypto` (needs `lot` = coin step, no tick check) or `forex` (`stopPips`, `pipValuePerLot`, `costPerLot`, `volumeStep`; formula in [references/forex-cfd-crypto.md](references/forex-cfd-crypto.md)). Optional: `lot` (default 100), `maxPositionPct`, `avgDailyValue`. Every number must be finite; a bad field stops the script with a message naming it. **No stop = the script stops** — it never sizes without one. A `riskPct` above 2 stops the script unless `riskPctApprovedBy` says where the user set it (for example `"CONTEXT.md 2026-10-28"`). Optional what-ifs that never change the size: `gapMultiplier` (1.5–2 when the price can gap past the stop) prints the gap loss · `openRiskPct` (risk already open, % of capital) prints total open risk and warns above 6% · forex `price` + `leverage` (+ `contractSize`, default 100,000) prints margin. Size 0 means the stop is too wide for the account: skip the trade.

**Script path:** installed from the marketplace: `ls -d ~/.claude/plugins/cache/*/trading-finance/*/skills/position-sizing/scripts/size.mjs | sort -V | tail -1` · in the SQT-Marketplace repo: `plugins/trading-finance/skills/position-sizing/scripts/size.mjs` · Node only, no dependencies.

## Why the risk % stays small — drawdown and the way back

Gain needed = drawdown ÷ (1 − drawdown): a 10% loss needs 11.1% back, 50% needs 100%. At 1% risk, 10 losses in a row cost about 9.6% (compounded) and need 10.6% back; at 5% risk the same streak costs 40% and needs 66.7%. Show the full table in [references/drawdown-recovery.md](references/drawdown-recovery.md) when a user asks to raise the risk %. (Arithmetic, computed here; no external source.)

## Worked example

Capital 100,000 baht, risk 1% = **1,000 baht**. Entry 48.50, invalidation 48.00 → stop 0.50 below at **47.50** (on the 0.10 tick). Risk per share = 1.00. Round-trip cost ≈ 0.2% × 2 × 48.50 ≈ 0.19 → use **1.19**.

- Raw size = 1,000 ÷ 1.19 = 840 → round down to board lot = **800 shares**
- Position value = 800 × 48.50 = **38,800 baht = 38.8% of capital** → fails the 10% concentration check
- Cap at 10% → 10,000 ÷ 48.50 = 206 → **200 shares** (9,700 baht); real risk = 200 × 1.19 = **238 baht (0.24%)**

Size if the user takes the trade: 200 shares, stop 47.50; the concentration limit, not the stop, is the binding rule here. A wider stop at 45.50 (below the 46.00 swing low) would give risk 3.19/share → 313 → 300 shares, but still capped at 200 by concentration.

## Output

Risk budget · risk per share (with cost) · size in shares and baht · % of capital · which rule bound the size (risk, concentration, liquidity) · the one assumption that would change the answer. No sizing without a stop-loss.

Related: `risk-manager` agent applies these limits; log the planned size in `trade-journal`.
