---
name: watchlist-setup
description: Use when starting to follow new stocks or rebuilding a messy watchlist. Thesis, entry, alerts.
argument-hint: <add|review|clean> [symbol or notes]
---

# Watchlist Setup (รายชื่อหุ้นที่จับตา)

Turn "I want to watch some stocks" into a short list where every name has a reason. Template: [references/watchlist-template.md](references/watchlist-template.md). General information, not investment advice.

## Workflow

1. **Context** — capital, horizon (day / swing weeks / long-term years), markets reachable (SET, mai, SET-listed DRs (Depositary Receipts) for foreign stocks, offshore via broker), and whether dividends or growth matter more.
2. **Limit the list** — max **10 names** (swing) or **15** (long-term). More means none get real attention. When the list is over the limit, score the names (section "Scoring when over the limit" below) and cut from the bottom.
3. **Per symbol record**
   - ticker, market, sector, as-of date of every number
   - **thesis** — one falsifiable sentence ("EPS growing 20%+ two quarters in a row while P/E is below its 5-year average"). Numbers for it (P/E, ROE, D/E, payout) come from `stock-fundamentals`
   - **long-term names also get pillars** — the 2–3 facts the thesis stands on (each one checkable in a filing) and the 2–3 risks that would break it, kept in a thesis file next to the watchlist (section "Thesis pillars" below)
   - **trigger / entry zone** — price zone or event that makes it actionable
   - **invalidation** — price or event that kills the thesis (from `technical-signals` for levels)
   - **liquidity** — 20-day average daily value traded; flag if under ~5 million baht (wide spreads, hard to exit)
   - **calendar** — next earnings (quarterly results due within 45 days of quarter end; annual audited results within 2 months, or 3 months if a reviewed Q4 statement is filed), XD date, AGM
   - **alerts** — price above/below, % move, volume spike — set in the broker app (Streaming, Settrade) or via the `alert-dispatcher` agent
4. **Check SET market signs** on each name before adding: the C signs `CB` `CS` `CC` `CF` (caution; there is no plain `C`), `SP` (suspended), `H` (halt), `NP` / `NR` (notice pending / received), and whether it is on the SET market surveillance lists (Cash Balance, Turnover List). A name under trading measures needs a cash account and is a red flag for a beginner.

ตรวจล่าสุด 2026-10-26 · แหล่ง: เครื่องหมาย https://www.set.or.th/en/market/information/trading-procedure/trading-signs , https://www.set.or.th/en/listing/listed-company/simplified-regulations/disclosure/c-sign-posting , https://media.set.or.th/rulebook/circular-letter/attachment-file/237.pdf · กำหนดส่งงบ https://www.set.or.th/en/listing/listed-company/simplified-regulations/disclosure/periodic-disclosure , https://www.sec.or.th/TH/Documents/Report56/FAQ-FinancialStatement-issuer.pdf , https://publish.sec.or.th/nrs/10198s.pdf
5. **Save** as `watchlist.md` (or `.csv`) in the finance folder; date the file.

## Scoring when over the limit

Use `decision-scoring`, command `score`, on the names that pass the hard rules. Script path: see `decision-scoring` (superuser plugin).

| Step | Value |
|---|---|
| Hard rules (`must`) | A one-sentence thesis is written · 20-day liquidity at least 5 million baht a day (the figure in the liquidity step) · no SP or H sign (trading halted) |
| Criterion 1 | Reward to risk = (target − entry) ÷ (entry − price where the thesis breaks) · `high` · proposed weight 0.35 |
| Criterion 2 | Conviction in the thesis, 1–5 (given by the user) · `high` · 0.25 |
| Criterion 3 | Distance from the current price to the entry zone, % · `low` · 0.20 |
| Criterion 4 | 20-day average traded value, million baht · `high` · 0.20 |

Weights are starting values the user can change (starting value, not yet measured). Drop the lowest scores until the list is at the cap (10 or 15). If the cut line reads `ยังไม่นิ่ง` (not stable) or `สูสี` (too close), the user chooses which name goes.

## Thesis pillars — long-term names

A one-line thesis is enough for a swing trade. A name held for years needs a record that shows, quarter by quarter, whether the reasons still hold. Template: "Thesis file" in [references/watchlist-template.md](references/watchlist-template.md).

1. **Pillars** — 2–3 facts the thesis needs, each tied to a number in a filing ("same-store sales growth positive", "net debt ÷ EBITDA below 2"). If a pillar cannot be checked in a filing, rewrite it.
2. **Break risks** — 2–3 things that would end it ("a new competitor takes the anchor tenant", "dividend cut").
3. **Update log** — every time new information arrives (results, a filing, a news item from `news-impact`): date · what is new · which pillar it touches · supports / weakens / neutral · conviction high / medium / low after it.
4. **Record evidence against as carefully as evidence for.** A log that only ever says "supports" is a log of what the user wanted to read.
5. **Review each long-term thesis at least once a quarter, even with no news** — usually right after the quarterly results (`news-impact` results day). Two pillars weakened, or one break risk happened, goes to the decision table below as "thesis invalidated".

No target price, no "upside", no buy or sell rating: the file records whether the reasons hold, the decision stays with the user.

Idea: `thesis-tracker` in anthropics/financial-services equity-research (Apache-2.0, viewed 2026-11-10), with the institutional parts (short ideas, price targets) left out.

## Decision table — add, keep or drop

| Situation | Action |
|---|---|
| No written thesis | Do not add; if already listed, delete at next review |
| Thesis invalidated (level broke or event happened) | Drop now — no "wait and see" |
| Entry zone hit, thesis intact | Move to the decision step: `position-sizing` then `trade-journal` |
| Nothing happened for 3 months | Re-read the thesis; keep it if still valid, otherwise drop |
| Added because "it moved a lot today" | Not allowed — that is chasing, not watching |
| Under Cash Balance / caution sign | Long-term list only, with a note why |

## Rules

- Review the full list **monthly** (`/trading-finance:watchlist-setup review`); dead theses go out with no attachment.
- One line per name in reviews — if it needs a paragraph, the thesis is not clear.
- Data from whatever market-data plugin is installed; if none, say so and use free public pages (set.or.th company pages), always with the as-of date.

## Worked example (illustrative)

User: swing trader, 200,000 baht, SET only. Adds ABC.

| Field | Value |
|---|---|
| Ticker / market / sector | ABC · SET · Commerce |
| Thesis | Same-store sales growth turned positive for 2 quarters; price still in a 6-month range 44–48 |
| Entry zone | Daily close above 48.00 on volume ≥ 1.5× 20-day average |
| Invalidation | Close below 44.00, or next quarter same-store sales negative |
| Liquidity | ~60 million baht/day — fine |
| Calendar | Q3 results expected by mid-November; no XD this quarter |
| Alerts | price ≥ 48.00 · price ≤ 44.00 · volume ≥ 2× average |
| As of | 2026-10-06 |

Command: `/trading-finance:watchlist-setup add|review|clean`. Next steps: read the chart with `technical-signals`, size with `position-sizing`.

## เรียกเป็นคำสั่ง

`/trading-finance:watchlist-setup <add|review|clean> [symbol or notes]`

Manage the watchlist with the `watchlist-setup` skill: **$ARGUMENTS**

- `add` — ask for thesis, entry zone, invalidation; append to the watchlist
- `review` — re-check every thesis against current data, kill dead ones
- `clean` — delete names without a written thesis (default max 10 symbols)

Always refresh data through installed market-data plugins and date every figure.
