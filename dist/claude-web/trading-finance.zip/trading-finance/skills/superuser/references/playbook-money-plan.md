# playbook · money-plan — personal financial plan

Use when: making a monthly budget · emergency fund · paying off debt · retirement planning · reviewing insurance · choosing funds.
Main skill: `personal-budget` · `emergency-fund` · `debt-payoff` · `retirement-plan` · `insurance-review` · `mutual-fund-picker`

## ขั้นตอน (Steps — copy into the todo as written)

1. Collect real numbers — income, spending from statements, debts, insurance, savings. Put `(รอยืนยัน)` (pending confirmation) on any that is missing · ใคร: หัวหน้าทีม
2. Work in this order: monthly budget → emergency fund → high-interest debt → retirement and investing · ใคร: `money-planner` ตัวใหม่
3. Use each topic's skill, and ตรวจ the current year's rates and rules against official sources · ใคร: `money-planner` ตัวใหม่
4. Show the numbers for every option side by side, and do not point to which way to choose · ใคร: `money-planner` ตัวใหม่ builds the comparison table, then the user chooses
5. ตรวจ that the calculation formulas can be rerun and that total income and spending match the statements · ใคร: `reviewer` ตัวใหม่

## Done when

The plan is a table that has been recalculated, every rate has a source, and the options come with numbers for the user to decide on their own.
