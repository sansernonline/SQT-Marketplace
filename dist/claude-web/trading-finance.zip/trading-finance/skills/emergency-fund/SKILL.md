---
name: emergency-fund
description: Use when sizing an emergency fund or where to keep it
---

# Emergency Fund (เงินสำรองฉุกเฉิน)

General information, not financial advice.

## How many months

Months × **essential** monthly spending (rent or mortgage, food, transport, utilities, insurance premiums, minimum debt payments, support for parents) — not total spending, not income.

| Situation | Months |
|---|---|
| Government officer / state enterprise, stable | 3 |
| Salaried private sector, one earner of two in the household | 3–6 |
| Salaried, sole earner with dependants | 6–9 |
| Commission, contract, gig, freelance (ม.40), seasonal income | 9–12 |
| Business owner (keep separate from business cash) | 12 |
| Paying off high-interest debt | 1-month mini buffer first, full fund after (`debt-payoff`) |

Adjust up for: health conditions, older parents depending on you, older car, single-industry town. Adjust down slightly if the employer offers strong severance and the user is ม.33 (social security unemployment benefit when laid off: 60% of the capped wage for up to 180 days per government news from 28 Jun 2568, but SSO's own page dated 3 Oct 2567 still says 50% (รอยืนยัน which rate SSO pays now); wage cap 15,000 on SSO's page, and whether the 17,500 cap from 1 Jan 2569 applies to this benefit is (รอยืนยัน); resigned or contract ended: 30% for up to 90 days. Sources and dates → `e-commerce:social-security-th` (section 2, Unemployment row, checked 2026-11-10), or ask sso.go.th or 1506. Plan the fund without counting on the higher figure).

## Where to park — the ladder

| Layer | Share | Product | Access | Protected by the Deposit Protection Agency (DPA)? |
|---|---|---|---|---|
| 1 | 1 month | normal savings account at main bank | instant | yes |
| 2 | 2–5 months | high-interest digital savings (e-savings) at a different bank | same day | yes |
| 3 | rest | money market fund (กองทุนรวมตลาดเงิน, risk level 1) or 3–6 month fixed deposit | money market: usually T+1; fixed deposit: early withdrawal loses interest | money market fund **no** (it is an investment, but holds very short deposits and bills) |

Never in stocks, crypto, long-term funds, Retirement Mutual Fund (RMF) / ThaiESG, or lent to friends.

## Deposit protection (สถาบันคุ้มครองเงินฝาก)

- Covers **up to 1,000,000 baht per depositor per bank** — all accounts and branches at that bank combined, principal plus interest. In force since 11 Aug 2564.
- Covers Thai-baht savings, current, fixed deposits and certificates of deposit at member banks. Does **not** cover mutual funds, bonds, bills of exchange (ตั๋วแลกเงิน), insurance, or co-operatives (สหกรณ์ออมทรัพย์).
- Above 1 million: split across banks. Money beyond the emergency tier (deposits vs bonds vs money market funds) → `bonds-and-deposits`.

## Workflow

1. Compute essential monthly spending from real statements (`personal-budget`).
2. Pick months from the table; target = months × essential spending.
3. Count what already qualifies (cash at bank, money market fund). Do not count RMF, stocks, or "I could borrow".
4. Close the gap with a monthly top-up from the budget, and set the date it will be full.
5. Set the ladder; name the accounts by purpose ("ฉุกเฉิน").
6. After using it, refill before resuming extra investing.

## Worked example

Freelance designer, essential spending 22,000/month, has 60,000 in savings, high-interest debt none.

| Step | Number |
|---|---|
| Target | 9 months × 22,000 = **198,000** |
| Already have | 60,000 |
| Gap | 138,000 |
| Top-up | 11,500/month → full in 12 months |
| Ladder | 22,000 savings at main bank · 88,000 e-savings at a second bank · 88,000 money market fund |

## Rules

- Interest rate is the last criterion; access and safety come first. E-savings promo rates change often — check the bank page (รอยืนยัน on any quoted rate).
- "Emergency" = job loss, medical not covered by insurance, urgent home/car repair, family crisis. A sale is not an emergency.
- The emergency fund is built before RMF/ThaiESG top-ups, except the employer PVD match, which comes first.

## References

- [`references/sources.md`](references/sources.md) — open to re-check dated figures, prices and rules, and their sources
