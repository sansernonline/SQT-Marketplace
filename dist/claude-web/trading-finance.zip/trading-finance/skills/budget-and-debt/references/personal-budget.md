<!-- merged from skill `personal-budget` on 2026-11-27 · description was: Use when salary runs out early or making a monthly budget -->
# Personal Budget (งบรายเดือน)

A budget that survives contact with real life. Worksheet: [references/budget-worksheet.md](budget-worksheet.md). General information, not financial advice.

## Workflow

1. **Real numbers, 2–3 months** — bank statement exports, e-wallet / PromptPay history (TrueMoney, ShopeePay, LINE Pay), credit card statements. Never use the user's guess of their own spending.
2. **Start from take-home pay**, not gross: salary − social security (5% of wage, capped at a 17,500 baht wage base = **875 baht/month** in 2569) − provident fund (PVD) contribution − withholding tax (ภาษีหัก ณ ที่จ่าย) per payslip. Add regular side income; treat bonus as a separate annual plan, not monthly money.
3. **Categorise** into four envelopes:
   - **Needs** — rent/home loan, utilities, food at home, transport to work, phone, insurance premiums, minimum debt payments, parents' support (ส่งเงินให้พ่อแม่ is a fixed need for many Thai households)
   - **Wants** — eating out, delivery, shopping, travel, subscriptions, gifts and social obligations (ซองงานแต่ง งานบวช งานศพ)
   - **Savings** — emergency fund until full (`emergency-fund.md`), extra debt payment above minimum (`debt-payoff.md`), annual bills sinking fund
   - **Investment** — DCA into funds/stocks, Retirement Mutual Fund (RMF) / ThaiESG (`income-tax-th`, `fund-and-bond-picker`)
4. **Flag leaks**: forgotten subscriptions, BNPL / ผ่อน 0% instalments stacking up, cash-advance fees, delivery frequency. List each with its monthly baht.
5. **Propose the split** — 50/30/20 (needs/wants/savings+investment) as a starting point; adjust to reality (high Bangkok rent may push needs to 60%). Never treat the split as sacred.
6. **The one number that matters** — the investment/saving transfer, set as a standing order on payday (บัญชีแยก, auto-transfer), before spending starts.
7. **Monthly 10-minute review** — actual vs plan per envelope, one category to fix next month. Explain only the lines that are off by **more than 10% and more than 500 baht** (both at once); the rest is noise and gets no comment. For a large line such as rent or a loan, a lower % is fine because 10% of it is already a lot of money. The 10% and 500 baht are starting values, not measured; the user may change them. (Idea: materiality thresholds in `variance-analysis`, anthropics/knowledge-work-plugins, Apache-2.0, viewed 2026-11-10.)

## Decision table

| Situation | Do first |
|---|---|
| Expenses > income | Cut wants, then renegotiate needs (phone plan, insurance overlap via `retirement-and-insurance`); never borrow to cover monthly spend |
| Credit-card or cash-card debt revolving | Savings envelope goes to `debt-payoff.md` before investment beyond the employer-matched PVD |
| No emergency fund | Fill `emergency-fund.md` first (at least 3 months of needs) before discretionary investing |
| Irregular income (freelance, commission) | Budget on the lowest month of the last 6; park the surplus in a buffer account |
| Year-end bonus | Pre-split: debt / emergency fund / tax-saving funds / one want |

## Where to park each envelope

- Spending: main account linked to the debit card / PromptPay.
- Emergency and sinking funds: separate high-interest savings account; deposit protection limit and rules: `emergency-fund.md` "Deposit protection".
- Investment: broker / fund account, auto-debited.

ตรวจล่าสุด 2026-10-26 · ประกันสังคม 5% ค่าจ้าง 1,650–17,500 สูงสุด 875 บาทต่อเดือนตั้งแต่ 1 ม.ค. 2569 (2572 เพดาน 20,000) แหล่ง: https://www.sso.go.th (ข่าวนนทบุรี 35688 · 27 ธ.ค. 2568 และหน้าบริการ 605_605) , https://www.krungsri.com/th/krungsri-the-coach/life/good-life/sso-section-33-rate-increase · คุ้มครองเงินฝาก 1 ล้านบาทต่อคนต่อสถาบัน แหล่ง: https://www.dpa.or.th/News/kar-prab-wngngein-khumkhrxng-thi-1-lan-bath , https://www.bangkokbank.com/th-TH/Personal/Grow-Club/DPA , https://www.bangkokbiznews.com/news/952780

Worked example (monthly, single, Bangkok, 2569, salary 35,000): [references/worked-example.md](worked-example.md)

## Rules

- If data is missing, estimate it with the user and mark it as an estimate.
- The goal is not a perfect spreadsheet; it is protecting the payday transfer.
- If expenses exceed income, say so plainly and cut wants first, never the investment line to zero without saying what it costs long term.

Related (same plugin): `emergency-fund.md`, `debt-payoff.md`, `income-tax-th`, `scam-check` before sending money to any "guaranteed" scheme. If installed: `household-money` (personal-life) to clear forgotten subscriptions.
