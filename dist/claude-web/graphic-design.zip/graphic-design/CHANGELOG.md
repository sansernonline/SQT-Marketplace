# Changelog — graphic-design

## 0.37.0 — 2026-11-27

- `narration-th`: บทพรีเซนต์สไลด์ละประโยคยาว ใช้ `tts_cues.py --keep-spaces` (ช่องว่างไทยเป็นจังหวะสั้น ใส่ , เฉพาะจุดหยุด ลบช่องว่างรอบคำอังกฤษ) แทนกฎ tutorial ที่เปลี่ยนทุกช่องว่างเป็น , · เสียง Niwat −5% กับชุดแต่งเสียงที่เจ้าของบอกว่า "โทนเสียงดีมาก" · วิธีใส่เสียงทับวิดีโอสไลด์เดิมโดยค้างภาพแทนการตัด (`references/presentation.md`)
- สคริปต์ใหม่ `split_words.py`: `check` หาคำที่เครื่องอ่านแยกเป็น 2 คำในประโยคจากเวลาของคำ (แทปเล็ต → แทป|เล็ต) · `make --splice` ต่อคำที่เจ้าของเลือกจากตัวอย่างเข้าไปพร้อมรอยต่อที่เจ้าของรับ · `make --speedup` เร่งตัวย่อที่สะกดทีละตัว (พี-โอ-เอส ×1.2)
- ตัวย่อเขียนคำอ่านแบบมีขีด `POS<TAB>พี-โอ-เอส` (ติดกันอ่านเป็น "พีโอส") · ทำตัวอย่างจากประโยคจริงและเทียบรูปคลื่นกับตัวอย่างที่เลือกก่อนบอกว่าแก้แล้ว · การแจ้งว่าเป็นเสียง AI บังคับเฉพาะ Azure ที่เหลือแล้วแต่เจ้าของ
- เคส eval `narration-th-regression` จากคำของเจ้าของ 2026-11-26 เตรียมไว้ ยังไม่ได้รัน

## 0.36.2 — 2026-11-27

- แก้ตามผู้ตรวจ: `meaning-first.md` ใช้ป้ายรอยืนยันที่บอกว่ารอใคร · `design-by-type` ลิงก์ไปแนวทาง 12 ขั้นของ superuser

## 0.36.1 — 2026-11-27

- `flat-design.md` ชี้สคริปต์ `depth_mark.py` ของ superuser แทนโค้ดงานทดลองโค้ดเรือนที่ลบแล้ว

## 0.36.0 — 2026-11-27

- งานโลโก้และไอคอนทำ 2 สไตล์คู่กันทุกแนว คือแบบมีมิติ (แสงเงา ไล่สี) กับแบบ flat design ให้เจ้าของเลือกสไตล์ไปพร้อมแนว (เจ้าของขอ 2026-11-27 "อยากให้มีการใช้ style flat design ด้วย") · กฎอยู่ใน `design-by-type/references/flat-design.md`: ใช้สีทึบ 3–4 สีจากแบรนด์ ไม่ไล่สี ไม่เบลอ ไม่มีเงานุ่ม มิติได้จากระนาบสองโทน เงาเลื่อนขอบคม และร่องตัดตรงจุดที่ชิ้นส่วนไขว้กัน ใช้รูปทรงเดียวกับแบบมีมิติ และต่ำกว่า 20 px ใช้รูปย่อที่ตัดรายละเอียดข้างในออก · ลองกับงานโค้ดเรือนแล้ว ผู้ตรวจให้แนวหลังคาเรือนไทยแบบ flat สูงกว่าแบบมีมิติ
- วิธีคิดแบบเริ่มจากความหมาย (`design-by-type/references/meaning-first.md`) ใช้ก่อนออกไปหาต้นแบบและผิวสัมผัส: เขียนความรู้สึกที่ลูกค้าต้องได้ 2–3 คำ (เช่น เร็ว · น่าเชื่อถือ) · ใช้ 1 ความหมายต่อ 1 ตราก็พอ ไม่ต้องมีของตามชื่อแบรนด์ · หาไอเดียจากของในที่ทำงานจริง (คอม เมาส์ ปุ่ม Enter หน้าต่างเทอร์มินัล) · ล็อกสไตล์ต่างกันทุกแนวจากตาราง 8 สไตล์ แล้วจึงค้นด้วยคำ สิ่งของ + สไตล์ + อุตสาหกรรม (เจ้าของขอ 2026-11-27 "ที่จริงไม่จำเป็นต้องมีคำว่าเรือนก็ได้นะ คือมีความหมายใดความหมายหนึ่ง ก็เพียงพอแล้ว")
- `logo.md` ข้อ 11 และรายการตรวจก่อนส่ง · `SKILL.md` ขั้น 6 · `wow-score.md` ชี้มาที่ไฟล์ใหม่

## 0.35.1 — 2026-11-26

- ต้องใช้ superuser `^4.0` แทน `^3.0` · รุ่นก่อนทำให้ `claude plugin update superuser` ข้าม 4.0.0

## 0.35.0 — 2026-11-26

- ชี้ชื่อ skill ของ superuser 4.0.0 ที่รวมแล้ว (เช่น `design-gate` · `ground-rules` · `workspace-rules`) แทนชื่อเดิม

## 0.34.0 — 2026-11-25

- skill ใหม่ `design-by-type`: แยกประเภทงานก่อน (โลโก้ · โปสเตอร์ · แบนเนอร์ · ปกเอกสาร · สไลด์) อ่านบริบทโปรเจกต์ 2 บรรทัดแล้วหาแนวด้วย `design_search.py --domain industry` หางานจริงที่มียอดนิยม จดตัวเลขพร้อมวันที่ ผสม 2–3 ชิ้นต่อแนวเป็นงานใหม่ 3 แนวให้เจ้าของเลือก · มีกฎความสวยแยกตามประเภทใน `references/` (logo · poster · banner · document-cover · slides) วิธีผสมและตารางยอดนิยมต่อเว็บใน `blend.md` และแหล่งอ้างอิงใน `sources.md` · กฎบางส่วนดัดแปลงจาก nextlevelbuilder/ui-ux-pro-max-skill (MIT) แล้วลองกับงานจริง 15 แนวเมื่อ 2026-11-19
- ขั้นเก็บงาน (`design-by-type/references/polish.md`): ใส่มิติ ภาพซ้อน แสง และรูปทรงที่มาจากไอเดียของงาน ก่อนส่งให้ผู้ตรวจรอบแรก · ทดลองกับ 4 แนวที่เจ้าของรับ ได้คะแนนว้าว 7–8 ในรอบเดียว (เจ้าของขอ "ว้าวเหมือนทำจาก canva ai" 2026-11-19)
- คะแนนว้าว (`design-by-type/references/wow-score.md`): 5 ข้อ ข้อละ 0–2 (หยุดสายตา · ไอเดียของงานนี้ · ลูกเล่นที่มีความหมาย · มิติและแสง · ความประณีต) ส่งให้เจ้าของเมื่อได้ 7 ขึ้นไปและไม่มีข้อไหนได้ 0 · เกณฑ์อิงการตัดสินของ Awwwards (Honorable Mention 6.5/10) และ D&AD (ไอเดียใหม่ · ทำได้ดี · เข้ากับบริบท) · `design-critic` ให้คะแนนนี้ทุกครั้ง · ชุด beauty ใช้ตารางเดียวกันให้เจ้าของตรวจผู้ตรวจได้ (เจ้าของขอ 2026-11-19 "อยากให้ design ของเราว้าว ตั้งแต่แรก")
- โลโก้ทางใหม่: สร้างเครื่องหมายจากตัวอักษรของฟอนต์ที่ใบอนุญาตเปิด (OFL) ด้วย fontTools แทนการให้ AI วาด SVG เอง · `brand-kit` ขั้น 0 ชี้มาที่นี่ · ทำตรา 2 แบบ คือแบบมีแสงเงาและรูปทรงสำหรับใช้หลัก กับแบบแบนสีเดียวสำหรับขนาดเล็ก (เจ้าของบอกว่าตราแบนดูแข็ง 2026-11-19)
- `design-critic`: ตอบคำถามความแข็ง 6 ข้อจาก `no-ai-look` `references/stiffness.md` และบอกว่าแข็งหรือไม่
- เคส eval 3 เคสของ `design-by-type` (trigger · behaviour · regression จากคำของเจ้าของ 2026-11-18) เตรียมไว้ ยังไม่ได้รัน

## 0.33.0 — 2026-11-25

- ทุก skill/agent ด้าน design: ด่านก่อนลงมือเริ่มด้วยการอ่านเนื้อหาแล้วเขียนบรีฟ `เนื้อหา:` (ตาม `design-references` ข้อ 0) · `design-critic` ตรวจบรรทัดหลักฐาน 8 ช่อง

## 0.32.3 — 2026-11-18

- sync `brief-template` จาก superuser 3.50.2: บรรทัด `กติกา:` ใช้ประโยคบังคับฉบับไทยที่ด่านส่งงานตรวจ และบอกให้ใส่ `model` + `effort` ในคำสั่งเรียก

## 0.32.2 — 2026-11-18

- ตัดข้อความซ้ำ ไม่รวมหรือเปลี่ยนชื่อ skill: brief-to-image ชี้ไปรายการ style 6 แบบที่ `image-generation/references/styles.md` แทนการเขียนรายการซ้ำ · ตาราง hook แบบพูดหน้ากล้อง (6 แถว) และกฎของมัน ย้ายจาก speaking-script ไปอยู่ที่ `video-script-to-clip/references/hooks-and-example.md` หัวข้อ Spoken hook patterns แล้ว speaking-script ชี้ไปหา (เทียบทีละแถวแล้ว ตารางทั้งสองเป็นคนละชุดแถว เก็บไว้ครบทุกแถว) · ตัวเลข caption (≤ 35 ตัวอักษรต่อบรรทัด · ≤ 17 ตัวอักษรต่อวินาที) ไม่ถูกแตะ

## 0.32.1 — 2026-11-18

- narration-th: บันทึกว่าเสียง Premwadee ของ edge-tts 7.3.1 ไม่ส่งเสียงกลับมาในบางบรรทัด เช่น "มุมขวาบน" และ "ที่มุม" (ลองซ้ำก็ไม่ได้) ขณะที่ Niwat อ่านได้ทุกบรรทัด ให้อ่านบรรทัดนั้นด้วย Niwat หรือเรียบเรียงใหม่ แล้วแจ้งผู้ใช้ (พบ 2026-11-17)

## 0.32.0 — 2026-11-17

- style-consistency: เพิ่ม `references/corporate-profile-deck.md` สูตรหน้าของ company profile แนวแดง ขาว และเทาเข้ม จาก deck ที่ผู้ใช้ชอบ (2026-11-17) มีกรอบหน้าที่ใช้ซ้ำ (หัวเรื่อง เนื้อหา 1 แบบ และแถบล่าง) เนื้อหา 6 แบบ ค่าสีและฟอนต์ที่วัดจากไฟล์จริง ข้อควรระวัง (ทำข้อความเป็นตัวหนังสือจริง ไม่ทำทั้งหน้าเป็นภาพ ตรวจตัวหนังสือมั่วในภาพที่ AI ทำ และขออนุญาตก่อนใช้โลโก้ลูกค้า) และวิธีจัดการเมื่อขัดกับ no-ai-look · ยังไม่ได้ลองทำ deck จริงด้วยสูตรนี้

## 0.31.1 — 2026-11-17

- ของกลางจาก superuser 3.45.0: config แม่แบบมีโมดูล `resume_check` (เตือนข้อเก่าใน "รับงานต่อ" และเตือนให้อัปเดตก่อนจบ) · แม่แบบ CONTEXT มีกฎ `รับโดย:` และป้าย `ขัดกัน` จาก superuser 3.44.0 ซึ่งรอบนั้นไม่ได้ขึ้นรุ่น plugin นี้

## 0.31.0 — 2026-11-16

- narration-th: edge ตั้งต้นช้าลงเหลือ -10% (Niwat -8%) และเพิ่มข้อสำหรับ tutorial ที่อ่านทีละจอ ให้แปลงช่องว่างระหว่างวลีเป็นจุดหยุด (ผู้ใช้สั่ง 2026-11-16 ให้ลดความเร็วและปรับการเว้นวรรคเสียง) · ยังไม่ได้รัน eval เทียบก่อนและหลัง

## 0.30.0 — 2026-11-16

- SKILL.md สั้นลงให้เหลือเท่าที่ใช้ทุกครั้ง (ผู้ใช้สั่ง 2026-11-16 "ให้ skill lean ที่สุด") · 23 skill · ตัวที่ถูกเปิดจริงใน log เขียนใหม่เป็น Use when · Steps · Check before done · References · ตัวอื่นตัดบรรทัดบอก plugin เครดิต ประวัติ กฎที่ซ้ำแกน และ anti-pattern ที่ซ้ำ · ที่มาพร้อมวันตรวจ ตัวอย่างเต็ม แม่แบบ และตารางยาวย้ายไป `references/` (เปิดเมื่อจำเป็น) · เงื่อนไข เกณฑ์ ขั้นตอน และตัวเลขใน facts.json คงครบ · ยังไม่ได้รัน eval เทียบก่อนและหลัง

## 0.29.3 — 2026-11-16

- แปลประโยคคำสั่งภาษาไทยที่ยังค้างในไฟล์ที่ model อ่านเป็นภาษาอังกฤษ (ผู้ใช้สั่ง 2026-11-16 "แปลให้ครบก่อน แล้วค่อยวัดผล") · แก้ 8 ไฟล์ใน plugin นี้ · ไทยที่เหลือเป็นแม่แบบ ตัวอย่าง ชื่อทางการ ป้ายสถานะ และคำที่ตัวตรวจจับ ซึ่งตั้งใจคงไว้

## 0.29.2 — 2026-11-15

- แปลไฟล์ที่ model อ่านที่ยังเป็นไทยส่วนที่เหลือทั้งหมดเป็นภาษาอังกฤษ (SKILL.md · references · agents · ผู้ใช้สั่ง 2026-11-15 "แปลเป็นอังกฤษให้หมด") · รอบนี้แก้ 23 ไฟล์ใน plugin นี้ · แม่แบบ ตัวอย่าง และข้อความที่ส่งถึงผู้ใช้ไทย ชื่อกฎหมายและหน่วยงาน ป้ายสถานะ ป้ายหลักฐาน และคำที่ hook หรือตัวตรวจจับ คงเป็นไทย · ยังไม่ได้รัน eval เทียบก่อนและหลัง

## 0.29.1 — 2026-11-15

- SKILL.md และ reference ที่ถูกใช้ (icon-design · narration-th · subtitles-th · video-editing · print-ready-files · youtube-thumbnail) · agent image-artist · playbook ของ superuser สาขาเป็นภาษาอังกฤษ (ผู้ใช้สั่ง 2026-11-15 · เลือกไฟล์จากการใช้จริงใน log 2,900 session · ไทยในไฟล์ที่แปลลดลง 88%) · ป้ายสถานะ ป้ายหลักฐาน คำที่ hook และตัวตรวจจับ และตัวอย่างภาษาไทยคงเป็นไทย · ยังไม่ได้รัน eval เทียบก่อนและหลัง

## 0.29.0 — 2026-11-15

- description ของ skill ทั้ง 24 ตัวเป็นภาษาอังกฤษประโยคเดียว ยาวไม่เกิน 65 ตัวอักษร · รายการ skill ของ plugin นี้ลดจาก 3,784 เหลือ 2,056 ตัวอักษร · รวมทุก plugin เหลือ 24,071 ตัว ต่ำกว่างบตั้งต้น 30,000 ของ Claude Code จึงไม่ต้องตั้ง `skillListingBudgetFraction` แล้ว (ผู้ใช้สั่ง 2026-11-15)
- ยังไม่ได้รัน trigger eval เทียบก่อนและหลัง (เสียเงิน รออนุมัติ)

## 0.28.8 — 2026-11-12

- ตัวเลขที่เปลี่ยนบ่อยไม่เก็บใน skill แล้ว ให้ค้นสดจากหน้าทางการทุกครั้ง เปิดไม่ได้ใส่ `(รอยืนยัน)` · คงเฉพาะเลขที่สคริปต์ใช้คำนวณ · แถวใน `scripts/check/expiry.json` ลดจาก 26 เหลือ 8 · `social-formats` (ระยะปลอดภัย · ขนาดโฆษณา · `platform-sizes.md`) · `marketplace-product-images` · `youtube-thumbnail` · `brief-to-image` (รุ่น Gemini) · `video-editing` (ความดังต่อแพลตฟอร์ม คงค่าตั้งต้น -16 LUFS ที่ `loudnorm2.py` ใช้) · `narration-th` (ราคา TTS) · คง `line-richmenu` เพราะ `richmenu_check.py` ใช้ · eval `social-formats-behaviour` และ `youtube-thumbnail-behaviour` ตรวจว่าอ้างหรือค้นหน้าทางการแทนตัวเลข · `facts.json` ตัด 3 ค่า (ความดัง Apple Podcasts · Spotify · โควตาฟรี Google TTS)

## 0.28.7 — 2026-11-12

- eval: ตัวให้คะแนน regex ที่เขียน `(?i)` ในตัว pattern (JavaScript ไม่รับ จึง error เงียบ) ย้ายเป็น `flags: i`

## 0.28.6 — 2026-11-12

- สำเนา `superuser/references/team-roles.md` ของ plugin นี้เป็นภาษาอังกฤษตาม superuser 3.39.1

## 0.28.5 — 2026-11-11

- `superuser/SKILL.md` ของ plugin นี้เป็นภาษาอังกฤษ (เล็กลงราว 40%) · คำไทยที่ hook ตรวจ ป้ายสถานะ และชื่อเอกสารราชการไทยคงไว้

## 0.28.4 — 2026-11-11

- สำเนา `superuser/references/` (brief-template · review-lenses · team-roles) ตรงกับแกน 3.38.0: ใบสั่งงานสั้น · โหมด test ของผู้ตรวจ · รอลูกทีมแบบ background

## 0.28.3 — 2026-11-11

- `superuser/references/team-roles.md` ตรงกับแกน: ผู้ตรวจในงบสมดุลใช้ระดับกลางทุกรอบ ระดับใหญ่เฉพาะรอบสุดท้ายของงานเสี่ยง

## 0.28.2 — 2026-11-11

- ใบสั่งงานแบบสั้นของ `worker` ตาม `superuser` 3.36.0: ชี้ไฟล์และหัวข้อของ spec แทนการคัดลอก · 1 หน่วยของโจทย์ = 1 ใบ เขียนทั้งโค้ดและ test

## 0.28.1 — 2026-11-11

- ใบสั่งงานแบบสั้นสำหรับ `worker` (`references/brief-template.md`) และ `team-roles.md` ตามต้นฉบับใน `superuser` 3.35.0: ลูกทีมค่าเริ่ม `haiku` รัน test เองได้

## 0.28.0 — 2026-11-11

- `narration-th`: เพิ่ม `scripts/term_sample.py` อ่านศัพท์ทีละคำแบบ "1, คำ" ได้ไฟล์เสียงชายกับหญิงและรายการเลข ให้ผู้ใช้ฟังหาคำที่ต้องแก้ก่อนสร้างทั้งตอน · `tts_cues.py --respell` สะกดใหม่หลังแทนคำอ่าน · ความเร็ว edge ที่ผู้ใช้เลือก Niwat +0% และ Premwadee −2% · ต้นแบบจาก podcast IoT 338 คำ (2026-11-09)
- `narration-th`: เพิ่มกติกาสคริปต์ podcast (เข้าเนื้อหาเลย · ไม่แนะนำตัว · ไม่คุยกับผู้ฟัง · 1 บรรทัด = 1 ประโยค) · `tts_cues.py` แปลงเลขอารบิกเป็นคำไทยทั้งก้อน (ปี 2569 → สองพันห้าร้อยหกสิบเก้า ไม่แยก 25 69) และตัดช่องว่างระหว่างอักษรไทยก่อนส่งเครื่องอ่าน เพราะช่องว่างทำให้เครื่องหยุดกลางประโยค

## 0.27.2 — 2026-11-10

- `line-sticker`: ถามว่าจะผ่านไหมหรือได้ส่วนแบ่งเท่าไร ตอบว่าสคริปต์ตรวจแค่ตัวเลขไฟล์ ส่วนแบ่งใส่ (รอยืนยัน) ไม่บอกเปอร์เซ็นต์จากความจำแม้มีคำเตือน (eval 2026-11-10 บอก 50% จากความจำ 2/3 รอบ)
- eval `line-sticker-guard`: regex marks-unverified รับคำว่ายังไม่ได้อ่าน/ตรวจ และยืนยันไม่ได้ด้วย

## 0.27.1 — 2026-11-10

- `social-formats` · `video-script-to-clip` · `brand-kit`: ส่วน Related ชี้ skill พี่น้องที่มีอยู่จริง (`banner-design` · `youtube-thumbnail` · `marketplace-product-images` · `line-richmenu` · `print-ready-files` · `speaking-script` · `subtitles-th` · `narration-th`) · โค้ด token ชี้ `design-system`
- เอาอีโมจิที่เป็นหัวข้อและป้ายออกจากเอกสารใน plugin
- eval ใหม่: `asset-organize` · `motion-basics` (trigger + behaviour อย่างละ 1 เคส)
- `copy-claims-check`: เขียนชื่อ อย. และ สคบ. เต็มครั้งแรก · "ข้อเท็จจริง" แทน "ข้อความเท็จจริง" · `evals/RESULTS.md` จดว่า `copy-claims-check` และ `line-sticker` ยังไม่ได้รันรอบแดง/เขียว (รอผู้ใช้อนุมัติค่า eval)

## 0.27.0 — 2026-11-10

- `copy-claims-check` (ใหม่): ตรวจข้อความโฆษณาเกินจริงด้วยประกาศ อย. โฆษณาอาหาร พ.ศ. 2564 และหน้า สคบ. ที่เปิดอ่านจริง · หมวดอื่นเป็น (รอยืนยัน) · ไม่ใช่คำปรึกษากฎหมาย
- `line-sticker` (ใหม่): เพดานสติกเกอร์นิ่ง เคลื่อนไหว และอีโมจิ LINE (ตรวจ 2026-11-10) พร้อม `scripts/sticker_check.py` และ `--self-test`
- `design-review`: รายการข้อบกพร่องจากภาพที่เรนเดอร์ · grep หาข้อความตกค้าง · คอนทราสต์ 3:1 ของไอคอน · alt text ก่อนส่ง · ตรวจตามระยะงาน (ร่างแรกดูแค่จุด 1-2)
- `campaign-set`: ด่านส่งงานเพิ่ม alt text และ `copy-claims-check` · แม่แบบเมทริกซ์เพิ่มคอลัมน์ข้อความสูงสุด · ถ้ายาวกว่านี้ · alt text
- `motion-basics`: `scripts/gif_check.py` อ่านขนาด MB เฟรม fps วินาทีของ GIF (WebM/MP4 ผ่าน ffprobe) แล้วเทียบเพดานที่ผู้ใช้ส่ง ไม่ฝังเพดานปลายทาง
- `social-formats`: แถวโพสต์ตัวเลข 1 ภาพ 1 ข้อสรุป ชี้ไป `data-analysis`

## 0.26.3 — 2026-11-10

- อ้างถึง plugin ซอฟต์แวร์ด้วยชื่อใหม่ `software-development` (เดิม `software-company`)
- ของกลางจาก superuser 3.33.0 (sync): ขั้นตรวจงานใหม่ใน `playbook-review` · แจกงานและรอลูกทีมใน `team-roles` · รอบ `playbook-unattended-run` มีตรวจเครื่องมือและกล่องขาออก · แม่แบบสมุดงาน ledger และแนวคิดที่ปฏิเสธใน `templates/` · แม่แบบ `config.json` มีโมดูล hook ใหม่

## 0.26.2 — 2026-11-08

- `references/examples.md`: ตัวอย่างระดับโมเดลจัดตามกฎ 3 ข้อของ superuser 3.26.0 (งานเสี่ยง → opus · งานกลไกที่มีแบบ → haiku · ที่เหลือ → sonnet)

## 0.26.1 — 2026-11-08

- `brand-kit`: description มีคำว่า voice และไม่เกิน 150 ตัวอักษร
- `banner-design` `references/uipro-banner-sizes-and-styles.md`: เพิ่มสารบัญ (ไฟล์ 119 บรรทัด)

## 0.26.0 — 2026-11-08

- ยุบ `brand-guidelines` เข้า `brand-kit` หัวข้อ "เขียนเป็นเอกสาร" · ขั้นตอนเต็มอยู่ใน `references/brand-guidelines.md` · สคริปต์ `.cjs` 4 ตัวย้ายไป `brand-kit/scripts/` · **เรียกชื่อเก่าไม่ได้แล้ว** · ไฟล์ผล `docs/brand-guidelines.md` ใช้ชื่อเดิม
- eval `brand-guidelines-*` เปลี่ยนชื่อเป็น `brand-kit-guidelines-*` · agent `brand-keeper` ชี้ตัวใหม่

## 0.25.1 — 2026-11-07

- audit หัวข้อ 8: หัวข้อ "Not an AI look" ใน skill 10 ตัวเหลือลิงก์ชี้ `no-ai-look` 3.2 (ตัดเลข "8-point" ที่ไม่ตรงของจริง) · subagent ตรวจภาพใน banner-design · brief-to-image · icon-design · image-generation กำหนดขนาดคำตอบและใช้ haiku ทายภาพ · agent 4 ตัว (art-director · brand-keeper · image-artist · social-creator) มีหัวข้อ "What You Return" จำกัด 15 บรรทัด ไม่แนบเนื้อไฟล์

## 0.25.0 — 2026-11-07

- `subtitles-th`: หัวข้อใหม่ "0 · หาแบบที่มีอยู่ก่อน" ใช้ฟอนต์และสีของแบรนด์หรือคลิปก่อนในช่องเดียวกันก่อน IBM Plex Sans Thai เป็นค่าสำรอง

## 0.24.0 — 2026-11-07

- เอาคำสั่งที่เป็นแค่ทางลัดไปหา skill ตัวเดียวออก 6 ตัว เรียก skill ตรงแทน เช่น `/graphic-design:brand-kit` · ขั้นตอนและ `argument-hint` ของคำสั่งเดิมย้ายไปหัวข้อ "เรียกเป็นคำสั่ง" ท้าย SKILL.md ของ skill ปลายทาง: `brand-init` → `brand-kit` · `brief` → `brief-to-image` · `campaign` → `campaign-set` · `resize-all` → `social-formats` · `review-design` → `design-review` · `video` → `video-script-to-clip`

## 0.23.0 — 2026-11-06

- agent `design-critic`: เป็นผู้ตรวจด้วยตาตัวใหม่ที่ `no-ai-look` บังคับก่อนส่งงาน (superuser 3.21.0) · ดูภาพขนาดจริง ตอบข้อ 3.2 เอง ไม่อิงผลตรวจของคนทำ

## 0.22.0 — 2026-11-06

- skill 17 ตัวมีบรรทัด "ด่านก่อนลงมือ" ชี้ไป `design-references` (superuser 3.20.0): banner-design · brand-kit · brand-guidelines · brief-to-image · campaign-set · icon-design · image-generation · line-richmenu · marketplace-product-images · motion-basics · social-formats · style-consistency · video-script-to-clip · youtube-thumbnail (3 แนว) · image-editing-brief (1 แนวได้) · design-review (ไม่มีบรรทัดหลักฐาน = ข้อแก้อันดับ 1) · print-ready-files (ต้องผ่านด่านก่อนส่งโรงพิมพ์) · `marketplace-product-images` และ `print-ready-files` เดิมไม่มี `no-ai-look`
- `brief-to-image`: ค้นต้นแบบทุกครั้ง มี style lock แล้วค้นเฉพาะองค์ประกอบ (เดิมข้ามเมื่อมี style lock)
- agent `art-director` · `brand-keeper` · `image-artist` · `social-creator`: ผ่านด่านก่อนลงมือก่อนงานสร้างสรรค์ทุกชิ้น · `design-critic`: งานไม่มีบรรทัด `ด่านก่อนลงมือ:` = ข้อแก้อันดับ 1 ยกเว้นงานที่ผู้ใช้หรือคนนอกออกแบบเอง

## 0.21.1 — 2026-11-06

- `image-generation`: บรรทัดก่อนส่งบอกว่าทุกงานต้องผ่านด่านตาของ `no-ai-look` (superuser 3.19.0)

## 0.21.0 — 2026-11-05

- skill ใหม่ `banner-design`: แบนเนอร์ 3 แนวขนาดจริง (ปก webinar · หัวเพจ · hero · แบนเนอร์โฆษณา) · ขั้นตอนและไฟล์อ้างอิงขนาดกับ 22 แนวศิลป์คัดลอกจาก nextlevelbuilder/ui-ux-pro-max-skill commit `28b3b8d` (MIT · ใบอนุญาตใน `references/LICENSE-uipro`) · เพิ่มเอง: หาต้นแบบจากร้านธีมและ Pinterest · ฟอนต์ไทย · สคริปต์ `render_banner.py` (self-test 3/3 · ลองกับแบนเนอร์ทดลองจริงแล้ว) · ขั้นตรวจ `no-ai-look` และผู้ตรวจตัวใหม่ · แถวใน skill-router · eval `banner-design-trigger` (เตรียมไว้ ยังไม่ได้รัน)

## 0.20.0 — 2026-11-05

- skill ใหม่ `brand-guidelines`: คู่มือแบรนด์ฉบับเต็ม (น้ำเสียง · ข้อความหลัก · การอนุมัติ · การเก็บไฟล์) ลอกจาก ui-ux-pro-max-skill `brand` (MIT · commit `b7d5353`) · สคริปต์ Node 4 ตัวไม่ต่อเน็ต · ซิงก์สีเข้า token · ไม่ลอกตัวสร้างโลโก้ · eval 3 เคส

## 0.18.0 — 2026-10-28

- skill ใหม่ `narration-th`: แยกเสียงบรรยายไทยจากสคริปต์ (text-to-speech) ออกจาก `video-editing` ตามที่ผู้ใช้เลือก (เดิมรวมไว้ 2026-10-24) · ย้ายแบบตัดแปะ ไม่เขียนเนื้อใหม่ · สคริปต์ `tts_cues.py` `f5_worker.py` `windows_tts.ps1` และ `references/tts-engine-score.example.json` ย้ายตาม · `video-editing` เหลือตัด ต่อ ความดัง สไลด์เป็นวิดีโอ และชี้มาที่ skill ใหม่
- eval `video-editing-tts-*` เปลี่ยนชื่อเป็น `narration-th-trigger` `-behaviour` `-guard` · เพิ่มเคสไม่ควรเปิด `narration-th-trigger-negative` (เตรียมไว้ ยังไม่ได้รัน) · agent `video-editor` ชี้ skill ใหม่

## 0.17.0 — 2026-10-28

- สคริปต์ตัดต่อ (`silences` `loudnorm2` `slides_to_video`) ไม่เขียนทับไฟล์ผลลัพธ์ที่มีอยู่แล้ว เว้นแต่ใส่ `--force` · เสนอชื่อใหม่ `-v02` · ตัวกันร่วมกันคือ `outguard.py` มี `--self-test`
- ค่าคงที่ของ `tts_cues.py` และ `silences.py` มีเหตุผลกำกับ หรือบอกว่า "ค่าตั้งต้น ยังไม่ได้วัด"
- `line-richmenu`: ตั้งเมนูเริ่มต้นและลบเมนูต้องขออนุมัติก่อน (ทดสอบกับผู้ใช้ 1 คน) · token อ่านจากตัวแปรสภาพแวดล้อมเท่านั้น · สคริปต์ใหม่ `richmenu_check.py` ตรวจ JSON กับภาพในเครื่อง (8/8) · เพดานอยู่ใน `references/richmenu-limits.json`
- `print-ready-files`: สคริปต์ใหม่ `print_check.py` ตรวจระยะตัดตก ฟอนต์ฝัง ppi หมึกรวม (8/8 รวมตรวจ PDF จริงด้วย poppler) · เกณฑ์อยู่ใน `references/print-specs.json`
- `asset-organize`: สคริปต์ใหม่ `apply_renames.py` ตรวจ `rename-log.csv` (ต้นทางหาย ชื่อชน ชื่อซ้ำ) ค่าตั้งต้น dry-run ทำเป็นสำเนา มี `--undo` (5 ข้อ)
- `brief-to-image`: ผิดทางกายภาพเป็นกฎเหล็กอย่างเดียว ไม่นับเป็นคะแนนซ้ำ · น้ำหนักใหม่ 0.40/0.30/0.15/0.15 (ค่าตั้งต้น ยังไม่ได้วัด) · เส้นแบ่งกับ `image-generation` ชัดขึ้น ตัดหัวข้อ brief ซ้ำออกจาก `image-generation`
- `video-editing` ใช้ `decide.mjs score` เลือกเครื่องเสียงบรรยายด้วยกฎเหล็กสิทธิ์เชิงพาณิชย์ · `youtube-thumbnail` กรองปกด้วย `pairwise` ก่อนอัปโหลด · `design-review` จัดลำดับจุดแก้ด้วย `priority` · งบเครดิตภาพ AI ใช้ `knapsack` · ตัวอย่าง JSON 4 ไฟล์รันผ่าน
- `motion-basics`: หัวข้อส่งออก GIF และ WebM ด้วย ffmpeg (คำสั่งรันผ่านจริง) · เพดานขนาดต่อปลายทางยังเป็น (รอยืนยัน)
- `icon-design` มีแถวใน triggers และ `image-artist` ส่งงานไอคอนมาที่ `icon-design` · คำว่าไอคอนอยู่ใน description ของ plugin · แก้เลขแถวใน `superuser` และ path ใน `speaking-script`
- eval: เคส "ไม่ควรเปิด" 4 เคส · เคสใหม่ 5 เคส (`brief-to-image` ×2 · `image-generation` · `design-review` · `video-script-to-clip`) · เกณฑ์อนุมัติใน `line-richmenu-behaviour` · `RESULTS.md` ใส่ช่วง 95% ยังไม่ได้รันเคสใหม่

## 0.16.1 — 2026-10-28

- `silences.py` รวมช่วงเก็บที่ทับกันเมื่อ `--pad` เกินครึ่งช่วงเงียบ เดิมได้เสียงซ้ำ
- `fetch_free_image.py` รับเฉพาะ https (redirect ไป http ก็ไม่ตาม) และหยุดเมื่อเกิน 25 MB · รูปที่ไม่ผ่านถูกข้าม รูปอื่นยังได้บรรทัดเครดิต

## 0.16.0 — 2026-10-27

- `brief-to-image` และ `image-generation` เลือกภาพจากหลายแบบด้วยคะแนน 5 เกณฑ์หรือเทียบเป็นคู่สลับตำแหน่ง (`decision-scoring`) · เรื่องรสนิยมผู้ใช้ตัดสิน

## 0.15.1 — 2026-10-27

- ไอคอนประจำ plugin `assets/icon.png` (512) และ `assets/icon.svg` · ช่อง `icon` ใน plugin.json (ใช้ในหน้ารายการของ directory) · ทำตาม `design-references`: ค้นต้นแบบบน Dribbble แล้วถอดสีหลักจากงานต้นแบบ หมุนเฉดต่อ plugin · ผ่าน design-critic

## 0.15.0 — 2026-10-27

- skill 10 ตัว (`brand-kit` · `campaign-set` · `social-formats` · `youtube-thumbnail` · `icon-design` · `image-generation` · `style-consistency` · `line-richmenu` · `motion-basics` · `brief-to-image`) และ agent `art-director` `brand-keeper` `social-creator` `image-artist`: ขั้นแรกค้นต้นแบบสดตาม `design-references` (superuser) แล้วถอดสีจากงานที่เลือก

## 0.14.0 — 2026-10-27

- `icon-design`: แนวที่โค้ดวาดเองไม่ถึง (มีมิติ · หลายสี · 3 มิติ · ภาพประกอบ) หยิบชุดที่นักออกแบบทำไว้มาปรับแทน · `references/asset-sets.md` ชุดและใบอนุญาต 20 ชุด (Fluent color · IconPark · Fluent Emoji · Phosphor · Open Peeps ฯลฯ อ่าน LICENSE 2026-10-27) · `scripts/recolor_icon.py` เปลี่ยนเฉดสีให้เป็นของแบรนด์โดยคงแสงเงาของนักออกแบบ (self-test 5/5)
- กฎใหม่จากรอบที่ผู้ใช้ปฏิเสธ 2026-10-27: ห้ามตัดหรือบากกรอบไอคอน · ห้ามเอาเส้นแบนมาใส่เงาแทนแนวมีมิติ · ข้อเสนอของผู้ตรวจที่ไม่มีตัวอย่างงานจริงรองรับต้องถามผู้ใช้ก่อน

## 0.13.1 — 2026-10-26

- `icon-design` ข้อ 3.1 ใหม่: ค้นหมวดเองก่อนถามผู้ใช้แบบนักออกแบบ (ร้านที่ไอคอนจะไปอยู่ · กฎทางการ · ตระกูลไอคอนผูกเป็นชุดอย่างไร · แนวที่ดูออกว่า AI ทำ) แล้วเสนอ 3–4 แนวพร้อมลิงก์ · ผลค้นรอบแรกอยู่ใน `references/category-research.md` (แหล่ง 23 หน้าเปิดอ่าน 2026-10-26) · ผู้ใช้ขอหลังเห็นว่า skill ถามตัวอย่างอย่างเดียว

## 0.13.0 — 2026-10-26

- skill ใหม่ `icon-design`: ไอคอนในหน้าจอใช้ชุดฟรีชุดเดียวที่ใบอนุญาตใช้ได้ (Lucide · Tabler · Phosphor · Material Symbols · Fluent · ห้าม Remix และ SF Symbols ทำโลโก้) · ไอคอนแบรนด์ (แอป · favicon · plugin · เครื่องหมาย) ขอตัวอย่างที่ผู้ใช้ชอบก่อน หา metaphor 10 อย่าง เลือกเครื่องมือตามของที่มีในเครื่อง · ตัวเลขทุกแพลตฟอร์มใน `references/specs.md` · `scripts/icon_check.py` ตรวจ viewBox เส้น กริด แล้วทำหน้าเทียบทุกขนาดพร้อม blur test · eval 3 เคส · แหล่ง 28 หน้าเปิดอ่าน 2026-10-26
- รอบแดง 2026-10-26: ไอคอน plugin 3 แนวที่ agent เขียน SVG ทีละเส้นโดยไม่มีตัวอย่างจากผู้ใช้ ผ่านตัวตรวจทุกตัวแต่ผู้ใช้ปฏิเสธทั้งหมด

## 0.12.3 — 2026-10-26

- eval แบบ behaviour ให้ `marketplace-product-images` · `print-ready-files` · `youtube-thumbnail` · แถว hook router อยู่ใน `superuser`
- `brand-kit` (`thai-fonts.md`) และ `print-ready-files`: ฟอนต์ SIPA ดัดแปลงต้องแจ้งเป็นหนังสือและเปลี่ยนชื่อ · TH Sarabun New ใช้ GPL พร้อมข้อยกเว้นฟอนต์ ไม่ใช่ใบอนุญาต DIP-SIPA

## 0.12.2 — 2026-10-26

- `subtitles-th`: กฎห้าม Noto Sans Thai กับซับที่มีคำอังกฤษ บอกให้ชัดว่าไฟล์ชุด notofonts (รุ่น 2.002 ที่เครื่องนี้ติดตั้ง) ไม่มีตัวละตินเลย ส่วนชุดบน Google Fonts มี · ดูจากชื่อฟอนต์ไม่ออก จึงยังไม่ใช้ทั้ง 2 ชุด (ตรวจตารางตัวอักษร 2026-10-26)

## 0.12.1 — 2026-10-26

- `subtitles-th`: ฟอนต์ซับค่าเริ่มต้นเป็น IBM Plex Sans Thai (ผู้ใช้เลือกจากภาพเทียบ 7 ฟอนต์) · ห้ามใช้ Noto Sans Thai กับซับที่มีคำอังกฤษ เพราะไม่มีตัวละติน คำอังกฤษจะใหญ่กว่าตัวไทยราว 1.3 เท่า

## 0.12.0 — 2026-10-26

- เตรียมรุ่น 1.0.0 (ใช้จริง 2–3 สัปดาห์ก่อนขึ้นรุ่นหลัก)
- skill ใหม่ `marketplace-product-images` · `print-ready-files` · `youtube-thumbnail` พร้อม agent เจ้าของและแถวใน triggers
- ผูก agent เจ้าของ: `line-richmenu` และ `speaking-script` ให้ social-creator · `motion-basics` ให้ art-director · `print-ready-files` ให้ design-critic
- ตรวจขนาดแพลตฟอร์มซ้ำ 2026-10-26: safe zone ของ TikTok และ YouTube Shorts ตามตัวเลขทางการ · header และ profile ของ X · เพดาน rich menu ของ LINE จาก API reference
- สคริปต์ `video-editing` 4 ตัวมี `--self-test` (ไม่มี ffmpeg ก็ข้ามได้) · `f5_worker.py` บอกวิธีติดตั้งแทน traceback
- แทนไอคอน ✅ ❌ 10 บรรทัดเป็นคำ · eval ใหม่ 11 เคส (ยังไม่ได้รัน)

## 0.11.0 — 2026-10-25

- รับ agent `image-artist` มาจาก `software-company` ให้อยู่กับ skill `image-generation` ที่มันใช้ทุกงาน · `triggers.md` เพิ่มแถว `image-generation` และ `speaking-script` ที่ก่อนนี้ไม่มีทางเรียกจาก plugin นี้
- `line-richmenu` ตัดข้อความ "ถ้าติดตั้ง graphic-design" ที่ชี้หาตัวเอง
- รับ skill `line-richmenu` (rich menu ของ LINE OA: ขนาดภาพ · พื้นที่กด · JSON · คำสั่ง API) มาจาก `thai-workplace` ที่รวมเข้า `e-commerce` แล้ว

- eval `video-editing-regression` และ `video-editing-tts-regression` เปลี่ยนชื่อเป็น `-guard` เพราะรอบแดงทำถูกอยู่แล้ว ไม่ใช่เรื่องที่เคยพลาดจริง (กฎใหม่ใน `skill-authoring`)
- เพิ่ม skill `speaking-script`: สคริปต์ให้คนพูดหน้ากล้อง (คลิป influencer · รีวิว · พิธีกร · voiceover) — กฎข้อเดียว write for the ear · hook ก่อนทักทาย · ตารางภาษาเขียน → ภาษาพูด · จับเวลาด้วยนาฬิกาไม่นับคำ · ขั้น 0 หาคลิปอ้างอิงก่อนเขียน · eval 3 เคส ใน `evals/speaking-script-*` · เพิ่มแถวใน skill-router (พร้อมกัน pattern โค้ดไม่จับ "สคริปต์พูด" อีก) · triggers · file-map
- `brief-to-image`: เพิ่มขั้น 0 หารูปอ้างอิงที่ชอบก่อนเขียน prompt แล้วแตกว่าชอบอะไร (แสง · สี · องค์ประกอบ) ใส่ใน brief — ลดผลงานหน้าตาเหมือนกันทุกชิ้น
- skill ใหม่ 2 ตัวสำหรับตัดต่อด้วย ffmpeg และ agent ใหม่ `video-editor`: `video-editing` (ตัดให้ตรงเฟรม · ต่อคลิป · ตัดช่วงเงียบด้วย `scripts/silences.py` · ปรับความดัง 2 รอบด้วย `scripts/loudnorm2.py` และอ่านว่าได้ Linear หรือ Dynamic · แปลงเป็นแนวตั้ง · ภาพปก · ต่อภาพสไลด์จาก `check_deck.py` กับเสียงบรรยายตาม `data-at` ด้วย `scripts/slides_to_video.py` ให้ยาวเท่าเสียงพอดี · วัดไฟล์ที่ได้ทุกครั้ง) · `subtitles-th` (ถอดเสียงเป็น .srt · `scripts/srt_check.py` ตรวจความยาวบรรทัด ความเร็วอ่าน เวลา และเครื่องหมายตามตาราง caption ของ `video-script-to-clip` · ฝังซับด้วยฟอนต์ไทยแล้วเปิดภาพดูวรรณยุกต์) · ทดสอบทุกคำสั่งกับ ffmpeg 9.0.2 บน Windows 2026-10-24 · eval 9 เคส (`video-editing-*` · `video-editing-slides-*` · `subtitles-th-*`) · playbook `video` เพิ่มขั้นตัดต่อก่อนขั้นตรวจ · `triggers.md` เพิ่ม 3 แถว
- `video-editing` เพิ่มหัวข้อเสียงบรรยายจากสคริปต์ (text-to-speech): สร้างเสียงไทยทีละซับด้วย `scripts/tts_cues.py` ได้ `narration.wav` ซับ `.srt` และเวลาสไลด์ (`data_at`) จากการรันเดียวโดยไม่ต้องถอดเสียง · เครื่องสร้างเสียง 3 ตัว: F5-TTS-THAI เลียนเสียงจากคลิปต้นแบบ (`scripts/f5_worker.py` อ่านไฟล์ด้วย soundfile แทน torchcodec ที่ต้องมี DLL ของ FFmpeg) · edge-tts · เสียงที่มากับ Windows (`scripts/windows_tts.ps1`) · ไฟล์คำอ่านให้เครื่องอ่านศัพท์อังกฤษเป็นไทยแต่ซับแสดงคำเดิม · ทดสอบกับบทเรียน 9 ซับจนได้วิดีโอ 2026-10-24 · ตารางเครื่องเสียงบอกค่าใช้จ่ายและสิทธิ์เชิงพาณิชย์ · eval 3 เคส (`video-editing-tts-*`) · agent `video-editor` รับงานนี้ · playbook `video` · `triggers.md` · `subtitles-th` บอกว่า 5/6 วินาทีคือราว 0.83 วินาที และ `srt_check.py` พิมพ์ภาษาไทยได้บนเครื่องที่ไม่ได้ตั้ง UTF-8 · `speaking-script` ชี้มาที่หัวข้อนี้

## 0.10.0 — 2026-10-23

- รับ skill `image-generation` จาก `doc-toolkit` ที่ยุบ (ชื่อเดิม) · ตัด dependency `doc-toolkit`
- `brief-to-image`: `references/prompt-anatomy.md` เพิ่มหัวข้อ Tactile 3D hero object: แม่แบบภาพวัตถุ 3 มิติจับต้องได้ 8 บรรทัด (subject · material · light · shadow · lens · background · one colour · negatives) พร้อมตัวอย่างเครื่องหมายคำถามกระดาษตัดสีส้มบนกระดาษครีม · เพิ่มสารบัญเพราะไฟล์ยาวเกิน 100 บรรทัด · ลิงก์จาก `SKILL.md` · `image-generation` `references/styles.md` แถว `3d` เปลี่ยนจาก prompt ทั่วไป (clay · studio · pastel) เป็นวัสดุ แสง เงา และ negative ที่ระบุชัด แล้วชี้ไปแม่แบบ
- `video-script-to-clip`: เพิ่ม `references/production-tools.md` เครื่องมือแปลงสคริปต์เป็นคลิป (CapCut · DaVinci Resolve รุ่นฟรี · HyperFrames · Remotion) พร้อมเงื่อนไขใช้เพื่อการค้าของเพลง เทมเพลต และฟอนต์ใน CapCut · เกณฑ์ Company License ของ Remotion · ค่าส่งออกต่อแพลตฟอร์ม · ฟอนต์ซับไทย · กฎเพลง ตรวจแหล่ง 2026-10-23 · ลิงก์จาก `SKILL.md` หัวข้อ Related · แถวใหม่ใน `triggers.md`
- `brief-to-image`: ตาราง Failure modes 8 อาการ บอกว่าแก้อย่างเดียวอะไรเมื่อรูปพลาด (ตัวอักษรเพี้ยน → เอาคำออกจาก prompt แล้วใส่ข้อความตอนจัดหน้า · ภาพในชุดไม่เข้ากัน → style lock sheet กับ seed หรือรูปอ้างอิงเดียวกัน) · ผู้ใช้ Gemini API: โมเดล `imagen-4.0-*` ปิดบริการเมื่อ 2026-08-17 ตามหน้า deprecations ให้ใช้รุ่น `gemini-*-image` และจดรหัสโมเดลที่ใช้จริง (ตรวจ 2026-10-23) · `image-generation` เขียน 1 ย่อหน้าบนสุดของ `image-style.md` ว่าภาพชุดนี้คืออะไร (ใครดู · ดูแล้วรู้สึกอะไร · จะไม่เป็นแบบไหน) แล้วเทียบทุกรูปกับย่อหน้านี้
- `brand-kit`: แยก Imagery กับ Voice · Voice ใช้คู่ก่อนกับหลังภาษาไทยที่เจ้าของแบรนด์เขียนเอง พร้อมเลือก ครับ/ค่ะ สรรพนาม และระดับภาษา 1 แบบจาก `thai-grammar` ข้อความไทยของแบรนด์จึงเสียงเดียวกันทุกชิ้น
- `design-review`: squint test (หรี่ตา ซูม 10% หรือเบลอ 10 px แล้วดูว่าอะไรยังเห็น) · เช็กตัวอักษร 4 ข้อ (ระดับต่างกันด้วยขนาดและน้ำหนัก ไม่ใช่สีอย่างเดียว · บรรทัดเนื้อความ 45–75 ตัวละติน หรือราว 35–55 ตัวไทย · ไม่ใส่ letter-spacing กับเนื้อความไทย · 1 บล็อก 1 การจัดแนว)
- `motion-basics`: ตาราง token การเคลื่อนไหวของ Material 3 (easing 5 แบบ · ช่วงเวลา 50–1000 ms) ตรวจกับ material-web (Apache-2.0) 2026-10-23 · ฉากหลังที่เคลื่อนไหวต้องมีความหมาย ฉากที่แค่ตกแต่งให้ตัดทิ้ง
- `video-script-to-clip`: เครื่องหมายวรรคตอนไทยในซับไตเติลและข้อความบนจอ · ข้อความการตลาดบนจอทั้งคลิป 15 วินาที ไม่เกินราว 120 ตัวอักษรไทย (ไม่นับวรรณยุกต์และสระบนล่าง)
- ใช้แกน `superuser` 3.1.0: playbook `team-project` และค่าตั้ง hook `guard` · `recompact` (ปิดไว้)

## 0.9.1 — 2026-10-22

- แก้ชื่อ plugin ของ `image-generation` (เป็น `doc-toolkit`) · แก้ตัวชี้ใน examples/triggers

## 0.9.0 — 2026-10-22

- `skills/superuser/SKILL.md` เหลือเฉพาะส่วนของสาขา (กฎเพิ่ม · playbook · agent · รออนุมัติ · ไฟล์กลาง) ขึ้นต้นด้วย "เปิด `superuser:superuser` ก่อน" — แกนของหัวหน้าทีมอ่านจาก plugin `superuser` 3.0.0 ที่เดียว ไม่คัดลอกบล็อกกลางอีก (50 KB → ราว 12 KB)
- `dependencies` ใส่ช่วงเวอร์ชัน `{ "name": "superuser", "version": "^3.0" }` และเพิ่ม `{ "name": "doc-toolkit", "version": "^1.0" }` (skill เอกสาร สไลด์ รูป ประชุม 15 ตัวที่ย้ายออกจาก superuser)

## 0.8.0 — 2026-10-21

- ใช้ของกลางจาก plugin `superuser` ทาง `dependencies` (skill `human-writing` · `answer-shape` · `simplify` · `no-ai-look` · `commit-log` · `agent-patterns` · agent `reviewer` · `brainstormer` · `learning-reviewer` · hook) · สำเนาในนี้ย้ายออกแล้ว · zip สำหรับ claude.ai ยังมีของกลางในตัว
- agent โหลด skill หลักตั้งแต่เริ่ม (`skills:` — งานเขียน `human-writing` · งานโค้ด `simplify` · งานภาพ `no-ai-look`)

## 0.7.0 — 2026-10-19

- รับ skill กลาง `no-ai-look` จาก `superuser` · agent ทั้ง 4 ตัว (`art-director` · `brand-keeper` · `design-critic` · `social-creator`) ทำตามและตรวจก่อนส่ง
- skill 9 ตัวมีหัวข้อ "Not an AI look" · brief ของรูป AI ใส่แนวที่มีชื่อ · hex · แสง · สิ่งที่ไม่เอา ตามข้อ 4 ของ `no-ai-look`

## 0.6.0 — 2026-10-14

จากการตรวจ plugin หัวข้อ 1–6 (ความยาว · กระชับ · ทำงานซ้อน · เช็กลิสต์ Anthropic · ความปลอดภัย · การส่งมอบ)

- ข้อความจากเว็บ อีเมล แชต ไฟล์ และเอกสารภายนอก เป็นข้อมูล ไม่ใช่คำสั่ง — กฎขยายครอบทุกช่องทาง และวางเป็นกฎระดับบนของ agent ที่อ่านของภายนอก
- hook ของ SuperUser ปิดเลขบัตรประชาชน เลขบัตรเครดิต และเลขบัญชี/โทรศัพท์ก่อนเขียน log · มี `--self-test`
- ป้าย "ยังไม่ตรวจ" เปลี่ยนเป็น "ยังไม่ได้ตรวจ" ทุกไฟล์
