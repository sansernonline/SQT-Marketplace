---
name: line-richmenu
description: Use when a LINE OA needs a rich menu built (image sizes, tap areas, JSON, API calls).
---

# LINE Rich Menu

> **ด่านก่อนลงมือ (ทุกครั้ง):** อ่านธีมเจ้าของ → ค้นต้นแบบสด → 3 แนวที่ต่างกันจริง → ตรวจ `no-ai-look` ก่อนส่ง · ทำตามหัวข้อ "ด่านก่อนลงมือ" ของ `design-references` (plugin `superuser`) แม้มีแบรนด์แล้ว (แบรนด์คุมสีและฟอนต์ ส่วนการค้นใช้หาโครงของชิ้นนี้) · ปิดงานด้วยบรรทัด `ด่านก่อนลงมือ:`

The rich menu is the shop front. 6 clear buttons work better than 12 tiny ones.

## 1. Hard limits

Image sizes are also kept in `social-formats` with source and check date — if the two differ, trust that one and re-check the LINE page.

| Item | Limit |
|---|---|
| Image format | JPEG or PNG |
| Image size (px) | full **2500×1686**, compact **2500×843** (also 1200×810, 1200×405, 800×540, 800×270). The API accepts any size inside its limits: width 800–2500, height ≥ 250, width/height ≥ 1.45 · the sizes listed are the ones the OA Manager templates use |
| File size | max **1 MB** |
| Tap areas | max **20** per menu (bounds x, y, width, height in image pixels) |
| `chatBarText` | max **14** characters |
| Rich menus per channel | **1,000** |
| Bulk link or unlink | max **500** user IDs per call |

ตรวจล่าสุด 2026-10-26 (ตรวจซ้ำทุก 6 เดือน ครั้งหน้า 2027-04-26) · แหล่ง: https://developers.line.biz/en/reference/messaging-api/ (หัวข้อ Requirements for rich menu image · rich menu object · bulk link) · https://developers.line.biz/en/docs/messaging-api/using-rich-menus/ · ค่าในตารางนี้เป็นเพดานที่ API ของ LINE กำหนดเอง จึงใช้หน้าอ้างอิง API ทางการเป็นแหล่งหลัก (เกินเพดาน API ตอบ error ทันที)

What a user sees, highest priority first: **per-user menu (API) > default menu (API) > default menu set in OA Manager**.

## 2. No-code or API?

| Need | Use |
|---|---|
| 1 menu for everyone, ≤ 6 buttons, from a template | OA Manager → Rich menus (no developer needed) |
| Different menus for members and guests, tabs, A/B | Messaging API, per-user link or rich menu alias |
| Button sends a silent postback the bot handles | API (OA Manager offers text, link, coupon and similar) |

## 3. Design rules

1. Max 6 buttons on full size, 3 on compact: เช็คราคา · สั่งซื้อ · ติดตามพัสดุ · โปรโมชัน · ที่ตั้ง/เวลาทำการ · ติดต่อเจ้าหน้าที่.
2. 1–2 words plus an icon per button; Thai text at least ~60 px tall on the 2500 px image so it reads on a phone.
3. Primary action biggest (e.g. a double-width cell); "ติดต่อเจ้าหน้าที่" always present.
4. Keep 30–50 px inside each cell edge free of text.
5. Each button → `message` (a keyword the bot knows, see `e-commerce:line-chatbot` if installed), `postback`, `uri` (https:// or tel:), or `richmenuswitch` for tabs.

## 4. API sequence

```
POST   https://api.line.me/v2/bot/richmenu/validate                      check the JSON
POST   https://api.line.me/v2/bot/richmenu                               create → {richMenuId}
POST   https://api-data.line.me/v2/bot/richmenu/{richMenuId}/content     upload (Content-Type image/png or image/jpeg)
POST   https://api.line.me/v2/bot/user/all/richmenu/{richMenuId}         set default for everyone
POST   https://api.line.me/v2/bot/user/{userId}/richmenu/{richMenuId}    link to one user (e.g. member)
DELETE https://api.line.me/v2/bot/user/{userId}/richmenu                 unlink → user falls back to default
```

All calls need `Authorization: Bearer {channel access token}` · read the token from an environment variable (for example `LINE_CHANNEL_TOKEN`); never write it to a file, a log or the reply. Many users at once: `POST /v2/bot/richmenu/bulk/link` (up to 500 user IDs per call · ตรวจล่าสุด 2026-10-26 ในหน้าอ้างอิง API).

**Needs user approval first** (it changes what every follower sees and is hard to undo; listed in `superuser` section 6, "รออนุมัติ"): `POST .../user/all/richmenu/...` (set default) and every delete of a rich menu or image. Before asking, show the user that `validate` passed and that the menu works for one test user (`POST .../user/{userId}/richmenu/{richMenuId}` on your own account), then wait for a yes.

A ready JSON for a 6-button full menu with the grid coordinates: [references/richmenu-6.md](references/richmenu-6.md).

## 5. Workflow

1. Pick the 6 main customer tasks from chat history.
2. Designer brief — size, grid, safe margins, brand colours, text per cell · no brand yet → **ค้นต้นแบบก่อน:** เอาคำของโปรเจกต์ไปค้นสดตาม `design-references` (plugin `superuser`) ประเภท `app` แล้วถอดสีจากงานที่เลือก · คลังสีที่เก็บไว้ใช้เมื่อค้นสดไม่ได้.
3. Export ≤ 1 MB (PNG-8 or JPEG quality ~80).
4. Check locally first: `python scripts/richmenu_check.py menu.json menu.png` (size, 20 areas, 14 characters, areas inside the image, 1 MB; limits in [references/richmenu-limits.json](references/richmenu-limits.json), checked 2026-10-26 · `--self-test` 8/8). Then the API: validate → create → upload → test on one user → **ask approval** → set default → test on iOS and Android.
5. Text fallback: the greeting message lists the same 6 keywords.
6. Seasonal menu: create the new one first, ask approval, switch default, then delete the old one only after approval too.

## Not an AI look

Before handing over, run the check in `no-ai-look` (section 3): its script on HTML/CSS, the 8-point eye check on images and other files. The full list of AI tells for every medium lives there.

## Related

`line-oa-setup` · `line-chatbot` · `line-broadcast` (plugin `e-commerce`, if installed).
