---
name: video-editing
description: Use when editing video or audio with ffmpeg (ตัดต่อ, silences, loudness) or turning slides into video. Thai TTS narration → narration-th.
---

# video-editing — ตัด ต่อ ปรับเสียง และส่งออกวิดีโอ

อยู่ใน plugin `graphic-design` · ถ้อยคำเขียนตาม `human-writing` · agent ที่ทำงานนี้คือ `video-editor` · เลือกโปรแกรมตัดต่อแบบกดดูภาพ (CapCut · DaVinci Resolve) และค่าส่งออกต่อแพลตฟอร์มอยู่ใน `video-script-to-clip` `references/production-tools.md`

> **กฎข้อเดียว:** ทุกการแก้ไฟล์จบด้วยการวัดไฟล์ที่ได้ (ความยาวจาก `ffprobe` · ความดังจากรอบสองของ `loudnorm` · ภาพที่จุดตัด) ไม่ใช่เชื่อว่าคำสั่งรันผ่านแล้วผลถูก

## ใช้เมื่อ

- ตัดหัวท้าย ตัดช่วงพูดผิด หรือตัดช่วงเงียบนานออก
- ต่อหลายคลิปเป็นไฟล์เดียว
- ปรับความดังให้ได้ค่าที่แพลตฟอร์มกำหนด (podcast · YouTube · คลิปอบรม)
- แปลงแนวนอน 16:9 เป็นแนวตั้ง 9:16 · ดึงภาพปก · ส่งออกเป็น MP4 ที่เปิดได้ทุกที่
- ต่อสไลด์ HTML จาก `html-slide-deck` กับเสียงบรรยายเป็นวิดีโอไฟล์เดียว (บทเรียน podcast · คลิปอบรม) หัวข้อ "สไลด์กับเสียงบรรยายเป็นวิดีโอ"

## ไม่ใช้เมื่อ (ใช้ตัวอื่นแทนหรือคู่กัน)

| งาน | ใช้ |
|---|---|
| เขียน hook บท shot list | `video-script-to-clip` |
| ซับไทย (ถอดเสียง · ตรวจ · ฝัง) | `subtitles-th` |
| ไม่อยากอัดเสียงเอง: เสียงบรรยายไทยจากสคริปต์ (text-to-speech) ได้ซับและเวลาสไลด์ในรอบเดียว | `narration-th` |
| สไลด์ที่ต้องมีภาพเคลื่อนไหวในแผ่น | อัดหน้าจอตอนเปิดเด็ค หรือ HyperFrames หรือ Remotion (`production-tools.md` ข้อ 1) |
| แก้สี ตัดหลายแทร็กโดยดูภาพ ใส่เอฟเฟกต์ | คนตัดใน DaVinci Resolve หรือ CapCut (`production-tools.md` ข้อ 1) · agent เขียนเช็กลิสต์ให้ |
| คลิปที่สร้างจากโค้ดเป็นชุด (ราคา ข้อความเปลี่ยนตามข้อมูล) | HyperFrames หรือ Remotion (`production-tools.md` ข้อ 1) |

## ขั้นตอน

0. **ตรวจเครื่อง** `ffmpeg -version` · ไม่มี → การติดตั้งทั้งเครื่องอยู่ใน "รออนุมัติ" · ฟิลเตอร์ซับต้องมี libass (ดูใน `--enable-libass` ของบรรทัด configuration)
1. **ดูไฟล์ก่อนแตะ** `ffprobe -v error -show_entries format=duration:stream=codec_name,width,height,r_frame_rate -of compact in.mp4` · เก็บต้นฉบับไว้ ไฟล์ผลลัพธ์ใช้ชื่อใหม่เสมอ (`asset-organize`)
2. **ตัดช่วง** ตรงเฟรมต้องเข้ารหัสใหม่:
   `ffmpeg -ss 00:01:30 -i in.mp4 -t 40 -c:v libx264 -crf 20 -preset veryfast -c:a aac -b:a 192k out.mp4`
   ตัดเร็วด้วย `-c copy` ได้ แต่จุดตัดเลื่อนไปที่ keyframe ใกล้สุด (ทดสอบ 2026-10-24: ขอ 7 วินาที ได้ 7.13) ใช้เมื่อความเร็วสำคัญกว่าความตรง และบอกผู้ใช้ว่าคลาดได้
3. **ต่อคลิป** ทุกไฟล์ codec ขนาด และ fps เดียวกัน → concat demuxer ไม่ต้องเข้ารหัสใหม่:
   ไฟล์ `list.txt` บรรทัดละ `file 'a.mp4'` แล้ว `ffmpeg -f concat -safe 0 -i list.txt -c copy joined.mp4`
   ไฟล์ต่างชนิดกัน → เข้ารหัสทุกไฟล์ให้เหมือนกันก่อน (ข้อ 2 ไม่ใส่ `-ss`) แล้วค่อยต่อ
4. **ตัดช่วงเงียบ** วัดระดับเสียงก่อน `ffmpeg -i in.wav -af volumedetect -f null -` แล้ว
   `python scripts/silences.py in.mp4` ดูช่วงเงียบและเวลาที่จะเหลือ → พอใจแล้วใส่ `-o tight.mp4` · ไฟล์ผลลัพธ์มีอยู่แล้ว สคริปต์ปฏิเสธและเสนอชื่อใหม่ (`tight-v02.mp4`) · ใส่ `--force` เฉพาะเมื่อผู้ใช้สั่งให้ทับ (กฎเดียวกันใน `loudnorm2.py` และ `slides_to_video.py`)
   `--noise` ตั้งต่ำกว่าเสียงพูดเบาสุดแต่สูงกว่าเสียงพื้นห้อง (ค่าตั้งต้นของสคริปต์ -35 dB · ของ ffmpeg เอง -60 dB ซึ่งเข้มเกินสำหรับห้องอัดทั่วไป) · `--min` ช่วงเงียบสั้นสุดที่ตัด (0.7 วินาที · ffmpeg ตั้ง 2 วินาที) · `--pad` เว้นขอบช่วงพูด (0.15 วินาที) กันพยางค์แรกและท้ายขาด
   ช่วงพูดผิดตัดด้วยมือตามเวลาที่ผู้ใช้จดมา ไม่เดาจากความเงียบ
5. **ปรับความดัง** `python scripts/loudnorm2.py in.wav out.wav --target <LUFS> --tp <dBTP>` (LUFS คือหน่วยวัดความดังเสียงทั้งไฟล์) (ไฟล์วิดีโอ: คัดลอกภาพเดิม เข้ารหัสเสียงใหม่) · รอบแรกวัด รอบสองใส่ค่าที่วัดได้ · อ่านบรรทัด `Normalization Type`:
   - `Linear` = เพิ่มหรือลดทั้งไฟล์เท่ากัน ช่วงดังเบาเหมือนเดิม
   - `Dynamic` = ffmpeg บีบช่วงดังเบาให้ถึงเป้า เกิดเมื่อช่วงความดัง (LRA) ที่วัดได้เกิน `--lra` หรือเป็น 0 (ทดสอบ 2026-10-24: LRA 5.9 ได้ Linear · 11.9 และ 0 ได้ Dynamic) และเมื่อไม่ได้ใส่ค่า `measured_*` ครบ 4 ตัว · อยากได้ Linear ให้เพิ่ม `--lra` หรือยอมรับแบบ Dynamic แล้วฟังช่วงที่ดังสุด
   - โหมด Dynamic ทำงานที่ 192 kHz จึงต้องกำหนด `-ar` ของไฟล์ผลลัพธ์ (สคริปต์ตั้ง 48000 ให้) · ค่าตั้งต้นของ ffmpeg คือ I -24 · LRA 7 · TP -2 ไม่ใช่ค่าของแพลตฟอร์มใด สคริปต์จึงให้ใส่เป้าเอง
   ค่าเป้าตามแพลตฟอร์มอยู่ในตารางหัวข้อ "ค่าความดังต่อแพลตฟอร์ม"
6. **แปลงสัดส่วน** แนวนอนเป็นแนวตั้ง 1080×1920:
   ครอปกลางภาพ `-vf "crop=ih*9/16:ih,scale=1080:1920"`
   เก็บภาพเต็มพร้อมพื้นหลังเบลอ `-filter_complex "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:5[bg];[0:v]scale=1080:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v]" -map "[v]" -map 0:a`
   ข้อความและซับต้องอยู่ใน safe zone ของแพลตฟอร์ม (`social-formats`)
7. **ภาพปก** `ffmpeg -ss 00:00:03 -i in.mp4 -frames:v 1 -q:v 2 thumb.jpg`
8. **ส่งออก** H.264 กับ AAC · `-pix_fmt yuv420p` (เปิดได้ในเครื่องเล่นทั่วไป) · `-movflags +faststart` (เล่นบนเว็บได้ก่อนโหลดครบ) · ขนาดและ fps ตาม `production-tools.md` ข้อ 3
9. **วัดไฟล์ที่ได้** ความยาวภาพกับเสียง `ffprobe -v error -show_entries stream=codec_type,duration -of csv=p=0 out.mp4` · ความดัง `python scripts/loudnorm2.py out.mp4 --measure` · ดึงภาพที่จุดตัดมาดู · แล้วให้ผู้ใช้ฟังช่วงที่ตัดจริง

## สไลด์กับเสียงบรรยายเป็นวิดีโอ

เวลาของทุกสไลด์มาจาก `data-at` ในเด็คที่เดียว แล้วพิสูจน์จากไฟล์ที่ได้ว่ายาวเท่าเสียง และภาพที่เวลาสุ่มเป็นแผ่นที่ควรขึ้น

1. **ตั้งเวลาในเด็ค** ทุก `<section class="slide">` มี `data-at="m:ss"` คือเวลาที่ควรถึงแผ่นนั้น (ความหมายเดียวกับนาฬิกาในหน้าต่างผู้พูดของ `html-slide-deck`) · เอาเวลาจากเสียงที่ตัดเสร็จแล้ว ไม่ใช่เวลาประมาณในสคริปต์ · เสียงที่สร้างด้วย `narration-th` มี `data_at` ของทุกสไลด์ใน `cues.json` แล้ว
2. **ทำภาพทีละแผ่น** `python <html-slide-deck>/scripts/check_deck.py deck.html --out frames` ได้ `p01.png …` ขนาด 1920×1080 (ต้องมี Playwright และ Pillow) · แผ่นที่มี animation เพิ่ม `--wait` ให้ภาพเป็นสถานะสุดท้าย · เด็คที่ยังเป็นไฟล์เนื้อหาต้อง `build_deck.py` ก่อน
3. **เสียงต้องเสร็จก่อน** ตัดและปรับความดังตามข้อ 4–5 ก่อนตั้ง `data-at` ตัดเสียงทีหลังแล้วสไลด์จะเลื่อนทั้งเด็ค
4. **ดูตารางเวลาแล้วสร้าง** `python scripts/slides_to_video.py deck.html frames narration.wav --check` · สคริปต์หยุดพร้อมบอกเหตุเมื่อ `data-at` ไม่เพิ่มขึ้นทุกแผ่น · จำนวนภาพไม่เท่าสไลด์ · แผ่นสุดท้ายเริ่มหลังเสียงจบ · ผ่านแล้วตัด `--check` ใส่ `-o episode.mp4` ได้ H.264 กับ AAC 30 fps ยาวเท่าเสียงพอดี
5. **ตรวจไฟล์** ความยาวภาพกับเสียงจาก `ffprobe` · เปิดดูต้นแผ่น 3 จุด · ฟังเสียงว่าเป็นเสียงบรรยายจริง · ใส่ซับต่อด้วย `subtitles-th`

| กับดัก | สาเหตุ | สคริปต์ทำให้แล้ว |
|---|---|---|
| แผ่นสุดท้ายขึ้นแป๊บเดียว | concat demuxer ไม่ใช้ `duration` ของภาพสุดท้าย ถ้าไม่ใส่ชื่อไฟล์นั้นซ้ำอีกบรรทัดท้ายรายการ (ffmpeg wiki Slideshow) | ใส่ภาพสุดท้ายซ้ำ |
| วิดีโอยาวเกินเสียง | `-shortest` อย่างเดียวยังเหลือภาพท้ายเมื่อมี filter (ทดสอบ 2026-10-24: ได้ 181.67 วินาทีจากเสียง 180) | ใช้ `-t` เท่าความยาวเสียง |
| ffmpeg ไม่ยอมเปิดรายการภาพ | path เต็มในไฟล์รายการต้องใช้ `-safe 0` | ใส่ให้แล้ว |

ทดสอบ 2026-10-24 กับเด็คตัวอย่าง 13 แผ่นของ `html-slide-deck` และเสียง 180 วินาที: ภาพและเสียงยาว 180.00 วินาทีเท่ากัน · สุ่ม 7 เวลาแล้วภาพตรงแผ่นทุกจุด · ให้เสียงสั้นเกิน (75 วินาที) สคริปต์หยุดเพราะแผ่นสุดท้ายเริ่มที่ 165 วินาที

## ค่าความดังต่อแพลตฟอร์ม

Loudness targets change and differ per destination, so this skill stores none. Destinations to look up: Apple Podcasts · Spotify (music, podcast, podcast ads) · YouTube · TikTok · Audible (ACX) · broadcast (EBU R 128). For each one find the integrated loudness target, the true peak ceiling, and whether the platform publishes a figure at all. Some platforms publish nothing, and secondary sources quote numbers the platform never wrote, so say which kind each value is. Note also that ACX uses dB RMS, a different unit from LUFS.

Look up live (WebSearch/WebFetch) before using it; if the page will not open, mark the value (รอยืนยัน). Official sources: the platform's own help or specification pages (Apple Podcasts Connect · Spotify for Artists loudness page · ACX audio submission requirements · EBU R 128).

ปลายทางที่ไม่ประกาศค่า ใช้ -16 LUFS · -1.5 dBTP (ค่าตั้งต้นของ `loudnorm2.py`) เพราะอยู่ในช่วงของ Apple และไม่ดังจนถูกลดระดับ (อนุมาน) แล้วบอกผู้ใช้ว่าเป็นค่าที่เลือกเอง · ลงหลายที่ด้วยไฟล์เดียว ตั้งความดังตามช่องทางหลัก และใช้เพดาน true peak ที่ต่ำสุดของทุกช่องทาง

## ตัวอย่างจริง

- **โจทย์:** เสียง 11 วินาทีที่มีช่วงเงียบ 2 ช่วง (2 กับ 1 วินาที) ในไฟล์วิดีโอ และเสียงที่ดังเบาต่างกันให้ปรับเป็น -16 LUFS
- **สิ่งที่ทำ:** `silences.py gaps.mp4 -o tight.mp4` · `loudnorm2.py varied2.wav out.wav`
- **ผล:** เจอช่วงเงียบ 3.00–5.00 และ 8.00–9.00 ตรงตามที่สร้าง · เหลือ 8.60 วินาทีเท่าที่คำนวณ (ภาพ 8.60 · เสียง 8.62) · ความดังได้ -15.6 LUFS แบบ Linear · ไฟล์วิดีโอ `--target -14` ได้ -14.0 LUFS โดยภาพไม่ถูกเข้ารหัสใหม่ (ตรวจจริง 2026-10-24 · ffmpeg 9.0.2 บน Windows)

## ตรวจก่อนส่ง

- [ ] เครื่องใหม่หรือแก้สคริปต์: `python scripts/<ชื่อ>.py --self-test` ของ `silences` · `loudnorm2` · `slides_to_video` · `outguard` (ตัวกันเขียนทับที่ 3 ตัวแรกใช้ร่วมกัน · `tts_cues` ย้ายไป `narration-th` 2026-10-28) ผ่าน (ไม่มี ffmpeg จะข้ามส่วนที่วัดไฟล์จริงและบอกว่าข้าม · ทดสอบ 2026-10-26 ffmpeg 9.0.2 ผ่านทั้ง 4 ตัว · 2026-10-28 ผ่านครบ 5 ตัวหลังเพิ่มตัวกันเขียนทับ นับรวม `tts_cues` ก่อนแยก)
- [ ] ต้นฉบับยังอยู่ · ไฟล์ผลลัพธ์ชื่อใหม่ · คำสั่งที่ใช้จดไว้ให้รันซ้ำได้
- [ ] ความยาวจาก `ffprobe` ตรงกับที่ตั้งใจ (ภาพกับเสียงต่างกันไม่เกิน 0.1 วินาที)
- [ ] ความดังรวมห่างจากเป้าไม่เกิน 1 LU และ true peak ไม่เกินเพดาน · บอกว่า Linear หรือ Dynamic
- [ ] ดึงภาพที่จุดตัดอย่างน้อย 1 จุดมาดู · บอกผู้ใช้ว่าต้องฟังนาทีไหน
- [ ] วิดีโอจากสไลด์: เปิดดูต้นแผ่นอย่างน้อย 3 จุดแล้วภาพตรงแผ่น
- [ ] เพลง ฟุตเทจ และฟอนต์มีใบอนุญาตสำหรับช่องทางนั้น (`production-tools.md` ข้อ 2 และ 5)

## ที่มา

- ffmpeg Filters Documentation: [loudnorm](https://ffmpeg.org/ffmpeg-filters.html#loudnorm) (ค่าตั้งต้น · 2 รอบ · `linear` ต้องมี `measured_*` ครบ · ทำงานที่ 192 kHz) · [silencedetect](https://ffmpeg.org/ffmpeg-filters.html#silencedetect) · ชื่อคีย์ JSON `input_*` มาจาก source `libavfilter/af_loudnorm.c` รุ่น n9.0.2 ส่วนการใส่ค่ากลับเป็น `measured_*` เป็นวิธีที่ใช้กันทั่วไป เอกสารไม่ได้เขียนตัวอย่าง (ดู 2026-10-24)
- ffmpeg Formats Documentation: [concat demuxer](https://ffmpeg.org/ffmpeg-formats.html#concat) (`file` · `duration` · `-safe 0` สำหรับ path เต็ม · ทุกไฟล์ต้อง codec เดียวกัน) · ffmpeg Wiki [Slideshow](https://trac.ffmpeg.org/wiki/Slideshow#Concatdemuxer) (ภาพสุดท้ายต้องใส่ซ้ำโดยไม่มี `duration`) (ดู 2026-10-24)
- `html-slide-deck` `assets/shell.html`: `data-at="m:ss"` คือเวลาที่ควรถึงแผ่นนั้น · `scripts/check_deck.py` ถ่ายภาพที่ 1920×1080 (อ่าน 2026-10-24)
- ค่าความดัง: [Apple Podcasts audio requirements](https://podcasters.apple.com/support/893-audio-requirements) · [Spotify loudness normalization](https://support.spotify.com/us/artists/article/loudness-normalization/) · [Spotify audio ad specs](https://ads.spotify.com/en-US/ad-specs/audio-ad-specs/) · [YouTube stable volume](https://support.google.com/youtube/answer/14106294) · [ACX audio submission requirements](https://help.acx.com/s/article/acx-audio-submission-requirements) · [EBU R 128](https://tech.ebu.ch/docs/r/r128.pdf) (ดูทุกหน้า 2026-10-24)
- ผลทดสอบของ skill นี้: หัวข้อ "ตัวอย่างจริง" ด้านบน (รันกับไฟล์ทดสอบที่สร้างขึ้นเอง 2026-10-24 · ffmpeg 9.0.2 บน Windows)
