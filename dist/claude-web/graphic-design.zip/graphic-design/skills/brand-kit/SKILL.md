---
name: brand-kit
description: Use when starting a brand or needing a style guideline
argument-hint: '[brand or company name]'
---

# Brand Kit

> **Pre-work gate (every time):** read the content and write the `เนื้อหา:` brief → read the owner's theme → search live references → 3 genuinely different directions → run the `no-ai-look` check before sending · follow the "ด่านก่อนลงมือ" (pre-work gate) section of `design-references` (plugin `superuser`) even when a brand exists (the brand controls colour and fonts, while the search finds the structure of this piece) · close the work with a `ด่านก่อนลงมือ:` line

One folder, one README, everything the brand needs to look like itself.

For app or product screens, the `software-development` plugin's `design-system` skill (if installed) covers writing tokens for code (CSS variables, Tailwind theme) and `ui-craft` covers reading existing screens; without it, keep to this skill. This skill is for marketing, social and print. A software project's one-off visuals (logo, poster, LINE art) are lighter work in `software-development:graphic-design`; once the brand needs a full kit or campaign, work here.

## Workflow

0. **Search for references first:** take the project's keywords and search live as `design-references` (plugin `superuser`) says, type `logo` (use `color` for colours), then pull the colours from the piece you choose · use the stored palette library only when a live search is not possible
1. **Collect** — brand name (Thai and English), 1-sentence positioning, audience, 3 personality adjectives, existing logo files, and 2 competitors to look different from
2. **Copy the folder template** in [kit-template.md](references/kit-template.md) to `brand-kit/v1/`
3. **Logo** — collect or request the 4 versions (full colour · reversed white · solid black · solid white), set clear space and minimum size (below)
4. **Colour** — assign roles, not just swatches (table below); run the contrast check on every text/background pair you will actually use
5. **Type** — pick 1 Thai+Latin pairing from [thai-fonts.md](references/thai-fonts.md), confirm the licence file, set the scale
6. **Imagery** — 3 adjectives, plus 1 on-style and 1 off-style example. **Voice** — not 3 adjectives: 1 before/after Thai pair written by the owner (how they would say it vs how a stranger would) · particles ครับ/ค่ะ yes or no · `คุณ` or no pronoun · 1 register from `human-writing` `references/thai-grammar.md` section 4
7. **Write the README** — the 5 rules that must never break, each with a 1-line reason
8. **Tag** `v1` and log changes in `CHANGELOG.md`; any change to colour, logo or font is `v2`

## Colour roles

| Role | Share of layout | Job | Rule |
|---|---|---|---|
| Background / neutral | ~60% | Canvas | Off-white or near-black, not pure #FFFFFF everywhere |
| Primary | ~30% | Recognition | The colour people name the brand by |
| Accent | ~10% | Action, price, call to action (CTA) | Use sparingly. If it is everywhere, it stops drawing the eye |
| Text | — | Reading | Must pass 4.5:1 on every background it sits on |
| Semantic (optional) | — | Sale, warning | Do not reuse accent for "error" |

**Contrast check (Web Content Accessibility Guidelines (WCAG) 2.2 AA, criterion 1.4.3):** normal text ≥ **4.5:1**; large text (≥ 18 pt, or ≥ 14 pt bold) ≥ **3:1**. Logos are exempt but should still be legible. Check pairs with any WCAG contrast checker (WebAIM Contrast Checker, a Figma or Canva contrast plugin, browser DevTools).

Worked example (a Thai café palette with 7 pairs, where white on amber fails and amber buttons carry dark text): [references/contrast-example.md](references/contrast-example.md)

## Type scale

- 1 Thai+Latin family for headlines and 1 for body (it can be the same family in 2 weights)
- Scale ratio 1.25 (major third) from a 16 px body: **16 · 20 · 25 · 31 · 39 · 49** px. On a 1080 px-wide social canvas: body 32–40 px, headline 72–120 px
- Thai body line-height **1.5–1.7** (stacked vowels and tone marks collide below about 1.4); Latin-only 1.4–1.5 (ค่ากลางอยู่ใน `human-writing` `references/thai-line-breaking.md`)
- Thai glyphs look smaller than Latin at the same size in many fonts — compare x-height and bump Thai 5–10% if the pairing looks uneven (judge by eye at real size)
- Looped Thai (มีหัว) for body and small text; loopless (ไม่มีหัว) for headlines and short display text

## Logo rules

| Rule | Default to write in the kit |
|---|---|
| Clear space | Height of 1 defined element (e.g. the symbol's height, or the cap height of the wordmark) on all 4 sides |
| Minimum size | Digital: test the wordmark at 24 px high and raise until it reads; print: about 15 mm wide — confirm with a test print |
| Backgrounds | Full colour on light; reversed on primary or dark; one-colour on photos only with a contrast overlay |
| Never | Stretch, rotate, recolour outside the kit, add shadow or outline, place on busy photo areas, retype the wordmark in another font |

Draw the clear-space box on a page in the kit (`logo/usage.png`) — people follow a picture, not a sentence.

## Rules

- Everything in the kit is a decision with a 1-line reason
- Not in the kit = not brand. A new colour enters only with a new kit version, never through a one-off post
- Confirm every font licence from the licence file in the download, not from a blog
- Keep the kit beside the work: `asset-organize` puts it at `00-brand-kit/`

## เขียนเป็นเอกสาร (full brand guideline)

Use this when an organisation or team needs a full guide (tone of voice, key messages, approval rules, file storage) or must sync colours into design tokens · a small shop is fine with the Workflow above

- **One file:** `docs/brand-guidelines.md`, which every person and every agent reads from one place · its colours and fonts are the source, and the token file follows them
- Start from `templates/brand-guidelines-starter.md` · put `(รอยืนยัน)` (awaiting confirmation) for any data you do not have, and do not invent it
- Sync tokens: `node scripts/sync-brand-to-tokens.cjs` · check a file: `scripts/validate-asset.cjs` · compare image colours: `scripts/extract-colors.cjs` · brand summary to paste into a prompt: `scripts/inject-brand-context.cjs`
- Full steps, topic/source-file table, limits and checklist: [references/brand-guidelines.md](references/brand-guidelines.md)

## Related

- `style-consistency` — the per-campaign style lock that sits under the kit
- `design-review` — point 7 checks every asset against this kit
- `asset-organize` — folder and naming

## เรียกเป็นคำสั่ง

`/graphic-design:brand-kit [brand or company name]`

Run `brand-kit` with the `brand-keeper` agent for: **$ARGUMENTS**

Ends with a README you can read in 5 minutes and a v1 version tag.

## References

- [`references/sources.md`](references/sources.md) — open to re-check dated figures, prices and rules, and their sources
