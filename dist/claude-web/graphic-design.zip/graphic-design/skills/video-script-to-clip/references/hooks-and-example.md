# Hook examples, per-shot brief and worked 12 s clip · video-script-to-clip

Open when writing the hook, writing per-shot generation briefs, or wanting a finished shot-list example.

## Hook patterns (first 3 seconds)

| Pattern | Example (café matcha) |
|---|---|
| Show the result | Close-up pour of matcha into milk, layers forming |
| Call out the viewer | "คนทำงานสีลม ร้อนแบบนี้…" |
| Problem first | Sweat on forehead, sun, "บ่ายสองโมงแล้วง่วงมาก?" |
| Surprising number | "ซื้อ 1 แถม 1 ทั้งเดือน" on screen at frame 1 |
| Before → after | Plain glass → finished layered drink in one cut |
| Question | "รู้ไหมทำไมมัทฉะต้องตีน้ำร้อน 80 องศา?" |

## Per-shot generation brief

Subject · action/motion (what moves, how fast) · camera (static, pan, push-in, orbit) · duration · aspect ratio · style block reference · first-frame and last-frame description (for continuity between shots) · negatives (text, logos, warped hands).

## Worked example — 12 s offer clip

| # | Time | Visual | Camera | On-screen text | Voice-over |
|---|---|---|---|---|---|
| 1 | 0–2.5 s | Matcha poured over milk and ice, layers forming | Macro, static | "ร้อนแบบนี้ ต้องมัทฉะเย็น" | (sound: ice) |
| 2 | 2.5–5 s | Office worker takes first sip, eyes close | Medium, slow push-in | — | "บ่ายนี้ เติมความสดชื่นหน่อย" |
| 3 | 5–9 s | Two glasses slide together on the counter | Top-down | "ซื้อ 1 แถม 1 · 1–12 เม.ย." | "ซื้อหนึ่งแถมหนึ่ง ถึงสิบสองเมษา" |
| 4 | 9–12 s | Logo + LINE ID on cream background, glass beside | Static | "แอด LINE @matcha26 รับโค้ด" | "แอดไลน์รับโค้ดเลย" |

Check shot 3 text (on-screen marketing text, read while watching, so ÷ 12 not ÷ 17): "ซื้อ 1 แถม 1 · 1–12 เม.ย." = 23 counted characters (base letters + digits + spaces + symbols) ÷ 12 ≈ 1.9 s; it is the offer, so hold ≥ 2.5 s → on screen 4 s, fine.
