---
name: social-formats
description: Use when designing for Facebook, Instagram, TikTok, YouTube, LINE OA or X. Sizes, ratios, safe zones.
argument-hint: <path to master asset> [platforms needed]
---

# Social Formats

> **ด่านก่อนลงมือ (ทุกครั้ง):** อ่านธีมเจ้าของ → ค้นต้นแบบสด → 3 แนวที่ต่างกันจริง → ตรวจ `no-ai-look` ก่อนส่ง · ทำตามหัวข้อ "ด่านก่อนลงมือ" ของ `design-references` (plugin `superuser`) แม้มีแบรนด์แล้ว (แบรนด์คุมสีและฟอนต์ ส่วนการค้นใช้หาโครงของชิ้นนี้) · ปิดงานด้วยบรรทัด `ด่านก่อนลงมือ:`

Right size first, design second. A beautiful post in the wrong ratio gets cropped by the platform, and the crop always takes the headline.

All pixel sizes and safe zones are in [platform-sizes.md](references/platform-sizes.md), each with its source and check date. This is the owner of these numbers; `software-company:graphic-design` and `line-richmenu` point here and keep only a fallback copy. Platforms change specs without notice — re-open the source link before a paid campaign.

## Workflow

0. **ค้นต้นแบบก่อน:** เอาคำของโปรเจกต์ไปค้นสดตาม `design-references` (plugin `superuser`) ประเภท `social` แล้วถอดสีจากงานที่เลือก · คลังสีที่เก็บไว้ใช้เมื่อค้นสดไม่ได้
1. **List placements** the campaign really needs (from the `campaign-set` matrix) — only the platforms the audience uses, not every platform
2. **Group by ratio** — most needs fit 4 canvases: **9:16** (stories, reels, TikTok, Shorts), **4:5** (feed), **1.91:1 / 16:9** (link, X, YouTube), **special** (LINE rich menu, covers)
3. **Design the master** at the largest canvas of the main ratio (e.g. 1440 × 2560 for 9:16 if ads, 1080 × 1920 for organic)
4. **Overlay the safe zone** before placing text — template from the platform where available (Meta Ads Manager safe-zone guardrail, TikTok safe-zone template)
5. **Derive** other ratios by re-composing, not stretching: move the subject, re-flow the text
6. **Name** each export with the platform and format code (`asset-organize`)
7. **Preview on a phone** — upload privately or use the platform's preview; check what the UI covers

## The four canvases

| Canvas | Size to design | Used by |
|---|---|---|
| 9:16 vertical | 1080 × 1920 (organic) · 1440 × 2560 (Meta ads recommendation) | Instagram (IG)/Facebook (FB) Stories and Reels, TikTok, YouTube Shorts |
| 4:5 portrait feed | 1080 × 1350 (organic) · 1440 × 1800 (Meta ads recommendation) | IG and FB feed |
| 1:1 square | 1080 × 1080 | FB/IG feed fallback, LINE rich message (1040 × 1040) |
| Wide | 1200 × 630 (link, 1.91:1) · 1600 × 900 or 1920 × 1080 (16:9) | FB link preview (1200 × 630), LinkedIn link preview (1200 × 627, same 1.91:1), X, YouTube |

ตรวจล่าสุด 2026-10-06 · แหล่ง: https://www.facebook.com/business/ads-guide/update/image · details per platform in [platform-sizes.md](references/platform-sizes.md)

## Safe zones that matter most

| Placement | Keep text and logos out of |
|---|---|
| Meta Stories and Reels (9:16) | Top **14%**, bottom **35%**, **6%** each side |
| TikTok (9:16) | On 1080 × 1920: top **240 px**, bottom **660 px**, **120 px** each side, plus a **180 px** strip on the right over the lower 1080 px (buttons) — TikTok's in-feed template, scaled from 720 × 1280; longer captions take more room |
| YouTube Shorts (9:16) | On 1080 × 1920: top **288 px**, bottom **672 px**, left **48 px**, right **192 px** (Google Ads figure for ads in Shorts · using it for ordinary Shorts is our inference, no official organic figure found) |
| YouTube channel banner | Everything outside the centre 1235 × 338 of a 2048 × 1152 canvas (official page only · รอยืนยัน) |
| Facebook page cover | Outer edges — mobile and desktop crop differently; keep text in the centre |
| LinkedIn profile cover | Bottom-left, where the profile photo overlaps |
| LINE OA profile | Corners — the image is shown in a circle |

ตรวจล่าสุด 2026-10-06 (Meta) · 2026-10-26 (TikTok · YouTube) · แหล่ง: https://www.facebook.com/business/ads-guide/update/image/instagram-story · https://ads.tiktok.com/help/article/tiktok-auction-in-feed-ads (ไฟล์แม่แบบ In-Feed) · https://support.google.com/google-ads/answer/9128498 · https://support.google.com/youtube/answer/10456525 · ตัวเลข TikTok และ Shorts ตรงกับคู่มือที่ไม่ใช่ทางการอีก 2 แหล่งต่อแพลตฟอร์ม (รายการใน platform-sizes.md)

## Rules

- Quote numbers only from the reference file or the platform's own page — third-party "size guides" fall behind
- Design at the recommended size; never upscale a small export
- Text on 9:16 sits in the middle band. The bottom-35% rule is the one most often broken
- Thai text needs more vertical room than Latin (tone marks above, vowels below) — leave extra top margin in tight headline boxes
- Keep file sizes under the limit in the reference (the LINE rich menu 1 MB limit is the one people hit most)
- Facebook link previews and LinkedIn link posts crop to 1.91:1 — a 1:1 image there loses top and bottom

## Worked example

Brief: a café promotes a new drink on IG feed, IG story, TikTok and LINE OA.

| Placement | Canvas | Export name |
|---|---|---|
| IG feed | 1080 × 1350 (4:5) | `matcha26-hero-ig-feed45-v01-th.jpg` |
| IG story | 1080 × 1920, text inside middle band (y 269–1248 px) | `matcha26-hero-ig-story-v01-th.jpg` |
| TikTok video | 1080 × 1920, captions above the bottom caption area | `matcha26-clip-tt-video-v01-th.mp4` |
| LINE OA rich message | 1040 × 1040 | `matcha26-hero-line-richmsg-v01-th.jpg` |

Story middle band: 1920 × 14% = 269 px from top; 1920 × 35% = 672 px from bottom → usable to y = 1248.

## Not an AI look

Before handing over, run the check in `no-ai-look` (section 3): its script on HTML/CSS, the eye check (3.2) on images and other files.

## Related

- `campaign-set` — which placements, in what order
- `asset-organize` — format codes in file names
- `video-script-to-clip` — captions and safe zones in video
- `software-company` `graphic-design` (if installed) — print sizes and LINE rich menu layout for product work

## เรียกเป็นคำสั่ง

`/graphic-design:social-formats <path to master asset> [platforms needed]`

Run `social-formats` and `campaign-set` derivation steps on: **$ARGUMENTS**

Never stretches an image. Every derived file has the platform and format in its name.
