---
name: campaign-set
description: Use when one campaign needs assets for many platforms
argument-hint: <campaign idea in one sentence>
---

# Campaign Set

> **ด่านก่อนลงมือ** (pre-work gate, every time): read the owner theme → search live references → 3 directions that really differ → check `design-gate/no-ai-look` before sending. Follow the "ด่านก่อนลงมือ" section of `design-gate/design-references` (plugin `superuser`) even when a brand exists (the brand controls colour and fonts; the search is for the layout of this piece). Close the work with the line `ด่านก่อนลงมือ:`

1 concept, every format it needs, in the right order. 5 one-off designs are not a campaign. 1 idea shown 5 ways is.

## Workflow

1. **Campaign card** — fill the card below. If you cannot write the 1-sentence summary, stop and get it from the owner
2. **Asset matrix** (the table of every asset needed) — 1 row per placement, using [asset-matrix-template.md](references/asset-matrix-template.md). Sizes come from `social-formats`
3. **Cut** — remove any row that does not serve the sentence or the audience's channels
4. **Style lock** — **ค้นต้นแบบก่อน:** run the project's keywords through a live search per `design-gate/design-references` (plugin `superuser`), type `social`, then pull the colours from the chosen work · use the stored palette bank only when live search is unavailable · then write or reuse a style lock sheet (`style-consistency`) before any generation or shoot
5. **Master first** — design the hero at the main placement's ratio (the one that carries most of the campaign), at its largest canvas. Get it approved before deriving anything. Then derive tallest to widest
6. **Derive in order** — stills by ratio (9:16 → 4:5 → 1:1 → wide) → covers and banners → motion and video last, built from the still's look
7. **Name** every file with the `asset-organize` pattern, putting the matrix ID in its optional `<id>` token
8. **Ship gate** (final check before posting) — each asset passes `design-review`, has its alt text (1 Thai line: what is seen plus the text on the image), its promo claims pass `copy-claims-check`, and its matrix row is ticked. No tick, no post

## Campaign card

| Field | Example |
|---|---|
| One sentence | "Our new matcha drink is the calm way to cool down this hot season." |
| Audience | Office workers 22–35 near Silom, follow us on Instagram (IG) and LINE |
| One action | Order at the counter or LINE OA with code `MATCHA26` |
| Offer and dates | Buy 1 get 1, 1–12 April |
| Mandatory items | Logo, price, LINE OA ID, promo terms line |
| Tone | Calm, fresh, not shouting |
| Approver | Owner (ชื่อ), 24 h turnaround |

## Derivation order — why

| Order | Asset | Reason |
|---|---|---|
| 1 | Master hero at the main placement's ratio (here 4:5; 9:16 if the story is the main placement) | Design where the text area is tightest. If it works here, it works on the others |
| 2 | Other still ratios | Rearrange the same elements. Never stretch |
| 3 | Covers, banners, rich menu | Wide or special shapes reuse the hero's parts |
| 4 | Carousel and secondary posts | Same style, new content |
| 5 | Motion and video | Animate approved stills. Changing the look in video breaks the set |

## Rules

- Derive, do not redesign. Keep the same type, colours, subject and layout logic across rows
- Mandatory items (price, terms, ID) appear identically on every asset — copy them from the card, never retype them
- Thai promo text: check numbers and dates against the card on every row. A wrong date on 1 platform is the most common campaign error
- Deliver the matrix as a checklist file the team ticks through, saved in the campaign's `02-exports/` folder

## Not an AI look

Before handing over, run the check in `design-gate/no-ai-look` (section 3): its script on HTML/CSS, the eye check (3.2) on images and other files.

## Related

- `social-formats` — sizes and safe zones per row
- `style-consistency` — the look shared by all rows
- `video-script-to-clip` — V rows
- `design-review` — the ship gate
- `copy-claims-check` — wording of offers and claims before posting
- `line-sticker` — when the campaign includes a LINE sticker set
- `asset-organize` — names and folders

## เรียกเป็นคำสั่ง

`/graphic-design:campaign-set <campaign idea in one sentence>`

Run `campaign-set` with the `social-creator` and `brand-keeper` agents for: **$ARGUMENTS**

Delivers the asset matrix as a checklist. An asset counts as done only after it passes design-review.

## References

- [`references/worked-example.md`](references/worked-example.md) — open to see a 6-row matrix and a file name
