# playbook · video — วิดีโอสั้นและงาน motion

ใช้เมื่อ: Reels · TikTok · Shorts · วิดีโอโฆษณา · ข้อความเคลื่อนไหว · โลโก้เคลื่อนไหว
skill หลัก: `video-script-to-clip` · `motion-basics` · `style-consistency`

## ขั้นตอน (คัดลง todo ตรงตัว)

1. เขียนข้อความหลักและ hook 3 วินาที · ใคร: `social-creator` ตัวใหม่ (ข้อความ hook สคริปต์) · ส่วน shot list motion และ brief ทีละช็อตเป็นของ `art-director`
2. ทำ shot list ตาม `video-script-to-clip` — ภาพ ข้อความบนจอ เสียง เวลา · ใคร: `art-director` ตัวใหม่
3. ตั้งจังหวะ motion ตาม `motion-basics` — กำหนดเวลาเป็นมิลลิวินาที · เลือกเส้น easing (จังหวะเร่งและชะลอ) · ข้อความบนจออยู่นานพอให้อ่านทัน · ใคร: `art-director` ตัวใหม่
4. เขียน brief ทีละช็อตสำหรับเครื่องมือวิดีโอหรือการถ่ายด้วยมือถือ · ใคร: `art-director` ตัวใหม่
5. ตรวจว่าซับไทยอ่านทันที่ความเร็วจริง และข้อความไม่ตกนอก safe zone ของแพลตฟอร์ม · ใคร: `design-critic` ตัวใหม่ (อ่านอย่างเดียว · ไม่แก้ไฟล์)

## จบเมื่อ

shot list และ brief ครบทุกช็อต และซับไทยผ่านการตรวจความเร็วอ่าน
