# playbook · brand-setup — set up or rebuild a brand kit

Use when: starting a new brand · rebranding · every post looks like a different company
Main principles: [`design-principles`](../../design-principles/SKILL.md) · logo [`logo.md`](../../design-by-type/references/logo.md) + [`meaning-first.md`](../../design-by-type/references/meaning-first.md) · superuser `design-gate/parts/design-method/guide.md`
Main skills: `brand-kit` · `icon-design` · `design-review` · agent `brand-keeper`

## ขั้นตอน (Steps) (copy into the todo exactly)

1. Gather raw material (the old logo · past work · the customer group), then write the 7-field `เนื้อหา:` brief per `design-method` steps 1–4 and save it in `DESIGN.md`. Open the logo principle file before drawing · ใคร: หัวหน้าทีม
2. Turn the brief into the brand direction before drawing: its `อารมณ์` words become the personality, its `ไม่เอา` becomes what the brand is not, and every direction traces back to `โปรเจกต์` · ใคร: `brand-keeper` ตัวใหม่ (for several routes: `brainstormer` ตัวใหม่)
3. Build the kit per `brand-kit`: logo rules and clear space · logo and icon marks per `icon-design` · color roles (contrast values are measured in step 5) · type scale · Thai and Latin font pair · tone of voice · ใคร: `brand-keeper` ตัวใหม่
4. Make 5 real-use templates, then run `design-review` on every piece and check it against the medium's principle file in [`design-principles`](../../design-principles/SKILL.md) (logo first) · ใคร: `brand-keeper` ตัวใหม่ makes the templates · `design-critic` ตัวใหม่ checks (ตรวจ)
5. Check (ตรวจ) that the color pairs used with text pass contrast and that the fonts are licensed for commercial use (check from the license page) · ใคร: `reviewer` ตัวใหม่

## Done when

A kit folder that can be read through in 5 minutes, and 5 templates that pass `design-review`
