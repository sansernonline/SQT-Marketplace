---
name: code-review
description: Run a code review with a fresh reviewer agent and the code-review-checklist skill.
argument-hint: <file path or PR description>
disable-model-invocation: true
---

> **ทางลัดเข้า SuperUser:** เปิด skill `superuser` ด้วย playbook `review` แล้วคัดลอกขั้นตอนของ playbook ลง todo ก่อน ส่วนขั้นตอนด้านล่างบอกรูปแบบงานและ output ของคำสั่งนี้ ให้ใช้คู่กับ playbook ไม่ได้ใช้แทน

Use a new `reviewer` agent (read-only) to perform a thorough code review of: **$ARGUMENTS** · high-stakes or contested change → `adversarial-review-panel`

The reviewer should:

1. Read the file(s) or diff to understand the change
2. Apply the `code-review-checklist` skill systematically
3. Categorize findings by severity:
   - `blocking:` — must fix before merge
   - `important:` — should fix
   - `nit:` — optional improvement
   - `q:` — questions
   - `praise:` — acknowledge good work
4. Provide concrete suggestions, not just criticism
5. Produce a summary at the end with overall recommendation:
   - ✅ Approve
   - 🔄 Request changes
   - 💬 Comment only
