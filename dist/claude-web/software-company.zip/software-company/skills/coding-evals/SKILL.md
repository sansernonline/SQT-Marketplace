---
name: coding-evals
description: Use when changing coding skills, playbooks or the developer agent, or asked if the team codes better.
---

# coding-evals — วัดว่าทีมเขียนโค้ดเก่งขึ้นจริง

> แก้ skill แล้ว "รู้สึก" ว่าดีขึ้นยังไม่พอ ต้องรันงานชุดเดิมก่อนและหลัง แล้วเทียบตัวเลข

ใช้เมื่อ: แก้ `stack-*` · `code-orientation` · `testing-standards` · playbook `feature` · `bug-fix` · `refactor` · agent `developer` · หรือผู้ใช้ถามว่าเก่งขึ้นไหม
ไม่ใช้กับ: งานลูกค้าจริง · งานที่ไม่มีโค้ด

---

## 1 · ชุดงาน

มี 8 งาน stack ละ 2 งาน แต่ละงานมีโปรเจกต์เล็กที่รันได้ และเกณฑ์ผ่านที่ตรวจด้วยคำสั่ง ไม่ใช่ความเห็น

| # | stack | งาน | ตรวจด้วย |
|---|---|---|---|
| 1 | .NET | เพิ่ม endpoint ยกเลิก order (ห้ามยกเลิกเมื่อส่งของแล้ว) | test ที่ซ่อนไว้ 6 ตัว · ไม่มี warning ใหม่ |
| 2 | .NET | แก้บั๊กวันที่ปีพุทธ 2569 ใน report (เครื่อง culture `th-TH`) | test ที่ซ่อนไว้ · ต้นเหตุถูกจุด |
| 3 | TypeScript | Angular form สมัครสมาชิก ตรวจเบอร์โทรไทย | test ที่ซ่อนไว้ · `tsc` 0 error · ไม่มี `any` |
| 4 | TypeScript | แก้ memory leak จาก subscription ใน component | วัดจำนวน subscription ก่อนและหลัง |
| 5 | Python | สคริปต์ import CSV ภาษาไทย (cp874) เข้า DB รันซ้ำได้ | รัน 2 ครั้ง แถวไม่ซ้ำ · test ที่ซ่อนไว้ |
| 6 | Python | FastAPI endpoint เรียกช้าเพราะ blocking call ใน async | latency ก่อนและหลัง · test ผ่าน |
| 7 | SQL | query รายงานยอดขายรายเดือน ช้าเกิน 2 วินาทีบนข้อมูล 1 ล้านแถว | เวลารันและ plan · ผลตรงกับคำตอบ |
| 8 | SQL | migration เพิ่มคอลัมน์ NOT NULL บนตารางใหญ่ โดยไม่ล็อกนาน | รันซ้ำได้ · ไม่มี downtime ในสคริปต์ |

ชุดงานอยู่ใน SQT-Marketplace ที่ `scripts/evals/coding/tasks/c<เลข>-<ชื่อ>/` (ไม่อยู่ใน plugin): `TASK.md` (คำสั่งที่ส่งให้ทีม) · `task.json` · `repo/` (โค้ดตั้งต้น) · `hidden/` (test ที่ทีมห้ามเห็น) · `reference/` (คำตอบอ้างอิง) · `check.mjs` · กติกาเต็มใน `scripts/evals/coding/CONTRACT.md`

## 2 · คะแนนต่องาน (เต็ม 10)

| ข้อ | คะแนน | ดูจาก |
|---|---|---|
| ถูกต้อง | 4 | hidden test ผ่านกี่ % (100% = 4 · ≥ 80% = 2 · ต่ำกว่า = 0) |
| test ของทีมเอง | 2 | มี test ใหม่ที่ล้มก่อนแก้ = 2 · มี test แต่ไม่ได้พิสูจน์ว่าเคยล้ม = 1 |
| สะอาด | 2 | build/lint/type 0 ปัญหาใหม่ = 1 · diff ไม่เกิน 1.5 เท่าของคำตอบอ้างอิง = 1 |
| ตามแบบแผน repo | 1 | reviewer ตัวใหม่ตอบว่าตาม/ไม่ตาม พร้อมจุด |
| รายงานจริง | 1 | ทุกข้ออ้างในรายงานตรวจได้ · ไม่มี "ผ่านแล้ว" ที่ไม่ได้รัน |

จดด้วย: เวลาที่ใช้ · token โดยประมาณ · จำนวนครั้งที่ต้องแก้ซ้ำ

## 3 · วิธีรัน

สคริปต์ `scripts/evals/coding/run-coding.mjs` ทำทุกขั้นให้ (วิธีใช้เต็มใน `scripts/evals/coding/README.md`)

```powershell
node scripts/evals/coding/run-coding.mjs --verify                     # ตรวจชุดงานก่อน: โค้ดตั้งต้นต้องตก · คำตอบอ้างอิงต้องผ่านครบ
node scripts/evals/coding/run-coding.mjs --old HEAD --tasks c1,c5     # รุ่นก่อน = commit ล่าสุด · รุ่นหลัง = ไฟล์ที่แก้อยู่
```

1. ทุกรอบรันในโฟลเดอร์ใหม่ใต้ `_to_delete/coding-bench/runs/` โหลด plugin ที่เทียบพร้อม `superuser` รุ่นเดียวกัน (ไม่โหลด plugin ที่ติดตั้งในเครื่อง) แล้วส่งคำสั่งเดียวกันให้ `superuser` ตรงตัว ไม่ช่วยเพิ่ม
2. ตรวจด้วย `check.mjs` ของงาน แล้วนับข้อ "test ของทีมเอง" กับ "สะอาด" ให้อัตโนมัติ (เอา test ของทีมไปรันกับโค้ดตั้งต้น · เทียบขนาด diff กับ `reference/`)
3. ข้อ "ตามแบบแผน" กับ "รายงานจริง" ให้ claude ตัวใหม่ที่ไม่เห็นงานตอนทำเป็นคนตัดสิน
4. งานที่ผลแกว่ง (โมเดลสุ่ม) ให้รัน `--runs 2` ขึ้นไปแล้วใช้ค่าเฉลี่ย และรายงาน 2 ตัวเลขต่องาน: **pass@k** = ผ่านอย่างน้อย 1 ใน k รอบ (บอกเพดาน) · **pass^k** = ผ่านครบทุก k รอบ (บอกความนิ่ง) · ตัดสินปล่อยด้วย pass^k เพราะงานจริงไม่ได้รันซ้ำให้เลือกรอบที่ดี (แนวคิดจาก ECC eval-harness)

## 4 · รายงานผล

สคริปต์เพิ่มแถวใน `scripts/evals/coding/RESULTS.md` เอง (1 แถวต่อรุ่น) · ผลรายรอบอยู่ใน `_to_delete/coding-bench/runs/`:

| วันที่ | เวอร์ชัน | งาน 1–8 | รวม /80 | เวลา | หมายเหตุ |
|---|---|---|---|---|---|

- ถ้าเวอร์ชันใหม่คะแนนรวมต่ำกว่าเดิม หรืองานไหนตก ≥ 2 คะแนน ให้ยังไม่ปล่อย แล้วหาเหตุจากงานที่ตก
- ใส่สรุป 3 บรรทัดในรายงานของ playbook `skill-authoring`: ดีขึ้นตรงไหน · แย่ลงตรงไหน · เพราะอะไร

## 5 · กติกา

- ทีมห้ามเห็น `hidden/` และคำตอบอ้างอิง ส่วนคนให้คะแนนต้องเป็น subagent ตัวใหม่เสมอ
- ห้ามแก้ชุดงานให้ผ่านง่ายขึ้นระหว่างเทียบ เพิ่มงานใหม่ได้ แต่เทียบเฉพาะงานที่มีทั้ง 2 รอบ
- บั๊กจริงที่ทีมเคยพลาด (จาก `.claude/superuser/learn/`) แปลงเป็นงานใหม่ในชุดนี้ได้ หลังตัดข้อมูลลูกค้าออก

## 6 · เชื่อมกับ skill อื่น

`docker-sandbox` · `testing-standards` · `principle-prove-it-works` · playbook `skill-authoring` · `stack-dotnet` · `stack-typescript` · `stack-python` · `stack-sql` · `code-orientation`
