---
name: commit-message-format
description: Use when writing a git commit message (Conventional Commits — type, scope, body, footer).
---

# Conventional Commit Message Format

## When to use this skill

- Writing any git commit message
- Reviewing commits in a PR for consistency
- Setting up commitlint / semantic-release

## Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

## Types

| Type | Use for | Triggers release? |
|------|---------|-------------------|
| `feat` | New feature | minor version bump |
| `fix` | Bug fix | patch version bump |
| `docs` | Documentation only | no |
| `style` | Formatting, no code change | no |
| `refactor` | Refactor without behavior change | no |
| `perf` | Performance improvement | patch |
| `test` | Adding/updating tests | no |
| `build` | Build system, dependencies | no |
| `ci` | CI/CD changes | no |
| `chore` | Maintenance tasks | no |
| `revert` | Revert previous commit | depends |

## Subject Rules

- **Imperative mood** — "add" not "added" or "adds"
- **Lowercase** — start with lowercase letter
- **No period at end**
- **Max 50 characters**
- **Complete this sentence:** "If applied, this commit will _____"

## Short and readable (applies to every commit)

Someone scanning `git log --oneline` should understand each line without opening the diff.

- **Language follows the repo** — check `git log -10` first. A Thai repo gets Thai descriptions; `type(scope):` stays English so tools can parse it. Lowercase and imperative mood apply to English only.
- **Subject says what changed for the reader**, not which file was touched: `fix(stock): เบิกของเท่ากับที่เหลือพอดีได้แล้ว`, not `fix: แก้ items.js บรรทัด 42`
- **One line is enough** for most commits. Add a body only when *why* is not obvious from the subject — at most 3 short lines or bullets
- **No filler** — no "this commit", "minor changes", "update code", "แก้นิดหน่อย", or a list of changed files (the diff already shows them)
- **One commit, one topic** — if the subject needs "and" or `·` to join unrelated changes, split the commit

| ❌ Hard to read | ✅ Short and clear |
|---|---|
| `update items.js, server.js, add test, fix bug` | `fix(stock): เบิกของเท่ากับที่เหลือพอดีได้แล้ว` |
| `feat: implement new functionality for exporting the low-stock report data to CSV format` | `feat(report): ส่งออกรายงานของใกล้หมดเป็น CSV` |
| `refactor: แก้โค้ดให้ดีขึ้น` | `refactor(report): อ่านประวัติเบิกครั้งเดียวแทนทุกสินค้า` |

## Examples

### Simple commit
```
feat(auth): add password reset via email
```

### With scope
```
fix(checkout): prevent double-charge on slow networks
```

### With body
```
feat(api): add rate limiting to public endpoints

Implement token bucket algorithm with 100 req/min limit per IP.
Returns 429 status with Retry-After header when exceeded.
Cache state stored in Redis to handle multi-instance deployments.
```

### Breaking change
```
feat(api)!: change auth response shape

BREAKING CHANGE: The /auth endpoint now returns tokens nested under
"data" key instead of root level. Update clients accordingly.

Before: { "access_token": "..." }
After:  { "data": { "access_token": "..." } }
```

### With issue reference
```
fix(login): handle email with leading whitespace

Closes #1234
Refs #5678
```

### Revert
```
revert: feat(auth): add password reset via email

This reverts commit a1b2c3d4.
Reverting due to security issue found in production.

Refs INCIDENT-42
```

## Body Rules

- Separate from subject with blank line
- Wrap at 72 characters
- Explain **why**, not just **what** (diff shows what)
- Use bullet points if multiple points
- Reference issues/tickets at the end

## Footer Conventions

```
Closes #123              ← closes the issue
Refs #456                ← references but doesn't close
BREAKING CHANGE: ...     ← breaking change notice
Co-authored-by: ...      ← attribution
```

## Quality Checklist

- [ ] Type matches the change (not just "chore" for everything)
- [ ] Scope is meaningful (component/module name)
- [ ] Subject is imperative and ≤50 chars
- [ ] Body explains WHY (if change isn't obvious)
- [ ] Breaking changes marked with `!` AND `BREAKING CHANGE:` footer
- [ ] Linked to issue/ticket when applicable

## Anti-patterns

- ❌ `update code`
- ❌ `fix bug`
- ❌ `WIP`
- ❌ `final commit` / `final final`
- ❌ Mixed changes: don't combine feature + refactor + fix in one commit
- ❌ Past tense: `added feature` (use `add feature`)
- ❌ Vague scope: `fix(misc): ...` (be specific)

## Splitting Commits

If your change is hard to summarize in one subject, split it:

```bash
# Instead of one big commit
feat(profile): redesign UI, add export, fix bug

# Split into focused commits
refactor(profile): extract user info component
feat(profile): redesign user info layout
feat(profile): add CSV export
fix(profile): correct date format in display
```
