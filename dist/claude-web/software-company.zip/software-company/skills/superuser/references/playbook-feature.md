# playbook · feature — เพิ่มหรือเปลี่ยนพฤติกรรม

ใช้เมื่อ: ฟีเจอร์ใหม่ · เปลี่ยนการทำงานเดิม · ทำตามข้อกำหนดใน SRS หรือ FSD
skill หลัก: [`code-orientation`](../../code-orientation/SKILL.md) · skill ตาม stack (`stack-dotnet` · `stack-typescript` · `stack-python` · `stack-sql`) · `lazy-coding` · `readable-code` · `testing-standards` · `spec-to-code-loop` (ถ้ามีหลายข้อกำหนด)

## ขั้นตอน (คัดลง todo ตรงตัว)

1. อ่านข้อกำหนดที่เกี่ยว (`docs/srs.md` · `docs/fsd-*.md` · mockup) แล้วทำ [`code-orientation`](../../code-orientation/SKILL.md) กับส่วนที่จะแตะ จะได้แผนที่ 10 บรรทัด แล้วเปิด skill ตาม stack ของโปรเจกต์
2. **บอกรูปข้อมูลก่อน** — type · ตาราง · state ที่ฟีเจอร์นี้สร้างหรือเปลี่ยน โดยเขียนเป็นโค้ดหรือตารางสั้น ๆ ในคำตอบ
   - วางตำแหน่งไฟล์ตามเกณฑ์โค้ดของ `superuser`: โฟลเดอร์ตามฟีเจอร์ · 1 ไฟล์ 1 หน้าที่ · แยก 3 ชั้น (รับข้อมูลเข้า → กฎธุรกิจ → เก็บข้อมูล) · ค่าตั้งอยู่นอกโค้ด · test อยู่ข้างโค้ด
   - ถ้าแตะ input จากภายนอก · login · ไฟล์ · เงิน · ข้อมูลส่วนบุคคล ให้เปิด [`principle-secure-by-default`](../../principle-secure-by-default/SKILL.md) ส่วนฟีเจอร์ที่เปิดสู่ภายนอก ให้รัน `/software-company:threat-model` ก่อนเขียน
3. ถ้าฟีเจอร์ข้ามหลายโมดูล ให้ร่างลายเซ็นฟังก์ชันและตำแหน่งไฟล์ก่อนเขียนเนื้อ ถ้ายังมีหลายทางที่ดีพอกัน ให้ใช้ [`parallel-attempts-pick-best`](../../parallel-attempts-pick-best/SKILL.md) หรือ playbook `prototype`
4. ในจุดที่จะแตะ ลบของที่ไม่ใช้ออกก่อน แล้วค่อยเพิ่ม ([`principle-replace-then-delete`](../../principle-replace-then-delete/SKILL.md))
5. แบ่งเป็นชิ้นเล็กที่ตรวจได้ทีละชิ้น ชิ้นละ 1 ข้อกำหนดหรือ 1 หน้าจอ แล้วส่งแต่ละชิ้นให้ agent `developer` ตัวใหม่ พร้อมแผนที่จากข้อ 1 ตำแหน่งไฟล์ และเกณฑ์ผ่าน
   - **test ก่อนโค้ด** สำหรับชิ้นที่มี logic (คำนวณ · เงื่อนไข · state): เขียน test ที่ล้มก่อน → รันให้เห็นว่าแดง → เขียนโค้ดให้เขียว → จัดให้สะอาด ส่วนชิ้นที่เป็นหน้าจอล้วนให้ตรวจด้วย skill ตรวจแอปแทน
6. ตรวจทุกชิ้นก่อนไปชิ้นถัดไป — test ของชิ้นนั้นต้องผ่าน และกดดูบนแอปจริงด้วย skill ตรวจแอปของโปรเจกต์
   - **ทุกพฤติกรรมใหม่และทุกข้อที่ตัดสินใจเอง ต้องมี test ล็อกไว้อย่างน้อย 1 ตัว** และ test ต้องล้มเมื่อโค้ดผิด ([`principle-prove-it-works`](../../principle-prove-it-works/SKILL.md))
7. **รีวิวก่อนบอกว่าเสร็จ — ห้ามข้าม** ถ้า diff เล็ก ให้ใช้ reviewer 1 ตัว (agent ใหม่ที่ไม่เคยเห็นงานนี้) ดูความถูกต้องและ edge case ถ้าฟีเจอร์มี logic หรือ state มาก ให้ใช้ [`adversarial-review-panel`](../../adversarial-review-panel/SKILL.md) อย่างน้อย 2 มุม คือความถูกต้องและความเรียบง่าย ถ้าเพิ่ม dependency หรือแตะเรื่องเสี่ยง ให้ผ่าน [`security-gate`](../../security-gate/SKILL.md)
   - test ผ่านครบไม่ได้แปลว่าไม่มีบั๊ก — ทุกข้อที่รีวิวยืนยันแล้ว ให้เขียน test ที่ล้มก่อน แล้วค่อยแก้
   - หน้าจอที่มี mockup หรือต้องเหมือนระบบเดิม ให้จบขั้นตรวจด้วย playbook `visual-parity`
8. เมื่อผ่านทั้งหมด ส่งมอบตามกฎ commit ใน `superuser` หัวข้อ 6 เปิด PR (`pr-description-template`) เมื่อผู้ใช้สั่ง แล้วจบด้วย `status-report`

## จบเมื่อ

ทุกเกณฑ์ผ่านของข้อกำหนดมีหลักฐาน — test ที่รันจริง หรือการกดบนแอปจริงพร้อมผลที่เห็น
