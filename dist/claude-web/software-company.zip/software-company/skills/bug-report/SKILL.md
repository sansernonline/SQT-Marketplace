---
name: bug-report
description: File a structured bug report using QA tester + bug-report-template skill.
argument-hint: <brief description of the bug>
disable-model-invocation: true
---

> **ทางลัดเข้า SuperUser:** เปิด skill `superuser` ด้วย playbook `bug-fix` แล้วคัดลอกขั้นตอนของ playbook ลง todo ก่อน ส่วนขั้นตอนด้านล่างบอกรูปแบบงานและ output ของคำสั่งนี้ ให้ใช้คู่กับ playbook ไม่ได้ใช้แทน

Use the `qa-tester` agent to create a complete bug report for: **$ARGUMENTS**

The tester should:

1. Apply the `bug-report-template` skill
2. Gather missing info in one question at the start (unknown → `(รอยืนยัน)`, keep going):
   - Steps to reproduce (exact)
   - Environment details
   - Expected vs actual behavior
   - Frequency
   - Evidence (screenshots, logs)
3. Assess severity (S1-S4) and propose priority (P1-P4)
4. Identify possible root cause hypothesis if visible
5. Produce final bug report in standard format
6. Suggest related test cases that should be added
