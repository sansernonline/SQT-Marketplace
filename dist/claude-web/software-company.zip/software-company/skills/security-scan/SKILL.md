---
name: security-scan
description: Run a security audit on code, dependencies or infrastructure with the security-engineer agent.
argument-hint: "<scope — code, deps, infra, or a specific file/component>"
disable-model-invocation: true
---

> **ทางลัดเข้า SuperUser:** เปิด skill `superuser` ด้วย playbook `review` แล้วคัดขั้นตอนของ playbook ลง todo ก่อน ขั้น security gate ให้ใช้ skill `security-gate` ส่วนขั้นตอนด้านล่างคือรูปแบบงานและ output ของคำสั่งนี้ ให้ใช้ประกอบ playbook ไม่ใช่แทนที่

Use the `security-engineer` agent to perform a security scan on: **$ARGUMENTS**

The security engineer should:

1. **Initial Discovery** — gather:
   - Scan scope (code, deps, infra, all)
   - Critical assets (PII, payment data, secrets)
   - Compliance requirements
   - Pre-existing security findings
   - Available SCA / SAST tools (Snyk, SonarQube, Trivy)

2. **Run automated scans where possible:**

   ### For code:
   - Look for OWASP Top 10 violations
   - SQL injection, XSS, CSRF, SSRF
   - Hardcoded secrets / API keys
   - Insecure crypto (MD5, SHA-1, weak ciphers)
   - Unsafe deserialization
   - Missing input validation
   - Authentication bypasses
   - Authorization gaps (IDOR)

   ### For dependencies:
   - Known CVEs in libraries
   - Outdated packages
   - License compliance issues
   - Supply chain risks
   - Suggested upgrade paths

   ### For infrastructure:
   - Exposed ports / services
   - Weak IAM policies
   - Unencrypted storage / transit
   - Missing security headers
   - Insecure defaults
   - Public S3 buckets, open databases
   - Container image vulnerabilities

3. **Manual review** for issues tools miss:
   - Business logic vulnerabilities
   - Authorization flaws
   - Race conditions
   - Privilege escalation paths
   - Cryptographic correctness
   - Session management

4. **Classify findings** using risk score:

   | Severity | Definition | Example |
   |----------|------------|---------|
   | 🔴 Critical | Exploitable now, severe impact | Auth bypass, RCE |
   | 🟠 High | Likely exploitable, significant impact | SQLi in non-admin |
   | 🟡 Medium | Hard to exploit OR limited impact | XSS in admin tool |
   | 🟢 Low | Defense in depth | Missing security header |

   Ship or not ship follows [`security-gate`](../security-gate/SKILL.md) step 4: a confirmed Critical or High **blocks shipping** until fixed or the user accepts the risk in writing.

5. **For each finding, provide:**
   - Description (what's wrong)
   - Location (file:line OR component)
   - OWASP category
   - CWE ID (Common Weakness Enumeration)
   - Proof of concept (how to exploit)
   - Fix recommendation with code example
   - References

6. **Check compliance posture:**
   - Relevant standards (PDPA, GDPR, PCI-DSS, SOC2, HIPAA)
   - Gaps with required controls
   - Evidence collection status

7. **Produce polished security audit report** using `polished-document-style` skill:
   - Executive summary
   - Health score per category
   - Critical findings (must fix)
   - High findings (must fix before shipping — `security-gate`)
   - Medium/Low findings (backlog)
   - Compliance gaps (if applicable)
   - Remediation roadmap (30/60/90 days)
   - Sign-off section

8. **Hand-off suggestions:**
   - Code fixes → `developer`
   - Infrastructure fixes → `devops-engineer`
   - Architecture changes → `solution-architect`
   - Customer notification (if breach) → `product-manager` + `technical-writer`
   - Detailed threat model → run `/threat-model`
