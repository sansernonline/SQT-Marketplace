> เดิมเป็น skill `defi-patterns` ใน plugin `software-company-web3` · ตั้งแต่ v2.0.0 ย้ายมารวมใน `smart-contracts`

**สารบัญ:** 

- [When to use this skill](#when-to-use-this-skill)
- [AMM Patterns](#amm-patterns)
- [Lending Patterns](#lending-patterns)
- [Vault Patterns (Yearn-style)](#vault-patterns-yearn-style)
- [Reward Distribution Patterns](#reward-distribution-patterns)
- [Governance Patterns](#governance-patterns)
- [Oracle Integration](#oracle-integration)
- [Liquidity Mining Patterns](#liquidity-mining-patterns)
- [Common Pitfalls](#common-pitfalls)
- [Reference](#reference)

# DeFi Implementation Patterns

## When to use this skill

- Building a DeFi protocol
- Reviewing DeFi code
- Wiring tokenomics into a protocol
- Integrating an oracle
- Designing a liquidation engine

## AMM Patterns

### Constant Product (Uniswap V2)

```solidity
// x * y = k
function swapXForY(uint256 dx) external returns (uint256 dy) {
    uint256 dxWithFee = dx * 997 / 1000;  // 0.3% fee
    dy = (dxWithFee * reserveY) / (reserveX + dxWithFee);

    require(dy <= reserveY, "Insufficient liquidity");

    IERC20(tokenX).transferFrom(msg.sender, address(this), dx);
    IERC20(tokenY).transfer(msg.sender, dy);

    reserveX += dx;
    reserveY -= dy;

    emit Swap(msg.sender, dx, dy);
}
```

### Concentrated Liquidity (V3)
- Liquidity sits in price ranges
- Uses capital efficiently
- Complex math (use the Uniswap V3 SDK)

### Stableswap (Curve)
- Built for stable pairs
- Lower slippage near the peg
- Different math (Stableswap invariant)

## Lending Patterns

### Pool-Based (Aave / Compound)

```solidity
// Deposit
function supply(address asset, uint256 amount) external {
    accrueInterest(asset);

    IERC20(asset).transferFrom(msg.sender, address(this), amount);

    uint256 mintAmount = amount * 1e18 / exchangeRate(asset);
    aTokens[asset][msg.sender] += mintAmount;
}

// Borrow
function borrow(address asset, uint256 amount) external {
    accrueInterest(asset);

    require(canBorrow(msg.sender, asset, amount), "Insufficient collateral");

    borrows[asset][msg.sender] += amount;
    IERC20(asset).transfer(msg.sender, amount);
}

// Liquidate
function liquidate(address user, address debtAsset, address collateralAsset, uint256 debtAmount) external {
    require(healthFactor(user) < MIN_HEALTH_FACTOR, "Not liquidatable");

    // Liquidator pays debt
    IERC20(debtAsset).transferFrom(msg.sender, address(this), debtAmount);
    borrows[debtAsset][user] -= debtAmount;

    // Seize collateral + bonus
    uint256 collateralAmount = calculateCollateral(debtAmount, debtAsset, collateralAsset);
    collateralBalances[collateralAsset][user] -= collateralAmount;
    IERC20(collateralAsset).transfer(msg.sender, collateralAmount);
}
```

### Health Factor

```solidity
function healthFactor(address user) public view returns (uint256) {
    uint256 totalCollateralUSD;
    uint256 totalDebtUSD;

    for (uint i = 0; i < assets.length; i++) {
        address asset = assets[i];
        uint256 price = oracle.getPrice(asset);

        totalCollateralUSD += collateralBalances[asset][user] * price * liquidationThreshold[asset] / 1e18;
        totalDebtUSD += borrows[asset][user] * price;
    }

    if (totalDebtUSD == 0) return type(uint256).max;
    return totalCollateralUSD * 1e18 / totalDebtUSD;
}

// healthFactor < 1e18 = liquidatable
```

## Vault Patterns (Yearn-style)

```solidity
// Strategy generates yield
interface IStrategy {
    function deposit(uint256 amount) external;
    function withdraw(uint256 amount) external returns (uint256);
    function harvest() external returns (uint256 yield);
}

contract Vault is ERC4626 {
    IStrategy public strategy;

    function deposit(uint256 assets, address receiver) public override returns (uint256 shares) {
        // Mint shares proportional to vault value
        shares = previewDeposit(assets);
        _deposit(_msgSender(), receiver, assets, shares);
        strategy.deposit(assets);
    }

    function harvest() external {
        uint256 yield = strategy.harvest();
        emit Harvest(yield);
    }
}
```

## Reward Distribution Patterns

### Pattern: Lazy Accumulation (Synthetix-style)

```solidity
uint256 public rewardPerToken;  // cumulative, scaled by 1e18
uint256 public lastUpdate;
uint256 public rewardRate;       // per second
uint256 public totalStaked;

mapping(address => uint256) public userRewardPerTokenPaid;
mapping(address => uint256) public rewards;
mapping(address => uint256) public balance;

function update() internal {
    // totalStaked is 0 before the first stake — dividing would revert every stake
    if (totalStaked > 0) {
        // multiply before dividing; 1e18 scale matches the / 1e18 in _updateUser
        rewardPerToken += (block.timestamp - lastUpdate) * rewardRate * 1e18 / totalStaked;
    }
    lastUpdate = block.timestamp;
}

function _updateUser(address user) internal {
    rewards[user] += balance[user] * (rewardPerToken - userRewardPerTokenPaid[user]) / 1e18;
    userRewardPerTokenPaid[user] = rewardPerToken;
}

function stake(uint256 amount) external {
    update();
    _updateUser(msg.sender);

    IERC20(token).transferFrom(msg.sender, address(this), amount);
    balance[msg.sender] += amount;
    totalStaked += amount;
}

function claim() external {
    update();
    _updateUser(msg.sender);

    uint256 amount = rewards[msg.sender];
    rewards[msg.sender] = 0;
    IERC20(rewardToken).transfer(msg.sender, amount);
}
```

## Governance Patterns

### Token-Weighted Voting (Governor)

Generate the contract with the [OpenZeppelin Contracts Wizard](https://wizard.openzeppelin.com/#governor) instead of writing it by hand — with `GovernorTimelockControl` the compiler requires several overrides, and a counting module (`GovernorCountingSimple`) is mandatory. Output below matches the Wizard for OpenZeppelin 5.x (compile-checked with 5.6.1 · ตรวจ 22 ต.ค. 2569).

Delays and periods are in the token's **clock** unit. `ERC20Votes` counts **blocks** by default, so `1 days` (= 86400) would mean 86400 blocks. Use block counts (Ethereum ≈ 12 s per block) or switch the token to timestamps (`clock()` / `CLOCK_MODE()` → `mode=timestamp`).

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Governor} from "@openzeppelin/contracts/governance/Governor.sol";
import {GovernorSettings} from "@openzeppelin/contracts/governance/extensions/GovernorSettings.sol";
import {GovernorCountingSimple} from "@openzeppelin/contracts/governance/extensions/GovernorCountingSimple.sol";
import {GovernorVotes} from "@openzeppelin/contracts/governance/extensions/GovernorVotes.sol";
import {GovernorVotesQuorumFraction} from "@openzeppelin/contracts/governance/extensions/GovernorVotesQuorumFraction.sol";
import {GovernorTimelockControl} from "@openzeppelin/contracts/governance/extensions/GovernorTimelockControl.sol";
import {IVotes} from "@openzeppelin/contracts/governance/utils/IVotes.sol";
import {TimelockController} from "@openzeppelin/contracts/governance/TimelockController.sol";

contract MyGovernor is
    Governor,
    GovernorSettings,
    GovernorCountingSimple,
    GovernorVotes,
    GovernorVotesQuorumFraction,
    GovernorTimelockControl
{
    constructor(IVotes _token, TimelockController _timelock)
        Governor("MyGovernor")
        GovernorSettings(7200 /* ~1 day of blocks */, 50400 /* ~1 week */, 0)
        GovernorVotes(_token)
        GovernorVotesQuorumFraction(4) // 4% quorum
        GovernorTimelockControl(_timelock)
    {}

    // Overrides required by Solidity
    function votingDelay() public view override(Governor, GovernorSettings) returns (uint256) {
        return super.votingDelay();
    }

    function votingPeriod() public view override(Governor, GovernorSettings) returns (uint256) {
        return super.votingPeriod();
    }

    function quorum(uint256 blockNumber)
        public view override(Governor, GovernorVotesQuorumFraction) returns (uint256)
    {
        return super.quorum(blockNumber);
    }

    function state(uint256 proposalId)
        public view override(Governor, GovernorTimelockControl) returns (ProposalState)
    {
        return super.state(proposalId);
    }

    function proposalNeedsQueuing(uint256 proposalId)
        public view override(Governor, GovernorTimelockControl) returns (bool)
    {
        return super.proposalNeedsQueuing(proposalId);
    }

    function proposalThreshold() public view override(Governor, GovernorSettings) returns (uint256) {
        return super.proposalThreshold();
    }

    function _queueOperations(
        uint256 proposalId, address[] memory targets, uint256[] memory values,
        bytes[] memory calldatas, bytes32 descriptionHash
    ) internal override(Governor, GovernorTimelockControl) returns (uint48) {
        return super._queueOperations(proposalId, targets, values, calldatas, descriptionHash);
    }

    function _executeOperations(
        uint256 proposalId, address[] memory targets, uint256[] memory values,
        bytes[] memory calldatas, bytes32 descriptionHash
    ) internal override(Governor, GovernorTimelockControl) {
        super._executeOperations(proposalId, targets, values, calldatas, descriptionHash);
    }

    function _cancel(
        address[] memory targets, uint256[] memory values,
        bytes[] memory calldatas, bytes32 descriptionHash
    ) internal override(Governor, GovernorTimelockControl) returns (uint256) {
        return super._cancel(targets, values, calldatas, descriptionHash);
    }

    function _executor() internal view override(Governor, GovernorTimelockControl) returns (address) {
        return super._executor();
    }
}
```

## Oracle Integration

### Chainlink Pattern

```solidity
import "@chainlink/contracts/src/v0.8/interfaces/AggregatorV3Interface.sol";

contract PriceConsumer {
    AggregatorV3Interface internal priceFeed;

    function getPrice() public view returns (int256) {
        (, int256 price, , uint256 updatedAt, ) = priceFeed.latestRoundData();

        // Sanity checks — never latestAnswer() (deprecated, no timestamp)
        require(price > 0, "Invalid price");
        // STALE_THRESHOLD = this feed's heartbeat (see data.chain.link) + a margin
        require(block.timestamp - updatedAt <= STALE_THRESHOLD, "Stale price");
        // answeredInRound is deprecated by Chainlink — don't rely on it
        // scale with priceFeed.decimals(); on L2s also check the sequencer uptime feed

        return price;
    }
}
```

### TWAP Pattern (Uniswap V3)

```solidity
// OracleLibrary lives in v3-periphery (not v3-core). The npm package targets
// Solidity <0.8 — for 0.8.x use the `0.8` branch of Uniswap/v3-periphery.
import "@uniswap/v3-periphery/contracts/libraries/OracleLibrary.sol";

function getTWAP(address pool, uint32 secondsAgo) public view returns (uint256 price) {
    (int24 tick,) = OracleLibrary.consult(pool, secondsAgo);
    price = OracleLibrary.getQuoteAtTick(tick, 1e18, token0, token1);
}
```

## Liquidity Mining Patterns

```solidity
// Reward distribution while bootstrapping
// CAUTION: pure emissions unsustainable without real yield underneath

contract LiquidityMining {
    uint256 public emissionPerBlock;
    uint256 public totalLP;

    function emissionsAt(uint256 startBlock, uint256 endBlock) public view returns (uint256) {
        // Reward rate decays over time
        return emissionPerBlock * (endBlock - startBlock) * decayFactor();
    }
}
```

## Common Pitfalls

- ❌ Depending on a single oracle
- ❌ Unprotected callback functions
- ❌ Flash loan and price manipulation in the same block
- ❌ Integer division before multiplication (loses precision)
- ❌ State updates after an external call (reentrancy)
- ❌ Missing slippage checks

## Reference

- [Aave V3 (lending)](https://github.com/aave/aave-v3-core)
- [Compound V3 (lending)](https://github.com/compound-finance/comet)
- [Uniswap V3 (AMM)](https://github.com/Uniswap/v3-core)
- [Yearn V3 (vaults)](https://github.com/yearn/yearn-vaults-v3)
- [OpenZeppelin Contracts — Governance](https://docs.openzeppelin.com/contracts/5.x/governance) (OpenZeppelin Defender was retired on 1 Jul 2026)
- [Curve (stableswap)](https://github.com/curvefi/curve-contract)
