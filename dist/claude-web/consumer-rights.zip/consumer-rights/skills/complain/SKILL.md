---
name: complain
description: Draft a complaint and escalation plan for a faulty product, bad service or refused refund — up to สคบ. 1166.
argument-hint: <what happened> [seller] [amount] [date]
disable-model-invocation: true
---

Run the `consumer-advocate` agent with the `complaint-letter-th` skill: **$ARGUMENTS**

1. Collect the facts and build the evidence list; ask only for what is missing.
2. Check time-limited rights first with `refund-request` (cooling-off, platform window, card dispute).
3. Identify the current step on the escalation ladder.
4. Draft the letter or message for that step in Thai (English too if the seller is foreign), with a dated deadline.
5. Write what happens next if the deadline passes.
