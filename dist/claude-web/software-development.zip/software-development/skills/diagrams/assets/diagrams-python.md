# diagrams (Python) — node ที่ใช้บ่อย และกับดักที่เจอจริง

อ้างอิงของ skill `diagrams` · ทดสอบกับ **diagrams 0.25.1 + Graphviz 2.42**

---

## 0 · เมื่อไหร่ใช้ · ติดตั้ง · กติกา (ย้ายมาจาก SKILL.md ข้อ 3)

ใช้เมื่อผังโครงสร้างพื้นฐานที่**อยู่ใน repo หรือเอกสารในทีม**ต้องมีไอคอน Amazon Web Services (AWS) · Azure · Kubernetes ของจริง ซึ่ง Mermaid วาดให้ไม่ได้ ส่วนไลบรารี **`diagrams`** (Python + Graphviz) จัดวางให้อัตโนมัติและ generate ใหม่จากโค้ดได้
ส่วนรูปที่ลูกค้า ผู้บริหาร หรือสไลด์จะเห็น ให้ใช้ `../references/diagram-figures.md` แทน

| ต้องการ | ใช้ |
|---|---|
| C4 · sequence · state · ER · flowchart | **Mermaid** ([mermaid-theme.md](mermaid-theme.md)) |
| ผังของจริงบนคลาวด์พร้อมโลโก้ผู้ให้บริการ ที่อยู่ใน repo | **`diagrams`** (ไฟล์นี้) |
| รูปในข้อเสนอลูกค้า · สไลด์ · เอกสารเซ็นรับ ที่ต้องดู "ออกแบบมา" | **`../references/diagram-figures.md`** |
| ลากวางเอง ปรับตำแหน่งทีละกล่อง | draw.io — คนทำเอง agent ทำแทนไม่ได้ |

> **อย่าวาด 2 ที่** — เรื่องเดียวกันให้เลือกเครื่องมือเดียว

### ติดตั้ง

```bash
pip install diagrams
# ต้องมี Graphviz ด้วย ไม่งั้นรันแล้วไม่มีไฟล์ออกมาและไม่มี error
apt install graphviz     # Windows: choco install graphviz   macOS: brew install graphviz
dot -V                   # ตรวจว่าติดตั้งแล้วจริง
```

### เริ่มจากโครงที่ทดสอบแล้ว

คัดลอก [`infra-diagram.py`](infra-diagram.py) ไปแก้ — ตั้งธีมชุดเดียวกับ Mermaid ไว้ให้แล้ว

### กติกาเพิ่มจาก SKILL.md ข้อ 4

- **หนึ่งกล่องต่อหนึ่งหน้าที่ และใส่จำนวนในป้าย** — `"Web / App ×2-6"` อ่านง่ายกว่าวาดกล่องเหมือนกัน 3 ใบ
  (กล่องซ้ำไม่ได้บอกอะไรเพิ่ม นอกจากทำให้เส้นพันกัน)
- **กลุ่มมีแค่ 2 สี** — `BOX` เทาอ่อน กับ `FOCUS` ฟ้า สำหรับส่วนที่เอกสารนี้กำลังพูดถึง
- **ไอคอนต้องเป็นของจริง** — ถ้าระบบไม่ได้ใช้ AWS ห้ามหยิบไอคอน AWS มาใช้เพราะสวย
  ให้ใช้ `diagrams.onprem.*` หรือ `diagrams.generic.*` แทน
- ป้ายเส้นยังต้องบอกว่า**อะไรไหลผ่าน** เหมือนเดิม — `SQL` `put object` `session` ไม่ใช่ `ใช้`

เรนเดอร์แล้ว**เปิดดูด้วยตา**ตามเช็กลิสต์ใน SKILL.md ข้อ 6 เหมือนกันทุกข้อ ส่วนกับดักที่เจอจริงอยู่ในข้อ 5 ของไฟล์นี้

---

## 1 · ผู้ให้บริการที่มีให้เลือก

`alibabacloud · aws · azure · c4 · custom · digitalocean · elastic · firebase · gcp ·
generic · gis · ibm · k8s · oci · onprem · openstack · outscale · programming · saas`

รายชื่อเต็มดูที่ [diagrams.mingrammer.com/docs/nodes](https://diagrams.mingrammer.com/docs/nodes/aws)
หรือถามตัวไลบรารีเองก็ได้:

```python
import importlib
m = importlib.import_module("diagrams.aws.database")
print([n for n in dir(m) if n[0].isupper()])
```

---

## 2 · node ที่ใช้บ่อยที่สุด

### AWS

| ใช้ทำอะไร | import |
|---|---|
| เครื่อง / คอนเทนเนอร์ | `from diagrams.aws.compute import EC2, ECS, EKS, Lambda, Fargate` |
| ฐานข้อมูล | `from diagrams.aws.database import RDS, Dynamodb, ElastiCache, Aurora` |
| เครือข่าย | `from diagrams.aws.network import ELB, ALB, Route53, CloudFront, VPC, APIGateway` |
| ที่เก็บไฟล์ | `from diagrams.aws.storage import S3, EFS` |
| คิว / เหตุการณ์ | `from diagrams.aws.integration import SQS, SNS, Eventbridge` |
| เฝ้าระวัง | `from diagrams.aws.management import Cloudwatch` |
| ตัวตน | `from diagrams.aws.security import IAM, Cognito, WAF` |

### Azure · Google Cloud Platform (GCP)

```python
from diagrams.azure.compute import AppServices, AKS, FunctionApps
from diagrams.azure.database import SQLDatabases, CosmosDb
from diagrams.azure.storage import BlobStorage
from diagrams.gcp.compute import GKE, Run, Functions
from diagrams.gcp.database import SQL, Firestore
from diagrams.gcp.storage import GCS
```

### Kubernetes

```python
from diagrams.k8s.compute import Pod, Deployment, StatefulSet, Job, Cronjob
from diagrams.k8s.network import Service, Ingress, NetworkPolicy
from diagrams.k8s.storage import PersistentVolume, PersistentVolumeClaim, StorageClass
```

### เครื่องของเราเอง (on-premises) — ใช้เมื่อไม่ได้อยู่บนคลาวด์

| ใช้ทำอะไร | import |
|---|---|
| ฐานข้อมูล | `from diagrams.onprem.database import PostgreSQL, MySQL, MSSQL, MongoDB` |
| แคช | `from diagrams.onprem.inmemory import Redis, Memcached` |
| คิว | `from diagrams.onprem.queue import RabbitMQ, Kafka, Celery` |
| คอนเทนเนอร์ | `from diagrams.onprem.container import Docker, K3S` |
| เครือข่าย | `from diagrams.onprem.network import Nginx, HAProxy, Internet, Consul` |
| เฝ้าระวัง | `from diagrams.onprem.monitoring import Grafana, Prometheus` |
| CI/CD | `from diagrams.onprem.ci import Jenkins, GithubActions, GitlabCI` |
| คน | `from diagrams.onprem.client import User, Users, Client` |

### ทั่วไป — เมื่อไม่มีโลโก้ที่ตรง

```python
from diagrams.generic.device import Mobile, Tablet
from diagrams.generic.network import Firewall, Router, Switch, VPN, Subnet
from diagrams.generic.os import Windows, Ubuntu, Android, IOS
from diagrams.generic.storage import Storage
```

### ไอคอนของเราเอง

```python
from diagrams.custom import Custom
sqt = Custom("Square Tech", "./icons/sqt-logo.png")   # ไฟล์ .png ขนาด ~256px
```

---

## 3 · ไวยากรณ์เชื่อมกล่อง

```python
a >> b                     # a ไป b
a << b                     # b ไป a
a - b                      # เส้นไม่มีหัวลูกศร
a >> Edge(label="SQL") >> b
a >> Edge(style="dashed", color="#C6CCD8") >> b
a >> [b, c, d]             # หนึ่งไปหลาย — ได้
```

```python
[a, b] >> [c, d]           # ผิด: TypeError — list กับ list ต่อกันไม่ได้
for x in [a, b]:           # ถูก: ถ้าจำเป็นต้องมีหลายกล่องจริง
    x >> c
```

> ทางที่ดีกว่าคือ**ยุบเป็นกล่องเดียวแล้วใส่จำนวนในป้าย** — `"Web Server x3"`
> กล่องเหมือนกันสามใบไม่ได้บอกอะไรเพิ่ม นอกจากทำให้เส้นพันกัน

---

## 4 · ตัวคุมหน้าตา

| ต้องการ | ใส่ตรงไหน |
|---|---|
| บนลงล่าง / ซ้ายไปขวา | `Diagram(..., direction="TB" หรือ "LR")` |
| ชื่อรูปอยู่บน | `graph_attr={"labelloc": "t"}` |
| ระยะห่างระหว่างชั้น | `graph_attr={"ranksep": "1.0"}` |
| ระยะห่างกล่องข้างกัน | `graph_attr={"nodesep": "0.6"}` |
| เส้นหักมุมฉาก | `graph_attr={"splines": "ortho"}` — สวยแต่ทับกล่องง่าย ลองทั้งสองแบบ |
| พื้นหลัง / เส้นขอบกลุ่ม | `Cluster(..., graph_attr={"bgcolor": ..., "pencolor": ...})` |
| ไฟล์ออกเป็น svg | `Diagram(..., outformat="svg")` |
| ไม่ให้เปิดไฟล์อัตโนมัติ | `Diagram(..., show=False)` |

---

## 5 · กับดัก

| อาการ | สาเหตุ · ทางแก้ |
|---|---|
| `TypeError: ... '>>': 'list' and 'list'` | ต่อ list เข้ากับ list ไม่ได้ ให้วนลูป หรือยุบเป็นกล่องเดียวแล้วใส่จำนวนในป้าย (ดูข้อ 3) |
| ภาษาไทยสระหาย วรรณยุกต์ผิดที่ | ฟอนต์ไม่รองรับไทย (ค่าเริ่มต้นของไลบรารีคือ `Sans-Serif` ซึ่งมักถูกแปลงเป็น DejaVu Sans ที่ไม่มีอักษรไทย) — ตั้ง `fontname` เป็น Noto Sans Thai · TH Sarabun New · Loma ทั้ง `graph_attr` `node_attr` `edge_attr` ให้ครบทั้งสามที่ ซึ่งโครง `infra-diagram.py` มี `pick_font()` เลือกให้อัตโนมัติ |
| ตั้ง `fontname` แล้วยังไม่เปลี่ยน | ตั้งไม่ครบสามที่ หรือฟอนต์ไม่มีในเครื่อง ตรวจด้วย `fc-list \| grep -i <ชื่อ>` |
| รันเงียบ ไม่มีไฟล์ | ไม่ได้ติดตั้ง Graphviz ตรวจด้วย `dot -V` |
| `ExecutableNotFound: dot` | สาเหตุเดียวกับข้างบน ส่วนบน Windows ต้องเพิ่ม Graphviz ลงใน PATH ด้วย |
| รูปสูงยาวผิดปกติ | ใช้ `direction="TB"` กับสายยาว ให้เปลี่ยนเป็น `"LR"` |
| ชื่อกลุ่มโดนเส้นทับ | เพิ่ม `ranksep` / `nodesep` หรือสลับลำดับที่ประกาศกล่อง หรือย้ายกล่องที่เส้นวิ่งผ่าน |
| กล่องอยู่ผิดกลุ่ม | กล่องอยู่ในกลุ่มที่ประกาศมันใน `with` เท่านั้น — ย้าย `with` ไม่ใช่ย้ายเส้น |
| ไฟล์ทับของเดิม | `filename=` ไม่ใส่นามสกุล และไฟล์เดิมจะถูกเขียนทับเงียบ ๆ |

---

## 6 · ตัวอย่างสั้น — ระบบบนเครื่องตัวเอง

```python
from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.network import Nginx
from diagrams.onprem.container import Docker
from diagrams.onprem.database import PostgreSQL
from diagrams.onprem.inmemory import Redis
from diagrams.onprem.client import Users

with Diagram("ระบบหลังบ้าน", filename="onprem", show=False, direction="LR"):
    users = Users("พนักงาน")
    with Cluster("เครื่อง app-01"):
        web = Nginx("Nginx\nreverse proxy")
        api = Docker("API\n(container)")
    db = PostgreSQL("PostgreSQL 16")
    cache = Redis("Redis")

    users >> Edge(label="HTTPS") >> web >> Edge(label="proxy") >> api
    api >> Edge(label="SQL") >> db
    api >> Edge(label="session") >> cache
```

---

## ตัวย่อ

- **AWS** — Amazon Web Services
- **GCP** — Google Cloud Platform
- **CI/CD** — Continuous Integration / Continuous Delivery
- **PNG** — Portable Network Graphics
- **SVG** — Scalable Vector Graphics
