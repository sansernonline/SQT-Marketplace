# graphic-designer templates — direction file · logo proposal · piece spec · review

Open this when you really have to write one of these documents. Mark anything you do not know with `(รอยืนยัน)` (awaiting confirmation).

## Standard Outputs

### Direction file
Copy this skill's `assets/brand-direction.md` to the project root and fill it in. Every piece after that refers to this file.

### Logo proposal
```markdown
## แบบที่ 01 — [ชื่อ เช่น "ตัวอักษรล้วน เรขาคณิต"]

**สถาปัตยกรรม:** ตัวอักษรล้วน / สัญลักษณ์+ตัวอักษร / สัญลักษณ์ล้วน / ตัวอักษรเป็นสัญลักษณ์ / อักษรย่อ
**ตัวอักษร:** [ตระกูล น้ำหนัก]
**สัญลักษณ์:** [อธิบาย หรือ ไม่มี]
**สื่อถึง:** [สิ่งที่อยากให้คนรู้สึก]
**ไม่ใช่:** [สิ่งที่ตั้งใจให้มันไม่เป็น]
**ทดสอบบริบท:** favicon ✓ · ปัก ✓ · ขาวดำ ✓ · กลับสี ✗ ช่องในตัว ก ตัน · ป้าย ✓ · โปรไฟล์ ✓
```

### Piece spec
```markdown
## [ชื่อชิ้นงาน]

**ไปอยู่ที่:** [LINE OA rich menu / โปสเตอร์ A3 / โพสต์ Facebook]
**ขนาด:** [px หรือ มม. · รวมตัดตกถ้าเป็นงานพิมพ์]
**ระยะมอง:** [30 ซม. บนมือถือ / 2 เมตร ที่หน้าร้าน]
**ข้อความที่ต้องอ่านออกแน่ ๆ:** [ประโยคเดียว]
**ไฟล์ส่งมอบ:** [รายการ]
**เก็บที่:** `assets/` (โลโก้ ไอคอน favicon) หรือ `assets/<ชื่องาน>/` (ชิ้นงานอื่น) — ต้นทาง `.svg` คู่กับไฟล์ export เสมอ
```

### Design review
List the faults one by one, and say **what each is wrong against**: the agreed direction · standard numbers · the list of things to avoid.

If something is a personal opinion, say it is an opinion.
