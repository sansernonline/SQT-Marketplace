---
name: bug-report-template
description: Use when writing up one software defect
argument-hint: <brief description of the bug>
---

# Bug Report Template

> **ภาษา:** ถ้อยคำทุกบรรทัดเขียนตาม `human-writing` — skill นี้บอกรูปแบบและโครง ส่วน human-writing บอกวิธีเขียนให้คนอ่านรู้เรื่อง

## Where bug reports live

One file per bug in `qa/bugs/BUG-<NNNN>-<slug>.md` at the project root. Attach screenshots and logs under `qa/bugs/BUG-<NNNN>/` — redact personal data first.

## When to use this skill

- Filing a new bug during testing
- Converting user complaints into bug tickets
- Reproducing an issue and documenting findings

## ไม่ใช้เมื่อ

| งาน | ใช้ตัวนี้แทน |
|---|---|
| รายงานบั๊กกองอยู่หลายเรื่อง ต้องคัด ทำซ้ำ และจัดกลุ่มก่อน | `bug-inbox-triage` แล้วใช้ skill นี้เขียนทีละใบ |
| เขียนกรณีทดสอบล่วงหน้าจากข้อกำหนด (ยังไม่มีบั๊ก) | `test-case-template` |
| ระบบจริงล่มหรือกระทบผู้ใช้จำนวนมาก | `incident-runbook-template` ระหว่างเหตุ · `postmortem-template` หลังเหตุ |

## 0 · หาแบบที่มีอยู่ก่อน (ทุกครั้ง)

ก่อนใช้โครงหรือแม่แบบในไฟล์นี้ ดูก่อนว่าผู้ใช้ ลูกค้า หรือโปรเจกต์มีแบบของตัวเองหรือยัง:

- **ที่ดู:** แบบฟอร์มของระบบติดตามงานที่โปรเจกต์ใช้: `.github/ISSUE_TEMPLATE/*.yml` หรือ `*.md` · ฟิลด์บังคับของ Jira / Azure Boards / GitLab ที่ผู้ใช้แจ้ง · รายงานบั๊กเก่า 2–3 ใบใน `docs/` หรือ tracker
- **ผล:** เจอ → ใช้แบบนั้น (หัวข้อ ลำดับ ชื่อฟิลด์ เลขรัน) แล้วบอกในคำตอบว่าใช้แบบจากไฟล์ไหน · ไม่เจอ → ใช้แม่แบบในไฟล์นี้เป็นค่าสำรอง และบอกว่าไม่พบแบบเดิม
- **ยังต้องมีทุกแบบ:** ระดับความรุนแรงใช้ชื่อและเกณฑ์ของทีมถ้ามี · ขั้นทำซ้ำ ผลจริง ผลที่คาดหวัง ยังต้องครบไม่ว่าใช้แบบไหน

## Severity vs Priority

These are **different**:

| | Severity | Priority |
|---|----------|----------|
| What it measures | Technical impact | Business urgency |
| Set by | QA (quality assurance) / Engineering | PM (product manager) / PO (product owner) |

| Severity | Definition |
|----------|------------|
| **S1 Critical** | System unusable, data loss, no workaround |
| **S2 High** | Major feature broken, workaround exists |
| **S3 Medium** | Feature partially broken |
| **S4 Low** | Cosmetic, minor inconvenience |

In a review report (the `reviewer` scale): S1–S2 = สูง · S3 = กลาง · S4 = ต่ำ

| Priority | Definition |
|----------|------------|
| **P1** | Fix immediately, block release |
| **P2** | Fix in current sprint |
| **P3** | Fix in next sprint |
| **P4** | Fix when there is time / backlog |

## Output Template

Copy **[`assets/bug-report.md`](assets/bug-report.md)** and fill it in. Do not write the outline from memory.

- Do not add, remove or reorder headings and `**fields:**`. A section marked `<!-- optional -->` may be deleted whole when it does not apply.
- A value you do not know yet → `(รอยืนยัน)`, never a guess and never the template's placeholder.
- Before handing over, run the shared checker until it passes (paths from this skill's folder):

  ```bash
  python <โฟลเดอร์ skill polished-document-style ใน plugin superuser>/scripts/check_outline.py assets/bug-report.md <your bug file>
  ```

  It flags missing or reordered headings, missing fields, changed table headers, and anything still unfilled (`<...>`, `YYYY-MM-DD`, `XXXX`, `...`, a field still listing every option).

## Title Writing Guide

Bad titles:
- "Login broken"
- "Bug in checkout"
- "It doesn't work"

Good titles (action + condition + result):
- "Login fails with 500 error when email contains apostrophe"
- "Checkout total shows NaN when quantity is decimal"
- "Search returns no results for queries longer than 100 chars"

**Formula:** `<Action> + <Condition> + <Unexpected result>`

## Steps to Reproduce Rules

- [ ] Start from a known state (logged out, fresh browser, etc.)
- [ ] Each step is one action
- [ ] Anyone can follow without prior knowledge
- [ ] Include exact data used (not "some user")
- [ ] No skipped steps (even "obvious" ones)
- [ ] Numbered sequentially

## Quality Checklist

Before submitting:

- [ ] Title clearly summarizes the issue
- [ ] Severity set · priority set, or `(รอยืนยัน)` until the PM/PO sets it
- [ ] Steps are reproducible by someone else
- [ ] Expected and actual results clearly differ
- [ ] At least one piece of evidence attached
- [ ] Environment info complete
- [ ] Searched for duplicates first
- [ ] `check_outline.py` passes

## Anti-patterns

- "Same as last week's bug" — describe it fully
- Multiple bugs in one report — split them
- "Bug" without steps — give steps to reproduce
- Putting a proposed fix in the title — the developer decides the fix
- Marking everything as P1 — be honest about priority

---

## Document Look

This skill decides **what goes in** the document. It does not decide **how it looks**.
Load the matching skill before writing, not after:

| What is being handed over | Load |
|---|---|
| Markdown someone reads (repo, wiki, issue tracker) | `polished-document-style` |
| A rendered `.docx` / `.pptx` / PDF a stakeholder signs off on | `branded-document-design` |
| The point needs a picture to land | `markdown-visuals`, then `diagram-figures` for project documents (`software-diagrams` only for README / PR notes) |

Default formatting is not neutral. It looks like unfinished work.

## เรียกเป็นคำสั่ง

`/software-development:bug-report-template <brief description of the bug>`

> **ทางลัดเข้า SuperUser:** เปิด skill `superuser` ด้วย playbook `bug-fix` แล้วคัดลอกขั้นตอนของ playbook ลง todo ก่อน ส่วนขั้นตอนด้านล่างบอกรูปแบบงานและ output ของคำสั่งนี้ ให้ใช้คู่กับ playbook ไม่ได้ใช้แทน

Use the `qa-tester` agent to create a complete bug report for: **$ARGUMENTS**

The tester should:

1. Apply the `bug-report-template` skill
2. Gather missing info in one question at the start (unknown → `(รอยืนยัน)`, keep going):
   - Steps to reproduce (exact)
   - Environment details
   - Expected vs actual behavior
   - Frequency
   - Evidence (screenshots, logs)
3. Reproduce once yourself from the reporter's steps before trusting them, and reject these excuses before scoring (idea from trailofbits/skills):
   - "cannot reproduce, so not a bug" → try another environment, data set or timing first, then file as `ทำซ้ำไม่ได้` with what was tried
   - "user did it wrong" → then it is a usability or validation bug, still filed
   - "edge case nobody hits" → count who can hit it; file with the number
   - "already known" → link the existing report; no link, no excuse
4. Assess severity (S1-S4) and propose priority (P1-P4)
5. Identify possible root cause hypothesis if visible
6. Produce final bug report in standard format
7. Suggest related test cases that should be added
