# CHANGELOG — e-commerce

## 1.8.3 — 2026-11-10

- ของกลางจาก superuser 3.33.0 (sync): ขั้นตรวจงานใหม่ใน `playbook-review` · แจกงานและรอลูกทีมใน `team-roles` · รอบ `playbook-unattended-run` มีตรวจเครื่องมือและกล่องขาออก · แม่แบบสมุดงาน ledger และแนวคิดที่ปฏิเสธใน `templates/` · แม่แบบ `config.json` มีโมดูล hook ใหม่

## 1.8.2 — 2026-11-08

- `references/examples.md`: ตัวอย่างระดับโมเดลจัดตามกฎ 3 ข้อของ superuser 3.26.0 (งานเสี่ยง → opus · งานกลไกที่มีแบบ → haiku · ที่เหลือ → sonnet)

## 1.8.1 — 2026-11-08

- `refund-request`: เลขขั้นเรียงเป็น Step 1 → 2 · `references/complaint-letter.md` ลบสารบัญซ้ำและลดระดับหัวข้อแม่แบบ (แก้ใน PR #75 ขึ้นเลขรุ่นที่นี่เพื่อให้เครื่องที่ติดตั้งแล้วอัปเดตได้)

## 1.8.0 — 2026-11-08

- ยุบ `complaint-letter-th` เข้า `refund-request` · ขั้นบันไดร้องเรียนและแม่แบบจดหมายอยู่ใน `references/complaint-letter.md` · **เรียกชื่อเก่าไม่ได้แล้ว**
- คำสั่ง `/e-commerce:complain` · agent `consumer-advocate` · playbook `complaint` `refund` `review` · triggers · `warranty-tracker` ชี้ตัวใหม่

## 1.7.1 — 2026-11-07

- ประหยัด token (audit หัวข้อ 8): ย้ายตาราง ตัวอย่าง และเช็กลิสต์ที่ใช้บางครั้งจาก SKILL.md ไป references/ ใน `hiring-th` `buy-compare` `product-listing` `cash-flow` `line-broadcast` `shipping-compare` `multi-shop-stock` `warranty-tracker` (ความหมายเดิม เพิ่มลิงก์) · `warranty-tracker` เพิ่มกฎ archive แถวหมดประกันและอ่านเฉพาะแถวที่ใกล้ครบ · `superuser/SKILL.md` ตัดประโยคซ้ำ 1 บรรทัด

## 1.7.0 — 2026-11-07

- agent `customer-chat`: ตอบด้วยน้ำเสียงจากแชตจริงของร้านตาม `chat-reply-templates` ข้อ 0
- หัวข้อใหม่ "0 · หาแบบที่มีอยู่ก่อน" ใน 5 skill: `chat-reply-templates` (น้ำเสียงจากแชตจริงของร้าน) · `doc-quotation` (ใบเสนอราคาฉบับก่อน · ต่อเลขรัน) · `hiring-th` (ประกาศเดิมและประกาศตำแหน่งเดียวกันในตลาด) · `line-broadcast` · `live-selling-script` (ตัวเลขครั้งก่อนของร้าน)
- eval ใหม่ 2 เคส `chat-reply-templates-existing` · `doc-quotation-existing` (ยังไม่ได้รัน)

## 1.6.0 — 2026-11-07

- เอาคำสั่งที่เป็นแค่ทางลัดไปหา skill ตัวเดียวออก 13 ตัว เรียก skill ตรงแทน เช่น `/e-commerce:buy-compare` · ขั้นตอนและ `argument-hint` ของคำสั่งเดิมย้ายไปหัวข้อ "เรียกเป็นคำสั่ง" ท้าย SKILL.md ของ skill ปลายทาง: `compare` → `buy-compare` · `contract` → `doc-contract-th` · `line-bot` → `line-chatbot` · `line-setup` → `line-oa-setup` · `listing` → `product-listing` · `live-script` → `live-selling-script` · `payroll` → `payroll-th` · `pdpa` → `pdpa-workflow` · `price-check` → `marketplace-fees-pricing` · `quotation` → `doc-quotation` · `reply` → `chat-reply-templates` · `tax-due` → `tax-vat-th` · `year-end-filing` → `dbd-annual-filing`

## 1.5.0 — 2026-10-28

- skill ใหม่ `import-landed-cost` แยกจาก `thai-business-setup` หัวข้อ 5 (ต้นทุนนำเข้าจากจีนต่อชิ้น · กติกาอากรปี 2569 · ทางรถหรือทางเรือ) ย้ายเนื้อหาแบบตัดแปะ ไม่เขียนใหม่ · `landed-cost.mjs` `rates.json` `example.json` ย้ายตามไปที่ `import-landed-cost/scripts/`
- `thai-business-setup` เหลือเลือกรูปแบบ จดทะเบียน และเช็กลิสต์หลังจด แล้วชี้ไป skill ใหม่ 1 บรรทัด (269 → 182 บรรทัด)
- agent `shop-manager` ใช้ `import-landed-cost` ก่อนตั้งราคาสินค้าที่สั่งจากจีน · แถวใหม่ใน `superuser/references/triggers.md`
- eval 3 เคสของ `import-landed-cost` (ควรเปิด · ไม่ควรเปิด · behaviour) ยังไม่ได้รัน

## 1.4.0 — 2026-10-28

- สคริปต์ใหม่ 3 ตัว: `tax-compare.mjs` ใน `seller-tax-basics` (หักเหมา 60% เทียบหักจริงพร้อมวิธีที่ 2 และโหมดบุคคลเทียบบริษัท SME ส่งต่อ `decide.mjs payoff`) · `stock-calc.mjs` ใน `multi-shop-stock` (buffer · จุดสั่งซื้อ · จำนวนสั่ง) · `landed-cost.mjs` ใน `thai-business-setup` (ต้นทุนนำเข้าต่อชิ้น 2 แบบ) · อัตราอยู่ใน `rates.json` ที่มีวันที่ตรวจ
- `price-calc.mjs` เตือนเมื่ออัตราเก่ากว่า 30 วัน · margin_pct น้อยกว่า 1 · voucher ตั้งแต่ราคาขาย และหยุดเมื่อต้นทุนรวม 0
- `payroll.mjs` เตือนเมื่อ rates.json เก่ากว่า 90 วัน · เงินสุทธิติดลบ · PVD ใส่เป็นเศษส่วน และ self-test เทียบอัตราขั้นสูงสุดกับ facts.json
- `thai-doc-total.mjs` อ่าน VAT 7% จาก `rates.json` เตือนเมื่อเก่าหรือเลย 30 ก.ย. 2570 และหยุดเมื่อยอดเกิน 9,999,999,999.99 บาท
- สคริปต์ทุกตัว import จากสคริปต์อื่นได้โดยไม่รัน CLI
- `buy-compare` ให้คะแนนด้วย `decide.mjs score` · TCO เป็นบาท · งบสูงสุดเป็นกฎ must
- `hiring-th` เปลี่ยนกฎคะแนนเสมอ: เดิมตัดสินที่เกณฑ์น้ำหนักมากสุด ตอนนี้รัน `decide score` แล้วให้คณะสัมภาษณ์ตัดสิน
- `hiring-th` ดูความนิ่งของอันดับผู้สมัครด้วย `decide.mjs score` และย้ายสัมภาษณ์ ตรวจบุคคลอ้างอิง PDPA จดหมายเสนองาน สัปดาห์แรก ประกาศภาษาอังกฤษไป references/ (304 → 166 บรรทัด)
- `thai-business-setup` เทียบบุคคลกับบริษัท 3 สถานการณ์กำไรด้วย `decide.mjs payoff` · ไม่เดาโอกาสแทนผู้ใช้
- `multi-shop-stock` แบ่งระดับ stock ด้วยจำนวนวันที่ขายได้แทนจำนวนชิ้น และบอกเหตุผลของ buffer +2 (ค่าตั้งต้น ยังไม่ได้วัด)
- `promptpay-qr` เพิ่มหัวข้อตรวจเงินเข้าบัญชีจริงก่อนส่งของ ไม่ส่งของด้วยสลิป และให้อ่านชื่อบัญชีที่แอปแสดงก่อนพิมพ์ QR
- `complaint-letter-th` description บอกชัดว่าเป็นฝั่งผู้ซื้อ
- ตารางคำสั่ง slash 14 ตัวใน `superuser/references/triggers.md`
- `evals/` ชุดแรก 5 skill (trigger ควรเปิด 3 ไม่ควรเปิด 3 และ behaviour 1 ต่อ skill) ยังไม่ได้รัน

## 1.3.1 — 2026-10-28

- `promptpay.mjs` ตรวจหลักตรวจสอบของเลข 13 หลัก เลขที่พิมพ์ผิดหยุดก่อนได้ QR ที่โอนเงินไปผิดคน
- `payroll.mjs` คิดประกันสังคมจากค่าจ้างเฉลี่ยต่อเดือนแล้วกระจายเป็นต่องวด เดิมใช้ค่าจ้างต่องวดเป็นฐานรายเดือน จ่ายรายสัปดาห์จึงหักและลดหย่อนผิด

## 1.3.0 — 2026-10-28

- สคริปต์ใหม่ที่คิดเลขแทน AI: `promptpay.mjs` (payload PromptPay และ CRC16 ตรงตัวอย่างใน skill ทุกตัวอักษร) · `thai-id.mjs` (หลักตรวจสอบเลขผู้เสียภาษี 13 หลัก) · `thai-doc-total.mjs` (VAT · หัก ณ ที่จ่าย · ยอดเป็นตัวหนังสือ) · `price-calc.mjs` (ราคาขายหลังค่าธรรมเนียม อัตรารับจากไฟล์ที่มีวันที่ตรวจ) · `payroll.mjs` (ภาษีหัก ณ ที่จ่ายและประกันสังคม ค่าอยู่ใน `rates.json` ผูกกับ `facts.json`) · ทุกตัวมี self-test และ CI รัน
- `line-oa-setup` บอกวิธีติดตั้ง MCP ทางการของ LINE (`@line/line-bot-mcp-server@0.5.0` รุ่น preview) แบบล็อกรุ่นให้ผู้ใช้ติดตั้งเอง ไม่ส่งไปกับ plugin

## 1.2.0 — 2026-10-27

- ตัดสินด้วยตัวเลขผ่าน `decision-scoring`: `shipping-compare` ให้คะแนนขนส่ง · `live-selling-script` และ `line-broadcast` เลือกชิ้นหรือ segment ภายใต้งบด้วย knapsack · `returns-and-bad-reviews` สู้เคลมเมื่อค่าคาดหวังเป็นบวกและมีหลักฐาน · `warranty-tracker` ประกันขยายด้วยค่าคาดหวัง · `cash-flow` ปิดช่องว่างเงินสดจากทางที่ต้นทุนต่อบาทต่ำสุด

## 1.1.3 — 2026-10-27

- ไอคอนประจำ plugin `assets/icon.png` (512) และ `assets/icon.svg` · ช่อง `icon` ใน plugin.json (ใช้ในหน้ารายการของ directory) · ทำตาม `design-references`: ค้นต้นแบบบน Dribbble แล้วถอดสีหลักจากงานต้นแบบ หมุนเฉดต่อ plugin · ผ่าน design-critic

## 1.1.2 — 2026-10-26

- `hiring-th` และ `labour-law-basics`: ม.17 ตรวจกับตัวบทในราชกิจจานุเบกษา (เล่ม 115 ตอน 8 ก) · ม.17/1 ตามสรุปของสำนักเลขาธิการวุฒิสภา · ถอดป้าย (รอยืนยัน)

## 1.1.1 — 2026-10-26

- ไอคอนในเนื้อหาเปลี่ยนเป็นคำ · ป้ายในร่างสัญญาเปลี่ยนจาก ⚠️ เป็น `[ให้ทนายตรวจ]` (`doc-contract-th` · agent `thai-doc-writer`)

## 1.1.0 — 2026-10-25

- `tax-vat-th`: ค่าปรับยื่น ภ.พ.30 ช้าแก้ให้ถูก เป็น 2% · 5% · 10% · 20% **ของเบี้ยปรับ** (เกิน 60 วันได้ 20%) ตามคำสั่ง ท.ป.81/2542 ข้อ 5(1) แก้โดย ท.ป.369/2569 มีผล 3 ก.ค. 2569 · เดิมเขียน 3 ขั้นและอ้าง ป.4/2528 · VAT 7% ถึง 30 ก.ย. 2570 และ e-Filing ยื่นเพิ่ม 8 วันสำหรับแบบที่ครบกำหนดถึง 31 ม.ค. 2570 ยืนยันแล้ว (หลังจากนั้นยังรอยืนยันว่าต่ออายุไหม)
- `marketplace-fees-pricing`: หมายเหตุเรื่อง กขค. ตรึงค่าธรรมเนียม 6 แพลตฟอร์ม 6 เดือน (ยังรอยืนยัน) · อัตราค่าธรรมเนียมยังไม่ได้ตรวจซ้ำรอบนี้
- skill ใหม่ `sme-bookkeeping`: บัญชีรายรับรายจ่ายจากบัญชีธนาคารและรายงานยอดโอนของแพลตฟอร์ม · ใครต้องทำรายงานเงินสดรับ-จ่าย · เก็บเอกสาร 5 ปี (พ.ร.บ.การบัญชี ม.14 · ประมวลรัษฎากร ม.87/3) ขยายได้ถึง 7 ปี · แยกเงินส่วนตัวกับเงินร้าน · ปิดบัญชีสิ้นเดือน · เมื่อไรควรจ้างสำนักงานบัญชี · แม่แบบชีตใน `references/` · ระยะเวลาลงรายการของกรมพัฒนาธุรกิจการค้าติด (รอยืนยัน)
- skill ใหม่ `cash-flow`: ประมาณการเงินสด 13 สัปดาห์ · วัดระยะเวลาเงินเข้าจริงของแต่ละช่องทาง (แพลตฟอร์ม · COD) · วันจ่ายภาษีหัก ณ ที่จ่าย VAT และประกันสังคมเป็นเงินออก · สัญญาณเตือนและสิ่งที่ทำ · แม่แบบใน `references/` · รอบโอนเงินของแต่ละแพลตฟอร์มติด (รอยืนยัน)
- agent `tax-helper` โหลด `sme-bookkeeping` · `cash-flow` · ตัวกระตุ้นทั้ง 2 ตัวชี้มาที่ `tax-helper`
- agent `tax-helper` โหลด `seller-tax-basics` · `hiring-th` · `thai-business-setup` ด้วย · ตัวกระตุ้นของ 2 ตัวหลังชี้มาที่ `tax-helper`
- รวม plugin `thai-workplace` เข้ามา: skill 19 ตัว คำสั่ง 8 ตัว (เอกสารธุรกิจ · ภาษีและปฏิทินยื่นแบบ · เงินเดือน · ประกันสังคม · กฎหมายแรงงาน · รับพนักงาน · เปิดบริษัท · ยื่นสิ้นปี · PDPA · LINE OA · พร้อมเพย์ · วันหยุด) · agent `thai-doc-writer` · `tax-helper` · `compliance-helper` · `line-admin` · playbook `business-doc` · `monthly-close` · `year-end` · `pdpa-setup` · `line-oa`
- `seller-tax-basics` กลับมาอยู่ plugin เดียวกับฝั่งขาย · ตัวชี้ที่เคยบอกให้ติดตั้ง `thai-workplace` เพิ่มไม่ต้องใช้แล้ว
- `line-richmenu` ไม่ได้ย้ายมาด้วย ไปอยู่ `graphic-design` เพราะเป็นงานออกแบบภาพเมนู
- prompt ของ `thai-workplace` 4 ไฟล์ย้ายไป `prompt/e-commerce/` · README รวมตาราง "เลือกจากสถานการณ์" ของงานหลังบ้านไว้ท้ายไฟล์
- ผู้ที่ติดตั้ง `thai-workplace` ไว้: `/plugin uninstall thai-workplace` แล้วติดตั้ง `e-commerce` · ชื่อ skill และ command เดิมใช้ได้เหมือนเดิมภายใต้ `e-commerce:`

## 1.0.0 — 2026-10-23

- รวม `online-seller` + `consumer-rights` เป็น plugin เดียว — ครอบซื้อ-ขายออนไลน์ทั้งสองฝั่ง
- ชื่อ skill และ command เดิมทุกตัวใช้ได้เหมือนเดิม · playbook ของทั้งสองฝั่งรวมอยู่ใน skill `superuser`
- `seller-tax-basics` ย้ายไป `thai-workplace` (ภาษี/เอกสารธุรกิจไทยอยู่ด้วยกัน) · ทุกที่ที่ชี้ไปบอกชื่อ plugin ไว้แล้ว
- ถอด plugin เดิม: `/plugin uninstall online-seller` และ `/plugin uninstall consumer-rights`
- `marketplace-fees-pricing`: ค่าธรรมเนียม ฿1.07 ต่อคำสั่งซื้อของ TikTok Shop คิดเฉพาะร้านที่ขายเกิน 100 ชิ้นใน 30 วันล่าสุด ร้านที่เล็กกว่านั้น ฿0 (flowaccount.com 2026-08-10) · Commerce Growth Fee แหล่งไม่ตรงกัน (6.42% กับ 5.89%) ติด (รอยืนยัน) · รอบขึ้นค่าคอมมิชชันของ Shopee มีข่าวลงวันที่ต่างจากตาราง ติด (รอยืนยัน)
- `product-listing`: คู่ตัวอย่างคำบรรยายแบบอ่อนกับแบบแข็ง (ประโยชน์ที่มีตัวเลข) · ตารางหาสาเหตุที่สินค้าขายไม่ออกจากตัวเลขของร้าน (ยอดเห็น · อัตราคลิก · คำสั่งซื้อ)
- `chat-reply-templates` · `returns-and-bad-reviews`: ข้อความตอบลูกค้าเขียนใหม่ตามระดับภาษาแชตร้าน คงคำขอโทษ ขอบคุณ นะคะ ไว้ ตัดเฉพาะข้อเท็จจริงที่ซ้ำ
- `complaint-letter-th` · `refund-request`: แม่แบบจดหมายย้ายไป `references/` · กำหนดเวลาเขียนเป็น "ภายใน 7 วัน นับจากวันที่ได้รับหนังสือฉบับนี้" · `multi-shop-stock` เก็บชีตสต็อกนานเท่าเอกสารภาษี อย่างน้อย 5 ปี
- `complaint-letter-th` แก้ข้อกฎหมายตามราชกิจจานุเบกษาและแหล่งอิสระอีก 4 แหล่ง (ตรวจ 2026-10-23): ผู้ประกอบธุรกิจฟ้องผู้บริโภคได้ที่ศาลที่ผู้บริโภคมีภูมิลำเนาแห่งเดียว (มาตรา 17 · ข้อความก่อนหน้านี้อ่านกลับความหมาย) · ผู้บริโภคได้รับยกเว้นค่าฤชาธรรมเนียม แต่ไม่รวมค่าฤชาธรรมเนียมในชั้นที่สุด และศาลสั่งให้จ่ายได้ถ้าฟ้องโดยไม่มีเหตุผลอันสมควร (มาตรา 18 ไม่เคยถูกแก้ จึงเอา (รอยืนยัน) ออก) · ผู้บริโภคเป็นโจทก์ยื่นที่ศาลที่มูลคดีเกิดหรือที่ผู้ประกอบธุรกิจมีภูมิลำเนา (รอยืนยัน) · ตัด "ไม่ต้องมีทนาย" ที่ตัวบทไม่ได้เขียนไว้
