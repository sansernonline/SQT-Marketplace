# Description template (Thai)

Fill every line; delete a line only if it truly does not apply.

```
【ชื่อสินค้า】 <ชื่อเต็มเหมือนในหัวข้อ>

✔ จุดเด่น
• <ประโยชน์ที่ลูกค้าได้ ข้อ 1 — เป็นผลลัพธ์ ไม่ใช่สเปก>
• <ข้อ 2>
• <ข้อ 3>

📐 รายละเอียดสินค้า
• ขนาด: <กว้าง x ยาว x สูง ซม.> / ปริมาณ: <มล. หรือ กรัม>
• น้ำหนัก: <กรัม>
• วัสดุ/ส่วนประกอบ: <...>
• สี/ตัวเลือก: <ตรงกับชื่อตัวเลือกในระบบ>
• ผลิตที่: <ประเทศ> · เลข อย./เลขจดแจ้ง: <ถ้ามี>
• วันผลิต/วันหมดอายุ: <ถ้าเป็นอาหารหรือเครื่องสำอาง>

📦 ในกล่องมี
• <รายการ>

👤 เหมาะกับ
• <ใคร ใช้ทำอะไร>

ระวัง: วิธีใช้ / ข้อควรระวัง
• <คัดจากฉลาก ห้ามแต่งเพิ่ม>

🚚 การจัดส่ง
• ส่งภายใน <1–2> วันทำการหลังชำระเงิน (ตัดรอบ <เวลา>)

🔁 การคืนสินค้า
• กรุณาถ่ายวิดีโอขณะแกะกล่อง หากสินค้าเสียหายหรือไม่ตรงปก ทักแชทได้เลย
• รับคืนตามนโยบายของ <แพลตฟอร์ม>

💬 สอบถามเพิ่มเติม ทักแชทได้ <เวลาตอบแชท>
```

## Rules

- Benefits first, specs second — buyers scan the first 3 lines on a phone
- Pick one form for the whole page: the product page has no ค่ะ/ครับ (marketing register) · if the shop wants them, put them on every line that speaks to the customer, not on a single line → `human-writing` `references/thai-grammar.md` section 4, the marketing register
- Metric units; sizes in ซม., never "ประมาณฝ่ามือ"
- Copy usage and warnings from the actual label; do not add effects the label does not state
- No LINE ID, phone number or outside link in Shopee/Lazada/TikTok descriptions — against platform rules
- Return line must not promise less than the platform's own policy (see `customer-care`)
