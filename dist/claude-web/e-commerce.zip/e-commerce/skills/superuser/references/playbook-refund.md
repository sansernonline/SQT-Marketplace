# playbook · refund — requesting a refund

Use when: wanting money back — changed mind after a direct-sale purchase · wrong, fake or broken goods · paid but never received · an unknown or duplicate card charge
Main principles: [`shop-principles`](../../shop-principles/SKILL.md) · [`customer-care.md`](../../shop-principles/references/customer-care.md) · [`buying.md`](../../shop-principles/references/buying.md)
Main skill: `buyer-help` (the complaint letter is in `references/complaint-letter.md`)

## ขั้นตอน (Steps — copy into the todo exactly)

1. Open both principle files first. Then classify the case following `buyer-help` and count the deadline of each route's right, then take the route closest to its deadline first · ใคร: `consumer-advocate` ตัวใหม่
2. Gather the payment evidence and the condition of the goods · ใคร: หัวหน้าทีม
3. Choose the route — ask the shop · open a dispute with the platform · ask the bank to reject the charge · complain. Then write the reason in the "การตัดสินใจ" (decisions) table · ใคร: หัวหน้าทีม
4. Draft the request, forms and messages needed, with click-by-click steps in the platform's or bank's app · ใคร: `consumer-advocate` ตัวใหม่
5. Check (ตรวจ) that the amount, dates and order number match the evidence, and that the request follows both principle files · ใคร: `reviewer` ตัวใหม่

## Done when

The request is ready to send before the deadline, with a backup plan if it is rejected.
