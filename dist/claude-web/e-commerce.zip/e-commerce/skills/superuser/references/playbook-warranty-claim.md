# playbook · warranty-claim — warranty register and claims

Use when: you just bought something with a warranty · you want to keep receipts in order · something broke and you want to know whether it is still under warranty
Main principles: [`shop-principles`](../../shop-principles/SKILL.md) · [`customer-care.md`](../../shop-principles/references/customer-care.md) · [`buying.md`](../../shop-principles/references/buying.md)
Main skills: `buyer-help`

## ขั้นตอน · Steps (copy into the todo exactly)

1. Open both principle files first. Then create or open the register per `buyer-help` — product · purchase date · shop · warranty end · where the receipt is kept · ใคร: `consumer-advocate` ตัวใหม่
2. Add the items the user sent, reading from the real receipt or warranty card · ใคร: `consumer-advocate` ตัวใหม่
3. If a claim is planned, check that the item is still under warranty, read the exclusion terms, and prepare the documents and the message to the service center · ใคร: `consumer-advocate` ตัวใหม่ checks eligibility and prepares the documents
4. Set a reminder 30 days before the warranty ends for items worth checking before then · ใคร: หัวหน้าทีม
5. Check (ตรวจ) the register, the reminders, and the claim pack (if any) before it reaches the user, judged against both principle files · ใคร: `reviewer` ตัวใหม่

## Done when

Every row of the register matches the real documents, and the claim pack is ready to send (if there is one).
