# playbook · year-end — year-end close: financial statements, shareholder meeting, ภ.ง.ด.50 (PND 50, corporate income tax return) and 50 ทวิ (withholding tax certificate)

Use when: after the accounting period ends · issuing withholding tax certificates and ภ.ง.ด.1ก (PND 1 Kor, annual employee withholding tax summary) for employees
Main principles: [`shop-principles`](../../shop-principles/SKILL.md) · [`thai-paperwork.md`](../../shop-principles/references/thai-paperwork.md)
Main skills: `thai-tax` · `thai-employment`

## ขั้นตอน · Steps (copy into the todo exactly)

1. Open `thai-paperwork.md` first. Then count back from the period end date per `thai-tax` — shareholder meeting · financial statements audited · บอจ.5 (Bor Or Jor 5, shareholder list) · ภ.ง.ด.50 · ใคร: `tax-helper` ตัวใหม่
2. Check the deadlines and penalties on the websites of the Department of Business Development and the Revenue Department · ใคร: `tax-helper` ตัวใหม่
3. Prepare ภ.ง.ด.1ก and 50 ทวิ from the full-year payroll table · ใคร: `tax-helper` ตัวใหม่
4. List the documents needed from the auditor and the directors, with the date each is needed · ใคร: `tax-helper` ตัวใหม่
5. Check (ตรวจ) — the full-year amounts in each 50 ทวิ must match the 12-month totals, and the timeline and forms follow `thai-paperwork.md` · ใคร: `reviewer` ตัวใหม่

## Done when

The year-end timeline has been checked against official sources, and every person's 50 ทวิ matches the totals.
