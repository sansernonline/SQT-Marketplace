# playbook · pdpa-setup — set up PDPA (Personal Data Protection Act) for an SME

Use when: starting PDPA work · making a consent form · a data subject has made a request · data has leaked
Main principles: [`shop-principles`](../../shop-principles/SKILL.md) · [`thai-paperwork.md`](../../shop-principles/references/thai-paperwork.md)
Main skills: `pdpa-workflow` · agent `compliance-helper`

## ขั้นตอน · Steps (copy into the todo exactly)

1. If data is leaking right now, run the breach-response steps in `pdpa-workflow` before anything else, and start the clock for notifying the authority · ใคร: หัวหน้าทีม (talk to the user at once)
2. Open `thai-paperwork.md` first. Then list the personal data the company keeps — what, whose, why, the legal basis, and how long · ใคร: `compliance-helper` ตัวใหม่
3. Draft the consent form, the privacy notice, and the record of processing activities · ใคร: `compliance-helper` ตัวใหม่
4. Set out the steps for handling data subject requests, with deadlines · ใคร: `compliance-helper` ตัวใหม่
5. Check (ตรวจ) — every activity has a legal basis, every point that needs a lawyer is flagged, and the documents follow `thai-paperwork.md` · ใคร: `reviewer` ตัวใหม่

## Done when

The PDPA document set is ready to use, and the steps for requests and breaches have clear deadlines.
