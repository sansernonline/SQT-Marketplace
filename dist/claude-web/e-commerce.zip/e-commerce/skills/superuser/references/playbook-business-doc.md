# playbook · business-doc — Thai business documents

Use when: a quotation · invoice · receipt · tax invoice · official letter · contract · leave request
Main skills: `doc-quotation` · `e-tax-invoice` · `doc-thai-official` · `doc-contract-th` · `doc-leave` · agent `thai-doc-writer`

## ขั้นตอน · Steps (copy into the todo as written)

1. Pick the document type that fits the event, per `doc-quotation` (quote · billing · payment received · tax invoice) · ใคร: หัวหน้าทีม
2. Collect the parties' details and line items from real sources · put the tax ID and address exactly as the user gave them · ใคร: หัวหน้าทีม
3. Draft in the skill's format — a tax invoice has every field the law requires · an official letter follows the correspondence regulations · a contract follows the contract-clause checklist · ใคร: `thai-doc-writer` ตัวใหม่
4. Calculate VAT, withholding tax, and the total in Thai words using the formulas · ใคร: `thai-doc-writer` ตัวใหม่
5. Check (ตรวจ) — mandatory fields are complete · figures and words match · contract clauses that need a lawyer are flagged · ใคร: `reviewer` ตัวใหม่

## Done when

The document is ready to send, the mandatory fields are complete, the totals match, and every point that needs an expert is flagged.
