# Knowledge base template and handoff messages

## KB sheet columns

Columns after `intent_id`: sample questions · approved answer · live data source · owner · last checked · `handoff?`. The sample rows below are Thai because the bot answers Thai customers.

| intent_id | ตัวอย่างคำถาม | คำตอบที่อนุมัติ | แหล่งข้อมูลสด | เจ้าของ | ตรวจล่าสุด | handoff? |
|---|---|---|---|---|---|---|
| hours | เปิดกี่โมง, วันนี้เปิดไหม | ร้านเปิดทุกวัน 09:00–18:00 น. ปิดวันหยุดนักขัตฤกษ์ค่ะ | — | ฝ่ายขาย | 2026-10-01 | no |
| price | ราคาเท่าไหร่, มีโปรไหม | ราคา {product} ตอนนี้ {price} บาทค่ะ | stock API | ฝ่ายขาย | live | if not found |
| refund | ขอคืนเงิน, ของเสีย | — | — | หัวหน้า CS | — | **always** |

## Handoff and system messages (ค่ะ persona)

Send these Thai messages as written.

- รับเรื่องแล้วค่ะ ขอส่งต่อให้เจ้าหน้าที่ดูแลนะคะ จะตอบกลับภายใน 30 นาทีในเวลาทำการค่ะ
- ตอนนี้นอกเวลาทำการ (09:00–18:00 น.) เจ้าหน้าที่จะตอบกลับวันทำการถัดไปค่ะ
- ขออภัยค่ะ ยังไม่เข้าใจคำถาม รบกวนเลือกจากเมนูด้านล่าง หรือพิมพ์ "ติดต่อเจ้าหน้าที่" ได้เลยค่ะ
- สวัสดีค่ะ ข้อความนี้ตอบโดยผู้ช่วยอัตโนมัติ อ่านนโยบายความเป็นส่วนตัวได้ที่ {link} ค่ะ
