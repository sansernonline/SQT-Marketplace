<!-- merged from skill `e-tax-invoice` on 2026-11-27 · description was: Use when a Thai VAT business issues or checks tax invoices -->
# Thai Tax Invoice and e-Tax Invoice

If a tax invoice misses even 1 required field, the buyer cannot claim the input VAT. This is general information, not tax advice. The Revenue Department (etax.rd.go.th) and the company accountant have the final say.

## 1. Who must issue what

| Who | Document |
|---|---|
| VAT-registered seller, every sale of goods or service | **ใบกำกับภาษี (full tax invoice)** — issued at the tax point (delivery of goods / receipt of payment for services) |
| VAT-registered retailer selling to consumers, with RD approval | may issue **ใบกำกับภาษีอย่างย่อ (abbreviated)** instead |
| Not VAT-registered | **cannot** issue a tax invoice; issue an ordinary receipt/invoice (see `thai-business-docs`) |

## 2. Full tax invoice — fields required by ม.86/4

| # | Field | Common mistake |
|---|---|---|
| 1 | The words **"ใบกำกับภาษี"** shown prominently | Titled only "ใบเสร็จรับเงิน" |
| 2 | Seller's **name, address and 13-digit tax ID** | Old address after moving office |
| 3 | Buyer's **name and address**; and, per อธิบดี notice ฉบับที่ 199, the buyer's tax ID and **branch** ("สำนักงานใหญ่" or "สาขาที่ 00001") when the buyer is VAT-registered | Branch missing |
| 4 | **Serial number** of the invoice (and book number, if any) | Duplicated numbers across branches |
| 5 | Name, type, kind, quantity and value of goods/services | "ค่าบริการ" with no description |
| 6 | **VAT amount shown separately** from the price | VAT folded into the total |
| 7 | **Date** of issue | |
| 8 | Seller's branch ("สำนักงานใหญ่" / "สาขาที่ ...") and any other item set by อธิบดี | |

- Language Thai, currency baht; foreign language/currency allowed only with RD approval or under the RD notice that allows English with baht figures (รอยืนยัน the current notice before relying on it).
- Combined documents are fine — "ใบแจ้งหนี้/ใบกำกับภาษี", "ใบเสร็จรับเงิน/ใบกำกับภาษี" — as long as every field is present.
- Corrections: never alter an issued invoice; issue **ใบลดหนี้** (credit note, ม.86/10) or **ใบเพิ่มหนี้** (debit note, ม.86/9), or cancel and re-issue.

## 3. Abbreviated tax invoice (ม.86/6)

Retail to consumers only, with permission. Must show: "ใบกำกับภาษีอย่างย่อ", seller name or abbreviated name and tax ID, serial number, POS/machine number if from a cash register, description and price, price **including VAT** (state "VAT included" / ราคารวมภาษีมูลค่าเพิ่มแล้ว), date. The buyer **cannot** claim input VAT from it — a business buyer must ask for a full tax invoice.

## 4. Electronic schemes

| | **e-Tax Invoice & e-Receipt** | **e-Tax Invoice by Email** |
|---|---|---|
| Who | Any VAT-registered business (no revenue limit) | VAT-registered with revenue **not over 30 M baht/year** (รอยืนยัน — a FlowAccount article dated 19 Sep 2568 reports that a 2567 RD change lets businesses above 30 M use Time Stamp too, yet the same article still prints "not over 30 M"; rd.go.th/27659 shows nav updated 13 Feb 2025; confirm on rd.go.th before advising a >30 M client) |
| Format | XML to the ETDA standard (ขมธอ.3-2560), digitally signed with a CA certificate | PDF/A-3 attached to an email |
| Signing | Own certificate, or via a registered Service Provider | Time-stamped by the central mailbox |
| Sending | Upload to RD within the 15th of the following month (or real-time via a Service Provider) | Send to the buyer and **cc csemail@etax.teda.th** |
| Registration | Apply on etax.rd.go.th (ใบคำขอ ก.อ.01) | Register at rd.go.th/27659.html |
| Typical user | Medium/large business, ERP, high volume | SME issuing by hand from accounting software |

- Only certain email providers registered with RD may send (รอยืนยัน — sources say Gmail/Google Workspace).
- e-Receipt is also how a buyer gets an "e-Receipt" for tax incentives (e.g. Easy e-Receipt for individuals) — paper invoices do not qualify for those.
- Keep electronic records for at least 5 years, 7 recommended (`shop-books` → `references/sme-bookkeeping.md` section 2 — per a Revenue Department ruling, not yet checked against the current statute), in the original format.

## Workflow

1. Confirm VAT registration (ภ.พ.20) and annual revenue → pick the scheme from section 4.
2. Build the template with every field in section 2; number by branch.
3. For by Email: register, generate PDF/A-3, send to buyer with cc to the central mailbox — the time-stamped reply is the proof.
4. For incoming invoices: check all 8 fields before booking input VAT on the ภ.พ.30 purchase report (รายงานภาษีซื้อ). If a field is missing, ask the supplier to re-issue.
5. Add a PromptPay QR on the invoice for faster payment (`shop-books`).

## Script

Run `thai-id.mjs` to check the 13-digit tax ID (เลขประจำตัวผู้เสียภาษีอากร) of the seller or the buyer before it goes on a tax invoice. The last digit is a check digit: `(11 − (Σ digit i × (14 − i), i = 1..12) mod 11) mod 10`. A pass means the number has no typo; it does not prove the company exists (check that on the Revenue Department site). When it fails, the output says which last digit it expected.

```
node thai-id.mjs <file.json> [--json]     # example file: scripts/e-tax-invoice/example.json
node thai-id.mjs 1234567890139 ...        # or pass the numbers directly
node thai-id.mjs --self-test
```

Input file: `{ "ids": ["1234567890139", "1-2345-67890-13-9"] }` · dashes and spaces are allowed. Exit code is 0 when every number passes, 1 when any fails. Other scripts can `import { isValidThaiId } from './thai-id.mjs'`.

**Script path:** installed from the marketplace: `ls -d ~/.claude/plugins/cache/*/e-commerce/*/skills/thai-tax/scripts/thai-id.mjs | sort -V | tail -1` · in the SQT-Marketplace repo: `plugins/e-commerce/skills/thai-tax/scripts/thai-id.mjs` · Node only, no dependencies.

## Related

`thai-business-docs` · `tax-vat-th.md` (ภ.พ.30, WHT on the payment) · `shop-books` · `dbd-annual-filing.md`.

## References

- [`worked-example.md`](e-tax-invoice/worked-example.md) — open for a sample invoice header block with every required field
- [`sources.md`](e-tax-invoice/sources.md) — sources and check date 2026-10-06 for section 4
