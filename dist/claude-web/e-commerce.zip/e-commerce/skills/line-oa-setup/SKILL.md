---
name: line-oa-setup
description: Use when creating a LINE Official Account or enabling the Messaging API (tokens, webhook, quotas).
---

# LINE OA Setup

Goal: go from nothing to a Messaging API channel that answers "hello". Only the user holds the secrets.

## 1. Two consoles, two jobs

| Console | URL | Used for |
|---|---|---|
| **LINE Official Account Manager** | manager.line.biz | create the OA, buy the package, profile, greeting, auto-reply, rich menu (no-code), chat, broadcasts, **enable Messaging API** |
| **LINE Developers console** | developers.line.biz | the Messaging API channel: channel secret, access tokens, webhook URL, LIFF/LINE Login |

Since 4 Sep 2024 a Messaging API channel can **no longer be created directly** in the Developers console — create the OA in OA Manager, then Settings → Messaging API → Enable; that creates the channel under a provider you pick.

## 2. Setup steps

1. **OA Manager** — create the account (unverified is fine to start; a verified/blue badge needs business documents).
2. **Enable Messaging API** — choose or create the Provider (use the company name; providers cannot be merged later).
3. **Developers console → channel → Basic settings** — copy the **channel secret** into the server's secret store (env var `LINE_CHANNEL_SECRET`).
4. **Messaging API tab → issue a token** (see section 3) → env var `LINE_CHANNEL_ACCESS_TOKEN`.
5. **Deploy the webhook** (section 4) on HTTPS.
6. **Messaging API tab → Webhook URL → Update → Verify** (expects 200) → turn on **Use webhook**.
7. **OA Manager → Response settings** — turn **Auto-reply messages off** if the bot replies; keep the greeting message if wanted.
8. **Echo test** — add the OA as a friend, send `hello`, confirm the log shows the event and the bot replies.

## 3. Channel access token — which type

| Type | Valid for | Limit | Use when |
|---|---|---|---|
| Long-lived | no expiry | 1 per channel; reissue invalidates the old one | quick start, small internal bot |
| Short-lived | 30 days | 30 per channel | servers that can refresh |
| v2.1 (JWT assertion) | you set, up to 30 days | 30 per channel | production — key pair, rotate on schedule |
| Stateless | 15 minutes | unlimited, cannot be revoked | serverless / per-request |

ตรวจล่าสุด 2026-10-06 · แหล่ง: https://developers.line.biz/en/docs/basics/channel-access-token/

## 4. Webhook requirements

- **HTTPS** with a certificate from a widely trusted CA — self-signed is rejected.
- Return **200 fast**; process events asynchronously (queue) — LINE redelivers if no 2xx (when redelivery is on).
- **Verify `x-line-signature` before anything else**: HMAC-SHA256 of the **raw request body** with the channel secret, Base64, compared to the header. Parsing or re-serialising the JSON first breaks the check.
- Body is UTF-8; 1 POST can carry several events — loop over `events`.

Minimal Node (Express) handler: [references/webhook-node.md](references/webhook-node.md).

## 5. Packages in Thailand

| Package | Monthly fee (ex VAT 7%) | Free messages/month | Extra message |
|---|---|---|---|
| Free | 0 | 300 | not available |
| Basic | 1,280 baht | 15,000 | 0.10 baht |
| Pro | 1,780 baht | 35,000 | 0.06 baht |

ตรวจล่าสุด 2026-10-22 (หน้าทางการ LINE for Business ยืนยัน 1,280 / 1,780 บาท ไม่รวม VAT 7%) · แหล่ง: https://lineforbusiness.com/th/service/line-oa-features/broadcast-message

Counted messages = push, multicast, narrowcast, broadcast — **per recipient**. Reply messages (using a reply token) and 1:1 chat typed by staff are not counted. Quota math: `line-broadcast`.

## 6. Let Claude send messages (optional MCP)

LY Corporation publishes an MCP server for the Messaging API: `@line/line-bot-mcp-server` ([github.com/line/line-bot-mcp-server](https://github.com/line/line-bot-mcp-server)). Its README calls it a **preview**. Checked on npm 2026-10-28: version 0.5.0. It can push text and flex messages from the OA.

This plugin does not ship it, because nothing here downloads code at run time. If the user wants it, they add it to their **user** scope with the version pinned, so the token lands in their own Claude Code settings and not in the project:

```bash
claude mcp add line-bot --scope user -e CHANNEL_ACCESS_TOKEN=<from the Developers Console> -e DESTINATION_USER_ID=<optional default user> -- npx -y @line/line-bot-mcp-server@0.5.0
```

Do not put the server with a real token into the project's `.mcp.json`, because that file is meant to be committed and shared. If a project must declare it, write `"CHANNEL_ACCESS_TOKEN": "${LINE_CHANNEL_ACCESS_TOKEN}"` and keep the real value in an environment variable.

- The token stays in the user's own settings or environment. It never goes into project files or git.
- A push message counts against the monthly quota. Run the quota math in `line-broadcast` before sending to many people.
- Read the tool list in the README of the pinned version before relying on it, because a preview can change between versions.

## Rules

- Tokens and the channel secret never go into code, chat, git or logs — environment or secret store only.
- 1 provider per company; a user's LINE `userId` differs per provider, so splitting OAs across providers breaks customer matching.
- Packages and prices change — re-check lineforbusiness.com before quoting a cost.
- Collecting names, phone numbers or chat logs = personal data: add the privacy notice (`pdpa-workflow`).

## Related

`line-chatbot` · `line-broadcast` · `pdpa-workflow` · if installed: `line-richmenu` (graphic-design), `config-and-secrets`, `notifications` (software-company).
