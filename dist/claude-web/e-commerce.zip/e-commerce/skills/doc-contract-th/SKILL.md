---
name: doc-contract-th
description: Use when drafting or checking a Thai contract
argument-hint: <type> <parties> <key terms>
---

# Thai Basic Contract Draft

This skill gives a complete first draft and flags every risky clause. It is general information, not legal advice. A Thai lawyer (ทนายความ) reviews anything flagged [ให้ทนายตรวจ] before anyone signs.

## 1. Pick the contract type first

| Situation | Type (ป.พ.พ.) | Who pays stamp duty | Key law beyond the code |
|---|---|---|---|
| Staff on payroll, employer directs the work | จ้างแรงงาน (ม.575) | none — not in the stamp-duty schedule | พ.ร.บ.คุ้มครองแรงงาน (see `labour-law-basics`) |
| Deliver a result (website, renovation, design) | จ้างทำของ (ม.587) | ผู้รับจ้าง (contractor) | Withholding tax (WHT) 3% on payment (`tax-vat-th`) |
| Rent land, building, room | เช่าทรัพย์ (ม.537) | ผู้ให้เช่า (lessor) | residential landlords: สคบ. controlled-contract rules |
| Ongoing service (maintenance, retainer) | usually จ้างทำของ | ผู้รับจ้าง | |

A "freelancer" who works fixed hours under the company's orders is legally an employee — the label in the contract does not decide it.

## 2. Stamp duty (อากรแสตมป์)

| Instrument | Rate | Note |
|---|---|---|
| เช่าที่ดิน โรงเรือน สิ่งปลูกสร้าง | **1 baht per 1,000 baht** (or part) of the **total rent for the whole term** | lessor pays; ≥ 1 million baht → pay in cash/e-Stamp instead of stamps |
| จ้างทำของ | 1 baht per 1,000 baht (or part) of the fee | contractor pays; ≥ 1 million baht → cash/e-Stamp |
| กู้ยืมเงิน | 1 baht per 2,000 baht, max 10,000 | |
| ค้ำประกัน | 1 / 5 / 10 baht by amount (รอยืนยัน) | |
| สัญญาจ้างแรงงาน | none | |

Last checked 2026-10-22 · sources: https://rd.go.th/67218.html (contract for work, paid by the contractor, ≥ 1 million baht paid in cash) · https://www.rd.go.th/23006.html and https://www.rd.go.th/6162.html (stamp duty rate schedule: contract for work 1 per 1,000 · loan 1 per 2,000, maximum 10,000 · lease 1 per 1,000 — confirmed)

Stamp at signing, or pay through **e-Stamp Duty** on rd.go.th within 15 days of signing. An unstamped contract **cannot be used as evidence in a civil case** until duty plus surcharge (เงินเพิ่มอากร, several times the duty — รอยืนยัน multiple) is paid.

Worked example: office lease 25,000/month × 36 months = 900,000 → 900 baht stamp duty, paid by the lessor (often passed on by agreement — write who bears it).

## 3. Clause checklists

Full checklists for employment, lease and hire-of-work contracts: [references/clause-checklists.md](references/clause-checklists.md). Every contract has: parties with ID/tax numbers and authorised signer, recitals, scope, price and payment, term, breach and cure, termination, notices, governing law, signatures and 2 witnesses.

## 4. Red flags (mark [ให้ทนายตรวจ], never remove silently)

| Clause | Why it is risky in Thailand |
|---|---|
| Penalty (เบี้ยปรับ) far above real loss | court may reduce it (ป.พ.พ. ม.383) — draft a realistic rate, e.g. 0.1% per day capped at 10% |
| Non-compete for employees | enforceable only as far as fair and reasonable (พ.ร.บ.ว่าด้วยข้อสัญญาที่ไม่เป็นธรรม 2540) — limit area, time, field |
| Employee deposit / guarantor (เงินประกันการทำงาน) | allowed only for certain jobs, with limits under the Labour Protection Act (รอยืนยัน the ministerial rule) |
| Wage deductions beyond tax, social security (SSO), provident fund (PVD), agreed debts | restricted by ม.76 |
| Lease over 3 years not registered at the land office | enforceable for only 3 years (ม.538) |
| Landlord business keeps deposit for wear and tear | residential controlled contract: deposit + advance rent ≤ 3 months, refund in 7 days (14 if damage) — scope by number of units (รอยืนยัน) |
| One-sided termination without notice, automatic renewal, IP assigned with no fee | unfair-terms risk |
| Personal guarantee (ผู้ค้ำประกัน) | guarantor protections in ม.681–685/1; drafting errors void clauses |

## 5. When a lawyer is required, not optional

- Any [ให้ทนายตรวจ] clause above; amount above ~1 million baht or term over 3 years.
- Land, condominium, share, franchise, loan with collateral (จำนอง/จำนำ).
- Foreign party, foreign-currency payment, or arbitration abroad.
- Dismissing an employee, settlement agreements, or anything already in dispute.

## 6. Reviewing a contract the other side sent

Sellers sign more contracts than they draft: distributor or reseller deals, ad agencies, creator and influencer networks, warehouse or space leases, bulk courier accounts. Review mode reads their paper and says where it hurts.

1. **Ask which side we are** (buyer or seller, lessee or lessor, brand or creator). The same clause is fine for one side and red for the other.
2. **Read every annex and schedule first** (ภาคผนวก · เอกสารแนบท้าย · price lists, SLAs, platform terms "incorporated by reference"). Fees, penalties and exclusivity often sit there, not in the main text.
3. **Walk 8 risk areas**, each marked แดง (red: do not sign as is), เหลือง (yellow: negotiate) or เขียว (green: fine):

| Area | Mark red or yellow when |
|---|---|
| Payment terms | we are paid more than 30 days after delivery or invoice (yellow); payment depends on the other side's "approval" with no deadline (red) |
| Liability | our liability has no cap, or we indemnify them for things we do not control (red) |
| Termination | they can end at once without cause and we cannot; no cure period; we pay for stock or work already done anyway |
| Intellectual property (IP) | our brand, photos or content pass to them, or a creator's content cannot be reused in our ads after the term |
| Scope and changes | scope is vague; they may change deliverables or prices by notice without our consent |
| Non-compete and exclusivity | we may not sell on other platforms or to other customers; area, time and field not limited (same unfair-terms risk as the non-compete row in section 4) |
| Confidentiality and data | customer personal data passes without a data processing agreement (`pdpa-workflow` E) |
| Auto-renewal | renews on its own with a short window to give notice; price rises on renewal |

4. **Quote the clause word for word** (clause number and the Thai text) next to a plain explanation of what it does to us. A finding without the quoted words cannot be checked.
5. **Offer replacement wording** for each red or yellow item, and say which ones to give up first if the other side pushes back (least harm to us first).
6. Every red item stays [ให้ทนายตรวจ]. Close with the same line as the workflow below.

## Workflow

1. Identify the type (section 1) and the parties' authority (company: หนังสือรับรอง and authorised director). The other side already sent a draft → review mode, section 6, instead of steps 2–4.
2. Fill the checklist for that type; leave unknowns as `{…}` not guesses.
3. Mark [ให้ทนายตรวจ] on red-flag clauses, with 1 line on why.
4. Compute stamp duty and say who pays.
5. Close with: "ร่างนี้เรียบเรียงจากที่คู่สัญญาตกลงกัน ก่อนลงนามควรให้ทนายความตรวจ".

## Related

`labour-law-basics` · `doc-leave` · `doc-quotation` · `tax-vat-th` · `pdpa-workflow` (personal data clauses).

## เรียกเป็นคำสั่ง

`/e-commerce:doc-contract-th <type> <parties> <key terms>`

Run `doc-contract-th` with the `thai-doc-writer` agent for: **$ARGUMENTS**

Every flagged clause stays flagged until a Thai lawyer clears it. The draft sets out what the parties want; the lawyer makes sure it protects them.
