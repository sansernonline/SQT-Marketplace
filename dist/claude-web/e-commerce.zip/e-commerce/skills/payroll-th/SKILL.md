---
name: payroll-th
description: Use when running Thai monthly payroll (tax withholding, social security, provident fund, PND 1).
argument-hint: '[month|year-end] [--employees <file>]'
---

# Thai Payroll

Gross pay minus social security (SSO), provident fund (PVD) and personal income tax (PIT) = net pay. Then file and remit. This is general information, not tax advice. Check unusual cases (bonus, stock, foreign staff) with an accountant.

## 1. Monthly payroll steps

| # | Step | Output | Deadline |
|---|---|---|---|
| 1 | Close attendance: OT, unpaid leave, new joiners, leavers (see `labour-law-basics` for OT rates), then run the 9 checks in section 1a | timesheet | before cut-off |
| 2 | Compute gross: salary + OT + allowances + commission + taxable benefits | payroll register | |
| 3 | SSO 5% on wage capped at 17,500 → max 875 (see `social-security-th`) | employee + employer share | |
| 4 | PVD employee % and employer % (if the company has a fund) | | |
| 5 | PIT withholding by annualisation (section 2) | withholding tax (WHT) per head | |
| 6 | Net pay = gross − SSO − PVD − PIT − other agreed deductions | payslip | pay day per contract (at least once a month, ม.70) |
| 7 | File **ภ.ง.ด.1** and remit WHT | RD receipt | 7th next month (paper) / 15th (e-Filing) |
| 8 | File **สปส.1-10** and remit SSO (both shares) | SSO receipt | 15th next month |
| 9 | Remit PVD to the fund manager | | per fund rules |
| 10 | Archive register, payslips, receipts — keep 5 years minimum, 7 recommended (`sme-bookkeeping` section 2 — per a Revenue Department ruling, not yet checked against the current statute) | | |

Year end: **ภ.ง.ด.1ก** (annual summary per employee) by end of February; give every employee **50 ทวิ** for the year (by February, รอยืนยัน exact day) and within 1 month after anyone leaves (รอยืนยัน).

## 1a. Check the inputs before computing tax

Most payroll errors are in the timesheet and the employee list, not in the tax maths. Before step 5, run these 9 checks against the attendance file and last month's register:

| # | Flag | Usual cause |
|---|---|---|
| 1 | Clock-in with no clock-out | forgot to scan; hours unknown |
| 2 | OT far above this person's normal month | real peak, or a typing error; OT also needs the employee's consent (`labour-law-basics` section 1) and pays 1.5× or 3× (section 2) |
| 3 | Zero hours for someone who normally works | unrecorded leave, left the job, or missing file |
| 4 | Wage rate differs from last month | a raise not yet approved in writing, or a wrong row |
| 5 | Duplicate or overlapping rows | same day entered twice |
| 6 | Leave beyond entitlement | paid sick or personal leave over the yearly days in `labour-law-basics` section 3 |
| 7 | Someone paid last month is missing | resigned (final pay, `labour-law-basics` section 4) or dropped by mistake |
| 8 | New joiner with no starting documents | no ล.ย.01, no social security registration (`social-security-th`) |
| 9 | Total payroll differs from last month by more than 10% | explain it in 1 line (new staff, OT, bonus) before paying |

- Never guess a missing time or fix a row quietly. Ask the owner one person and one issue at a time, and write the answer next to the row.
- Social security uses the wage floor and cap in `social-security-th`; a wage above the cap still pays the capped amount.
- The 10% line is a starting value from Anthropic's payroll-prep skill (`anthropics/knowledge-work-plugins` small-business, Apache-2.0, read 2026-11-10; ideas only, no text copied), not measured on Thai payrolls.
- The check summary lists names and issues only, never ID card numbers or bank account numbers (`pdpa-workflow`).

## 2. PIT withholding on salary (ม.40(1)) — annualisation

Method from ม.50(1) ประมวลรัษฎากร:

1. Annual income = monthly taxable pay × number of pay periods in the year (12, or remaining months for a mid-year joiner + income already paid).
2. Less expense deduction: 50% of income, max **100,000**.
3. Less allowances the employee declared on ล.ย.01: personal **60,000**; spouse with no income 60,000; child 30,000 each (60,000 for 2nd+ child born 2561 or later); parents 30,000 each (aged 60+, income under 30,000); **SSO contributions actually paid** (up to 875 × 12 = 10,500 in 2569, รอยืนยัน); PVD employee contributions (within 15% of wage, overall retirement cap 500,000); life/health insurance as declared.
4. Apply the progressive rates → annual tax.
5. Monthly WHT = annual tax ÷ 12. Recalculate when salary changes or a bonus is paid.

| Net income (baht/year) | Rate | Tax on band | Cumulative at top |
|---|---|---|---|
| 0 – 150,000 | exempt | 0 | 0 |
| 150,001 – 300,000 | 5% | 7,500 | 7,500 |
| 300,001 – 500,000 | 10% | 20,000 | 27,500 |
| 500,001 – 750,000 | 15% | 37,500 | 65,000 |
| 750,001 – 1,000,000 | 20% | 50,000 | 115,000 |
| 1,000,001 – 2,000,000 | 25% | 250,000 | 365,000 |
| 2,000,001 – 5,000,000 | 30% | 900,000 | 1,265,000 |
| over 5,000,000 | 35% | | |

ตรวจล่าสุด 2026-10-06 · แหล่ง: https://www.rd.go.th (อัตราภาษีเงินได้บุคคลธรรมดา, ม.48) · SSO cap: https://www.infoquest.co.th/2025/550753

### Script

`payroll.mjs` ทำขั้นตอนในส่วน 2 ให้ครบ: เงินได้ทั้งปี → หักค่าใช้จ่าย → ลดหย่อน → ภาษีขั้นบันได → หาร 12 งวด พร้อมประกันสังคม (5% ของค่าจ้าง ฐานขั้นต่ำ 1,650 ถึงเพดาน ปัดเป็นบาท) และ PVD ลูกจ้าง ได้ภาษีหัก ณ ที่จ่ายต่อเดือนและเงินสุทธิต่อคน

```
node payroll.mjs <file.json> [--json]     # example file: scripts/example.json
node payroll.mjs --self-test
```

ไฟล์ input: `{ "employees": [ { "name": "...", "gross": 50000, "pvd_employee_pct": 0, "pvd_employer_pct": 0, "spouse": false, "children": 0, "children_2nd_plus": 0, "parents": 0, "other_deductions": 0, "periods": 12 } ] }` · มีแค่ `name` กับ `gross` ก็รันได้ ที่เหลือเริ่มต้นเป็น 0 / false / 12 · ช่องที่ผิดทำให้สคริปต์หยุดพร้อมข้อความที่ชื่อช่อง · ประกันสังคมคิดจากค่าจ้างเฉลี่ยต่อเดือน (`gross` × `periods` ÷ 12) แล้วกระจายเป็นต่องวด ลดหย่อนทั้งปีจึงเท่ากับ 12 เดือนเสมอ · PVD ลูกจ้างเกิน 15% ของค่าจ้างสคริปต์เตือนและลดหย่อนให้แค่ 15%

ขั้นบันไดภาษี เพดานประกันสังคม และค่าลดหย่อนอยู่ใน `scripts/rates.json` (มีวันที่ตรวจและแหล่ง สคริปต์พิมพ์ออกมาในผล และเตือนเมื่อเก่ากว่า 90 วัน) · เพดานประกันสังคมและอัตราขั้นสูงสุดถูกเช็กกับ `scripts/check/facts.json` ที่ราก repo SQT-Marketplace (ไม่ติดไปกับ plugin) · เงินสุทธิติดลบ และ PVD ที่ใส่น้อยกว่า 1 (เช่น 0.05 แทน 5) ได้คำเตือน · ปีภาษีเปลี่ยนให้แก้ `rates.json` ก่อนรันเดือนมกราคม · ยังไม่รวมโบนัส พนักงานเข้ากลางปี และเงินได้ที่จ่ายไปแล้ว ให้คิดตามส่วนโบนัสด้านล่างเอง

**Script path:** ติดตั้งจาก marketplace: `ls -d ~/.claude/plugins/cache/*/e-commerce/*/skills/payroll-th/scripts/payroll.mjs | sort -V | tail -1` · ใน repo SQT-Marketplace: `plugins/e-commerce/skills/payroll-th/scripts/payroll.mjs` · Node อย่างเดียว ไม่มี dependency

ผลเป็นข้อมูลประกอบ ไม่ใช่คำแนะนำด้านภาษี

### Worked example

Single employee, salary 50,000/month, no PVD.

| Line | Baht |
|---|---|
| Annual income 50,000 × 12 | 600,000 |
| Expense 50% capped | −100,000 |
| Personal allowance | −60,000 |
| SSO 875 × 12 | −10,500 |
| **Net income** | **429,500** |
| Tax: 7,500 + (429,500 − 300,000) × 10% | 7,500 + 12,950 = **20,450** |
| **Monthly WHT** 20,450 ÷ 12 | **1,704.17** |

Payslip: gross 50,000 − SSO 875 − WHT 1,704.17 = **net 47,420.83**.

### Bonus month

Compute tax on (annual salary + bonus) and on annual salary alone; the difference is withheld in the bonus month on top of the normal monthly WHT.

## 3. ภ.ง.ด.1 and ภ.ง.ด.1ก

- **ภ.ง.ด.1** monthly — 1 line per employee paid: tax ID, name, pay date, amount paid, tax withheld. Nil months: no return needed if nothing was paid.
- **ภ.ง.ด.1ก** yearly — totals per employee for the calendar year; must agree with the 12 ภ.ง.ด.1 returns and the 50 ทวิ issued. Differences are the usual audit question.

## 4. หนังสือรับรองการหักภาษี ณ ที่จ่าย (50 ทวิ)

Field list and fill-in template: [references/50-tawi.md](references/50-tawi.md).

## Rules

- Collect ล.ย.01 (allowance declaration) from each employee at hiring and each January — no form, only personal allowance.
- Never pay salary in cash without a signed receipt; bank transfer is the record.
- Payroll data is personal data — access-limited, see `pdpa-workflow`.
- Rates and allowances change by law each tax year; check rd.go.th before the January run.

## Related

`social-security-th` · `labour-law-basics` · `tax-vat-th` (calendar, ภ.ง.ด.3/53) · `thai-holidays` (pay day on holidays).

## เรียกเป็นคำสั่ง

`/e-commerce:payroll-th [month|year-end] [--employees <file>]`

Run `payroll-th` with the `tax-helper` agent for: **$ARGUMENTS**

Uses `social-security-th` for the SSO cap and `labour-law-basics` for OT rates. Produces the payroll register, payslip figures, and the filing dates for ภ.ง.ด.1 (7th paper / 15th e-Filing) and สปส.1-10 (15th), ending with the accountant handoff checklist.
