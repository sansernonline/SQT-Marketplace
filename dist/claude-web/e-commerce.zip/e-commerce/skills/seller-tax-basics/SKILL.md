---
name: seller-tax-basics
description: Use when a Thai individual selling online asks about tax (40(8), deemed expenses, PND 90 and 94, VAT).
---

# Seller Tax Basics (Thai individual online seller)

General information, not tax advice — confirm figures at rd.go.th or with a tax accountant (นักบัญชี / ผู้สอบบัญชีภาษีอากร) before filing. Figures are for tax year 2569 (2026) as checked below.

The Revenue Department already sees most online sales: banks and e-wallets report high-volume accounts, and large platforms report seller income. Not filing is no longer invisible.

## Workflow

1. **Classify income** — selling goods online as an individual = เงินได้ตามมาตรา 40(8) ประมวลรัษฎากร
2. **Total gross sales** for the year from every channel (platform payout reports + bank statements for LINE/Facebook), before fees
3. **Choose the expense method** — 60% deemed or actual (table below); compute both
4. **Run the 0.5% minimum-tax check** (below) — it often decides the bill for low-margin shops
5. **File half-year** ภ.ง.ด.94 for January–June sales (by 30 September; e-filing usually extends — รอยืนยัน the year's date)
6. **File full-year** ภ.ง.ด.90 by 31 March of the following year (e-filing usually extends ~8 days — รอยืนยัน), crediting tax paid with ภ.ง.ด.94
7. **Watch the value added tax (VAT) line** monthly — when sales for the year pass ฿1.8 million, register for VAT within 30 days (below)
8. **Keep records** (list below) for at least 5 years (รอยืนยัน the retention period that applies)

## Thresholds and key figures

| Item | Figure |
|---|---|
| Must file when 40(8) and other non-salary income exceeds | ฿60,000 a year single / ฿120,000 married (for filing purposes) |
| Deemed expense for buying-and-reselling goods | 60% of gross |
| Personal allowance | ฿60,000 |
| Minimum-tax check | Applies when non-salary income (40(2)–40(8)) is ฿120,000 or more: tax = 0.5% of that income; if over ฿5,000, pay the higher of normal tax and 0.5% tax |
| Personal income tax brackets (net income) | 0–150,000: exempt · 150,001–300,000: 5% · 300,001–500,000: 10% · 500,001–750,000: 15% · 750,001–1,000,000: 20% · 1,000,001–2,000,000: 25% · 2,000,001–5,000,000: 30% · above 5,000,000: 35% |
| VAT registration | Compulsory once annual sales exceed ฿1.8 million; register (ภ.พ.01) within 30 days of exceeding; then file ภ.พ.30 every month, even with zero sales: paper by the 15th, e-filing by the 23rd |
| VAT rate | 7% (reduced from the statutory 10%), extended by พ.ร.ฎ. (ฉบับที่ 807) พ.ศ. 2569 to 30 Sep 2570 |

ตรวจล่าสุด 2026-10-06 · แหล่ง: https://www.rd.go.th · https://flowaccount.com/blog/shopee-income-tax-threshold/ · https://www.thairath.co.th/money/personal_finance/finance_banking/2778210 · https://www.prd.go.th/th/content/category/detail/id/33/iid/526275 (VAT 7% to 30 Sep 2570, same source as `tax-vat-th`) · ตรวจซ้ำ 2026-10-22: พ.ร.ฎ. ฉบับที่ 807 พ.ศ. 2569 ลงราชกิจจานุเบกษา 23 ส.ค. 2569 มีผล 1 ต.ค. 2569 (ไฟล์กรมสรรพากร https://rd.go.th/fileadmin/user_upload/kormor/newlaw/dc807.pdf มีจริง แต่อ่านข้อความไม่ออก · วัน/เลขฉบับจาก lookuptax.com และข่าว — ตรวจกับราชกิจจาฯ อีกครั้ง) · 40(8) หักเหมา 60% อัตราเดียว: ข่าวกรมสรรพากร ต.ค. 2560 https://media.thaigov.go.th (ยังไม่ได้เทียบประกาศฉบับปัจจุบัน)

## 60% deemed vs actual expenses

| Use | When |
|---|---|
| **60% deemed (หักเหมา)** | Real costs are below 60% of sales (high-margin products, handmade, digital) or the seller has no receipts |
| **Actual (หักตามจริง)** | Real costs are above 60% (most resellers on thin margins) **and** every cost has a proper receipt or tax invoice: goods bought, packaging, platform fees, shipping, ads, rent |

You choose per tax year; switching to actual means you must be able to prove every baht.

## Worked example — single reseller, tax year 2569

Gross sales ฿1,200,000 (all channels). Actual costs with receipts ฿900,000. No other income, only the personal allowance.

| | 60% deemed | Actual |
|---|---|---|
| Expense | 720,000 | 900,000 |
| Net after expense | 480,000 | 300,000 |
| Less personal allowance | 60,000 | 60,000 |
| Net income | 420,000 | 240,000 |
| Tax by brackets | 7,500 + 12,000 = **19,500** | 4,500 |
| 0.5% minimum check (0.5% × 1,200,000) | 6,000 | 6,000 → higher than 4,500 and over ฿5,000 |
| **Tax payable** | **19,500** | **6,000** |

Actual expenses win, but only with receipts — and the 0.5% minimum lifts the bill from ฿4,500 to ฿6,000. Sales are under ฿1.8 million, so no VAT registration yet; as sales grow, check monthly.

### Run the script, do not add up by hand

`scripts/tax-compare.mjs` does the table above in one call: both methods, the 0.5% check and which one is cheaper. Rates live in `scripts/rates.json` with the date they were checked; the report prints that date and warns when it is older than 90 days.

```bash
node scripts/tax-compare.mjs scripts/example.json      # { "sales": 1200000, "actual_expenses": 900000 } → 19,500 vs 6,000
node scripts/tax-compare.mjs --self-test
```

**Script path:** installed from the marketplace: `ls -d ~/.claude/plugins/cache/*/e-commerce/*/skills/seller-tax-basics/scripts/tax-compare.mjs | sort -V | tail -1` · in the SQT-Marketplace repo: `plugins/e-commerce/skills/seller-tax-basics/scripts/tax-compare.mjs` · Node only, no dependencies.

`allowances` is the year's total allowances (default: personal ฿60,000 only). Salary or other income types are out of scope — use `payroll-th` or ask an accountant. Comparing sole trader against a company: `"mode": "company"`, see `thai-business-setup` section 2.

## Who reports your sales to the Revenue Department

| Reporter | Rule |
|---|---|
| Banks, e-wallets, payment providers — กฎหมาย e-Payment (พ.ร.บ.แก้ไขเพิ่มเติมประมวลรัษฎากร ฉบับที่ 48 พ.ศ. 2562) | Report accounts that **receive more than 3,000 deposits/transfers a year**, or **more than 400 transactions with a total above ฿2 million a year**, counted per institution |
| E-commerce platforms (ประกาศอธิบดีกรมสรรพากร, from accounting periods starting 1 Jan 2567) | Platforms registered in Thailand with revenue above ฿1,000 million a year keep a special account and send seller income data within 150 days after year-end |

Being reported is not a tax bill; it means the Revenue Department can compare your filing with the data.

ตรวจล่าสุด 2026-10-06 · แหล่ง: https://www.kasikornbank.com/th/kwealth/Pages/e-payment-tax.aspx · https://brandinside.asia/?p=160771 · thresholds as reported; regulation text (รอยืนยัน) at rd.go.th

## Registration

- **ทะเบียนพาณิชย์ (commercial registration)** — online sellers are required to register with the local registrar or กรมพัฒนาธุรกิจการค้า (DBD) within 30 days of starting (รอยืนยัน current exemptions); then the DBD Registered trust mark is possible
- **VAT** — see thresholds; voluntary registration earlier is allowed but adds monthly filing
- **Company** — consider when net profit regularly pushes the owner into the 25%+ bracket; ask an accountant

## Records to keep

- Platform monthly income/payout reports and fee invoices (Shopee, Lazada, TikTok Shop each provide downloadable statements)
- Bank and e-wallet statements for LINE/Facebook sales
- Purchase receipts and tax invoices for stock, packaging, shipping, ads
- Stock records (`multi-shop-stock`) — they back up the cost of goods sold
- Copies of ภ.ง.ด.94, ภ.ง.ด.90, ภ.พ.30 and payment receipts

## Related

- `marketplace-fees-pricing` — VAT `v` in the price formula after registering
- `doc-quotation` — invoices and receipts; `tax-vat-th` — VAT filing calendar
- `trading-finance` `tax-basics-th` (if installed) — other personal income (investments) in the same ภ.ง.ด.90
