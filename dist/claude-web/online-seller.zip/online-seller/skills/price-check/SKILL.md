---
name: price-check
description: Work out a selling price, or the profit on a current price, after commission, fees, shipping, VAT and margin.
argument-hint: <product> <cost> <platform> [current price, category, target margin]
disable-model-invocation: true
---

Run `marketplace-fees-pricing` with the `shop-manager` agent for: **$ARGUMENTS**

Show the full cost table in baht and the margin %. Mark every fee rate that was not confirmed in the seller's own Seller Centre as (รอยืนยัน).
