---
name: interview-prep
description: Use when preparing for a job interview
argument-hint: <company> <role> [round — hr|manager|technical|final] [th|en]
---

# Interview Prep

Prepare for **this** interview: this company, this role, this round.

## Workflow

1. **Collect** — job post, company, round type, language, interviewer names if known, date and format (on-site, Teams/Zoom, phone).
2. **Research (15 minutes)** — what the company sells, who the customers are, one recent news item, size and parent company. Write 3 facts the user can mention.
3. **Map requirements** — take the job post's top 6–8 requirements and match one story to each.
4. **Build the story bank** (Situation, Task, Action, Result (STAR), below).
5. **Prepare the hard answers** — the Thai human resources (HR) list below.
6. **Mock round** — the `interview-coach` agent prepares a 10-question practice set with a scoring rubric; the lead runs the live round with the user after the task.
7. **Logistics** — route and travel time + 20 minutes buffer; for online, test camera, mic, name display and a quiet room the day before.
8. **After** — thank-you note within 24 hours; debrief notes.

## STAR story bank

**S**ituation (1 sentence) · **T**ask (1 sentence) · **A**ction (3–4 sentences — what *you* did, say "I", not "we") · **R**esult (1–2 sentences with a number + what you learned).

Aim for 60–120 seconds spoken. Keep each story in 3 lengths, because rounds differ: a **30-second headline** (situation + result, for the HR screen and "give me an example" follow-ups) · the **90-second STAR** (the default) · a **3-minute deep version** with the trade-offs, numbers and what you would do differently, for a technical or final round that probes. Write the 90-second one first; the other two are cut and expanded from it.

Build 6–8 stories that together cover:

| Theme | Typical question |
|---|---|
| Biggest achievement | Tell me about something you are proud of |
| Conflict | A time you disagreed with your manager or a colleague |
| Failure | A time something went wrong — what did you do |
| Pressure / deadline | A time you had too much to do |
| Leadership / influence without authority | A time you convinced others |
| Learning fast | A time you had to learn something new quickly |
| Customer | A difficult customer or stakeholder |
| Initiative | Something you improved without being asked |

One story can answer several themes — tag each story with the themes it covers. Story bank template → [references/question-bank.md](references/question-bank.md).

## The questions Thai HR always asks

| Question | What they really check | How to answer |
|---|---|---|
| แนะนำตัวเอง / Tell me about yourself | Can you summarise | 60–90 s: present role → 2 results → why this job. Not your life story |
| ทำไมถึงอยากออกจากงานปัจจุบัน / Why are you leaving | Will you badmouth us later | Pull, not push: "looking for X which this role offers". Never criticise the current employer |
| เงินเดือนที่คาดหวัง / Expected salary | Fit with budget | Give a researched range, top end above target; see `salary-negotiation`. "Based on the scope and market data, I'm looking at 65,000–72,000 baht base, open to discussing the total package" |
| เงินเดือนปัจจุบันเท่าไร / Current salary | Anchor you low | You may share base honestly or redirect to expected; never inflate (they may ask for a payslip or 50 ทวิ) |
| เริ่มงานได้เมื่อไร / Notice period | Timeline | State your contract notice. Under the Civil and Commercial Code §582 the default is one pay period ahead — check your own contract, which may say 30 days or more |
| จุดอ่อน / Weakness | Self-awareness | Real but non-fatal weakness + what you do about it + evidence it is improving |
| มีแฟน / แต่งงานหรือยัง / วางแผนมีลูกไหม | (Not job-related; using it to decide may be unfair discrimination under the Gender Equality Act B.E. 2558) | You may answer briefly or redirect: "That won't affect my availability for this role" |
| ทำไมเลือกบริษัทเรา / Why us | Did you research | Use the 3 facts from Step 2 |
| เห็นตัวเองอีก 5 ปีเป็นอย่างไร | Will you stay | Growth inside this kind of role, not "your job" or "my own business" |
| มีคำถามไหม / Any questions | Interest | Always ask 2–3 (below) |

## Technical round

- Re-read the job post's tools list; for each, prepare one sentence of what you did with it and one result.
- Coding / analysis tests: talk while you think; state assumptions; do the simple working version first, then improve.
- Case or presentation: structure (problem → options → recommendation → risks); time-box to the slot minus 5 minutes for questions.
- "I don't know" answer: "I haven't used X directly; the closest is Y where I …; I would start by …".
- Portfolio / GitHub / work samples: remove confidential client data before showing anything (non-disclosure agreements still apply).

## Questions to ask them

Pick 2–3; never ask about salary or leave in the first round unless they raise it.

1. What does success look like in this role after 6 months?
2. What is the biggest challenge the team faces this year?
3. How is performance reviewed, and how often?
4. Why is the position open — new role or replacement?
5. What do you enjoy about working here? (good for building rapport)
6. What are the next steps and the timeline?

Thai versions are in the question bank reference.

## Thank-you note (within 24 hours)

Short, specific, one thing you discussed. Templates in Thai and English → [references/question-bank.md](references/question-bank.md).

## Rules

- Never claim a skill or result that is not real — it collapses in the next round or on reference check.
- Do not memorise scripts word for word; know the story beats.
- Inappropriate personal questions (religion, pregnancy plans) — answer briefly or redirect; the user decides. Note it for later if it reflects the culture.

ข้อความภาษาไทย (thank-you note, follow-up) → `human-writing` `references/thai-grammar.md` หัวข้อ 4 ระดับ สมัครงาน

Related: `resume-th-en` (stories must match the CV) · `salary-negotiation` · `polite-message-th-en` (follow-up messages) · `meeting`.

## เรียกเป็นคำสั่ง

`/personal-life:interview-prep <company> <role> [round — hr|manager|technical|final] [th|en]`

Run the `interview-coach` agent with the `interview-prep` skill: **$ARGUMENTS**

1. Confirm company, role, round type, language and date.
2. Build 6–8 Situation, Task, Action, Result (STAR) stories mapped to the job requirements.
3. List the 10 most likely questions for this round, including expected salary and why you are leaving.
4. Offer a live mock round from the practice set — the lead runs it with the user, one question at a time, scored (`interview-coach` prepares the set, it never talks to the user).
5. Prepare 3 questions for the user to ask, and the thank-you note template.
