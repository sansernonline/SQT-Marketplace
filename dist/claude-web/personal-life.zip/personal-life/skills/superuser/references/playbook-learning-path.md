# playbook · learning-path — learn a new technology step by step

Use when: the user wants to learn a language, framework or concept well enough to use it for real.
Main skill: `learning-path` · `english-tech-reading`

## ขั้นตอน (Steps — copy into the todo as written)

1. Find the answers from the information at hand: what the user already knows · which real project it can tie to · how much time per week. Put `(รอยืนยัน)` (pending confirmation) on anything unknown. Do not guess values · ใคร: หัวหน้าทีม
2. Break it into small milestones under `learning-path`. Each step must produce something that runs and ties to the real project · ใคร: `tech-mentor` ตัวใหม่
3. Give every milestone an official learning source (the maker's documentation) and a checkpoint for whether to go on or stop · ใคร: `tech-mentor` ตัวใหม่
4. Build the first milestone as a worked example — code that really runs, with its output · ใคร: `tech-mentor` ตัวใหม่
5. ตรวจ that every milestone has a verifiable outcome and that the total time does not exceed what the user has · ใคร: `reviewer` ตัวใหม่

## Done when

The plan is in steps that fit the time, and the first milestone really runs.
