---
name: goal-and-habit
description: Use when setting quarterly goals or building a habit
---

# Goals and Habits

Few goals, measured honestly, carried by habits small enough to survive a bad week.

## Workflow

1. **Brain-dump** everything the user wants this quarter. Do not filter yet
2. **Pick three, at most** — by numbers, see "Choosing goals by numbers" below. Everything else goes on a `someday` list, which is parked, not deleted
3. **Make each goal measurable** using the outcome formula below
4. **Find the lead habit** for each goal: the repeated action that produces the outcome. A goal with no habit is a wish
5. **Design the habit** with cue, routine and reward, and shrink it with the 2-minute rule
6. **Set up the tracker** using the template below, in `goals/YYYY-Qn.md`
7. **Weekly check (5 minutes)** inside `weekly-review`: tick last week, read the three goals, and choose the one adjustment for next week
8. **Week 6 midpoint**: is the goal on pace? If not, change the plan (step 9). Do not just try harder
9. **Failure review** when two weeks in a row are missed, or at quarter end. See the failure review section below
10. **Quarter end**: score each goal, write three lines of lessons, and carry forward or drop

## Choosing goals by numbers (`decision-scoring`, command `knapsack`)

1. **Budget = real free hours per week**, not wished-for hours: 168 minus sleep, work, commute, family and chores, as the user counts it from last week's calendar. Write that number first.
2. **For each brain-dump item** give: cost = hours per week it needs; value = **impact × desire**, each 1–5 by the user (impact = how much life changes if it happens; desire = how much the user wants it, not how much they should). Value is 1–25.
3. **Iron rules:** an item with a fixed deadline outside the user's control (an exam date, a tax filing) goes in with `"must": true`. Cost over the whole budget → cut or shrink the item.
4. **Run:** `node decide.mjs knapsack goals.json` — it tries every set and returns the best one for the budget · put `"max_items": 3` in the file so it never picks more than three goals. 

Example input (JSON for `knapsack`) and the result when run: [references/tracker-template.md](references/tracker-template.md)
5. A close call (the "ชุดรองลงมา" line in the result is under 10% behind the best set, starting value, not yet measured; the line appears only with 20 items or fewer) or a goal the user refuses → the user decides. Impact and desire are the user's own scores; the tool only does the arithmetic. Time budget and scores are starting value, not yet measured until a quarter of weekly checks shows the real hours.

## Outcome formula

> **Verb + measurable result + by date + measured how**

| Vague | Measurable |
|---|---|
| Get fit | Run 5 km under 35 minutes by 31 Dec, timed on the running app |
| Save more | Have ฿60,000 in the emergency account by 31 Dec, checked on the bank app on the 1st of each month |
| Learn English | Finish 60 lessons and hold a 10-minute call with a tutor without switching to Thai by 31 Dec |
| Read more | Finish 6 books by 31 Dec, logged in `reading.md` |

Rule: the user must be able to say **yes or no** on the date. "Better" and "more" are not outcomes.

## Habit design

| Part | Question | Example (run 5 km) |
|---|---|---|
| **Cue** | After what existing thing, or at what time and place? | "After I drop the kids at school on Mon, Wed and Fri" |
| **Routine** | What exactly? | Put on running shoes and run/walk 20 minutes |
| **Reward** | What feels good right after? | The podcast episode I only allow myself while running, plus the tick on the tracker |
| **2-minute version** | What is the bad-day minimum that still counts? | Put on running shoes and walk to the end of the street |

- **The 2-minute rule**: a new habit starts as something that takes 2 minutes or less. On bad days, the 2-minute version counts as done. Showing up is the habit; the volume comes later
- **Habit stacking**: "After [current habit], I will [new habit]." Attach the new habit to something that already happens every day
- **Make it easy, and make the alternative hard**: shoes by the door; the phone charger in the living room, not the bedroom
- **Never miss twice**: one miss is normal; two misses in a row is the start of a new habit of not doing it

## Tracker template

Markdown template (quarter goals table + weekly log): [references/tracker-template.md](references/tracker-template.md)

## Failure review (blame-free, 10 minutes)

1. **What happened?** The facts only: how many days were done out of how many planned
2. **When did it break?** Which day of the week, and what was different about it (travel, overtime, a sick child)
3. **Which part failed?** The cue never came / the routine was too big / there was no reward / the goal was not really wanted
4. **One change** for the part that failed: a new cue, a smaller routine, or a better reward. If the goal was not wanted, drop it openly and record why
5. Write the review in the quarter file under `## Reviews`

## Worked example

Save ฿60,000 in the emergency account by 31 Dec (cue · routine · reward · week 6 review and failure review): [references/worked-example.md](references/worked-example.md)

## Rules

- Measure the habit weekly and the outcome monthly. Daily outcome-watching discourages people
- Never shame a slip. Change the system first, then the goal
- Health goals: set the habit and the measurement; ask a doctor before strict diets or intense training

Related: `weekly-review` (the weekly check), `decision-journal` (drop or continue), `personal-budget` in `trading-finance` (money goals), `learning-path` (learning goals).
