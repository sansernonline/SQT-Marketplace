---
name: week-review
description: Run the 20-minute weekly review — done, slipped, owed to people, three priorities.
argument-hint: '[--deep]'
disable-model-invocation: true
---

Run the `weekly-review` skill: **$ARGUMENTS**

--deep adds a calendar-audit pass and a look at money/admin due next week.
