---
name: subscriptions
description: Audit recurring charges — cost per use, cancel, downgrade or keep, cancel steps, trial-end reminders.
argument-hint: <statement files or folder> [--months 3|12]
disable-model-invocation: true
---

Run the `subscription-audit` skill with the `life-admin` agent on: **$ARGUMENTS**

Produces the cost-per-use table, a decision per line, cancellation steps by billing channel (App Store, Google Play, merchant, bank auto-debit), the annual-versus-monthly break-even for anything kept, and a calendar reminder 2 days before every free trial ends. The result is appended to `subscriptions.md` with the next audit date.
