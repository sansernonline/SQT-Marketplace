<!-- merged from skill `performance-self-review` on 2026-11-27 · description was: Use when writing a self-review or promotion case -->
# Performance Self-Review

Your record is the evidence.

Not for: negotiating the raise number or an offer → `job-search`.

## Workflow

1. **Keep a brag document** all year — 5 minutes every Friday (template below).
2. **2 weeks before the review** — pull the year's entries, group them by the company's review criteria or your key performance indicators (KPIs).
3. **Frame each item as impact** (formula below). Pick the top 3–5.
4. **Fill the self-assessment** — the company form or the template in [references/templates.md](templates.md).
5. **Rate yourself honestly** — 1 level above where your manager will likely land is fine; 2 levels is not credible.
6. **Prepare the conversation** — 3 wins, 1 growth area with a plan, 1 ask (training, scope, promotion, raise). Before the form goes in, run a **reader test**: a fresh reader (a subagent that has not seen this chat, or the user in a new chat) gets only the form and answers as the manager deciding a promotion would — "what changed because of this person · which claim has no evidence · what is the ask". Method: `thesis-writing`, "Reader test".
7. **After the meeting** — send a short written recap of what was agreed.

## Brag document — weekly entry

| Date | What I did | Result / number | Who noticed (feedback, message) | Skill shown | KPI it links to |
|---|---|---|---|---|---|
| 2026-03-14 | Fixed duplicate-invoice bug in billing export | 312 duplicate invoices stopped per month | CFO thanked team on email | Problem solving | Billing accuracy |

Also save: thank-you messages, customer compliments, certificates, screenshots of dashboards (no confidential data). Store in a folder per year.

**Evidence ladder** — rank each entry by how well it would survive a sceptical reader, and lead the review with the top rung:
1. **Measured** — a number from a system or report someone else can open (dashboard, ticket count, audit result)
2. **Witnessed** — a named person said it in writing (email, chat, review comment)
3. **Shown** — the artifact exists (document, code, deck) but nobody measured its effect
4. **Claimed** — only your memory; find a proxy from rungs 1–3 before review season or leave it out

**Backfill when the document is empty** — do not start from memory. Scan the year's record first: sent mail and chat threads, calendar, closed tickets, git log and merged pull requests (developers: `git log --author=me --since=YYYY-01-01 --oneline`), delivered files. List what the record shows, then ask the user only for the result and who noticed.

## Impact framing

**Result for the business ← what I did ← how I did it.** Lead with the result.

| Activity framing (weak) | Impact framing (strong) |
|---|---|
| Ran 24 training sessions | Cut new-hire time-to-productive from 8 to 5 weeks by running 24 onboarding sessions |
| ทำรายงานยอดขายทุกเดือน | ทำให้ผู้บริหารตัดสินใจเรื่องสต็อกได้เร็วขึ้น 1 สัปดาห์ ด้วยรายงานยอดขายรายเดือนแบบอัตโนมัติ |
| Handled customer complaints | Brought complaint resolution time from 5 days to 2 and kept 3 key accounts worth 4.2 million baht a year |

Impact categories that land with Thai management: money (revenue, cost, ลดต้นทุน) · time · risk / compliance (audit, PDPA, safety) · customers · people (trained, retained).

## Self-assessment — rules

- Use numbers and dates; avoid adjectives ("excellent", "ดีมาก").
- Acknowledge one real miss and what you changed — it makes the wins believable.
- Link to company goals by name (the objectives and key results (OKR), KPI or strategic theme).
- Credit the team where it was a team result, then say your part ("I led …", "I built …").
- Keep it to one page or what the form allows.

## Asking for promotion

Promotion is usually "already doing the next level's work", not "deserve it for time served".

1. Get the next level's job description or competency framework from HR.
2. Map evidence: for each requirement, 1 or 2 brag-doc items showing you already do it.
3. Find the gap honestly; propose how to close it in 3–6 months.
4. Ask your manager early (not at the review meeting itself): "What would you need to see from me to be promoted to [level] in the next cycle?"
5. Agree measurable criteria and a date; confirm by email.
6. Re-check monthly in 1:1s.

Promotion case template (Thai and English) → [references/templates.md](templates.md).

Related: `job-search` (turning the review into a raise) · `job-search` (brag doc becomes CV bullets) · `weekly-review` in `personal-life` (the Friday habit).
