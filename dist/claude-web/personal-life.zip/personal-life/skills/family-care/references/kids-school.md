<!-- merged from skill `kids-school` on 2026-11-27 · description was: Use when a Thai family plans a child's school year -->
# Kids and School (Thailand)

A school year has 3 money peaks (enrolment, term 1 start, term 2 start) and 1 paperwork peak (enrolment or transfer). Plan for those 4 dates; the rest is routine.

General information, not tax or legal advice — the school, เขตพื้นที่การศึกษา and กรมสรรพากร are the authorities.

## The Thai school year (public schools under สำนักงานคณะกรรมการการศึกษาขั้นพื้นฐาน, สพฐ.)

| Period | Usual timing | Plan for |
|---|---|---|
| Enrolment / admission (รับนักเรียน) | ม.ค.–เม.ย.; อนุบาล/ป.1/ม.1/ม.4 have published timetables | Documents, entrance test, fees deposit |
| ภาคเรียนที่ 1 | mid-May → early October | Uniforms, books, term fees, tutoring sign-up |
| Mid-year break (ปิดภาคเรียน) | October | Camp / childcare cover |
| ภาคเรียนที่ 2 | early November → end of March | Term 2 fees, exams in Feb–Mar |
| Long break | April → mid-May | Summer course, next year's supplies |

Exact dates differ each year and for private and international schools — use the school's own calendar (ปฏิทินการศึกษา) (รอยืนยัน for any date before the school announces it).

## Fees: what is free and what is not

Public schools follow the เรียนฟรี 15 ปี policy (อนุบาล to ม.6), which funds tuition, textbooks, a uniform allowance, learning supplies and student activities — amounts per head are set by สพฐ. each year (รอยืนยัน the current figures). Parents usually still pay for: extra programmes (English Program / Gifted), extra uniforms (sports, scout), school trips, lunch top-ups, insurance, parents' association donations. Private schools charge full term fees plus a one-off entry fee.

Use [references/school-year-planner.md](school-year-planner.md) to lay fees out by month.

## Enrolment and transfer documents

| Document | New enrolment | Transfer (ย้ายโรงเรียน) |
|---|---|---|
| สูติบัตร (birth certificate) — copy | ✔ | |
| ทะเบียนบ้าน of child and parents — copy (some schools give priority by registered district) | ✔ | ✔ |
| บัตรประจำตัวประชาชน of parents/guardian — copy | ✔ | ✔ |
| Child's ID card (from age 7) — copy | ✔ (if issued) | ✔ |
| Photos (uniform, size per school) | ✔ | ✔ |
| ปพ.1 (transcript) from previous school | ป.1 not needed; ม.1/ม.4 ✔ | ✔ |
| Transfer letter / ใบย้าย and ปพ.1 from the old school | | ✔ |
| Vaccination record (สมุดสีชมพู) | often requested for อนุบาล | |
| Name/surname change certificate, guardianship papers if applicable | ✔ | ✔ |

Sign every copy "สำเนาถูกต้อง" and keep the originals in `family-legal`.

## Tutoring decision

Ask before paying: what exact gap (subject, grade, test)? For how many weeks? How will we know it worked (school mark, practice test)? Prefer short blocks (8–10 weeks) with a review over open-ended monthly fees.

## 5-minute check at home (ทบทวนความเข้าใจ)

Before paying for tutoring, or when homework comes back wrong, find out what the child actually misunderstands.

1. **Take the topic from the child's own textbook chapter or worksheet**, not from a curriculum list. The core-curriculum indicator codes of สพฐ. were not checked for this skill (ยังไม่ได้ตรวจ), so none are quoted here.
2. **1–3 questions per idea.** For multiple choice, each wrong option comes from a real common mistake, so the answer shows which mistake it is. Example (ป.3 fractions): "พิซซ่าแบ่ง 4 ชิ้นไม่เท่ากัน กินไป 1 ชิ้น กินไป 1/4 ไหม" — a child who says yes thinks the bottom number counts pieces, not equal parts.
3. **A short guide for the parent:** "ตอบแบบนี้ แปลว่า … ลองทำต่อแบบนี้ …", one line per wrong option.
4. **Positive, specific words only.** Say what the child did ("นับชิ้นถูก แต่ยังไม่ได้ดูว่าชิ้นเท่ากันไหม"), never อ่อน · โง่ · ตามไม่ทัน.
5. Same gap in 2 checks a week apart → that gap is what tutoring is for (decision questions above). The agent does not make up exam questions "from the real test".

## Tax and grants pointer

| Item | Amount | Notes |
|---|---|---|
| Child deduction (ลดหย่อนบุตร) | 30,000 บาท/คน | Child under 20, or under 25 and studying, with income below the limit |
| Second child onward born 2561 or later | 60,000 บาท/คน | |
| Pregnancy and childbirth (ฝากครรภ์และคลอดบุตร) | up to 60,000 บาท/ครรภ์ | Receipts from hospital |
| เงินอุดหนุนเพื่อการเลี้ยงดูเด็กแรกเกิด (child support grant) | 600 บาท/เดือน to age 6 (รอยืนยัน) | Household income test; register at the local administrative organisation (องค์กรปกครองส่วนท้องถิ่น · อปท.) / district (รอยืนยัน current criteria) |

For planning which parent claims which child, and the full list, use `trading-finance` `income-tax-th` (if installed).

## Workflow

1. **Calendar** — copy the school's ปฏิทินการศึกษา into the family calendar: term starts, exam weeks, parent meetings, holidays
2. **Fees** — list every fee by month in the planner; add uniforms, books and supplies the month before term
3. **Documents** — 2 months before enrolment, run the checklist above; make 3 sets of signed copies
4. **Health** — check the vaccination record against the school's request; dental and eye checks in the April break
5. **Tutoring** — use the decision questions; review at the end of each block
6. **Tax** — at year end, collect birth certificates and hospital receipts for `trading-finance` `income-tax-th` (if installed)

## References

- [`school-year-planner.md`](school-year-planner.md) — fee planner by month and a worked example for 2 children
- [`sources.md`](kids-school/sources.md) — tax deduction sources (checked 2026-10-06) and credits

## Related

`family-week` (lunch boxes) · `elder-care.md` (grandparent pick-up roster in the handoff note) · `trading-finance` `income-tax-th` (if installed) · `trading-finance` `budget-and-debt` (if installed) · `family-legal`
