---
name: linkedin-profile
description: Use when creating or improving a LinkedIn profile for a Thai job search (headline, About, keywords).
---

# LinkedIn Profile (Thai market)

Recruiters in Thailand search LinkedIn mostly in English, by job title + skill + location. The profile must match those searches and then convince in the first 2 lines.

## Workflow

1. Pick 1–2 **target roles** (the job titles you want to be found for).
2. Collect 10–15 **keywords** from 5 real job posts for those roles (JobsDB + LinkedIn). Count which words repeat.
3. Write the **headline** (formula below).
4. Write the **About** section.
5. Rewrite **Experience** bullets — copy from `resume-th-en` (action + result + number).
6. Fill **Skills** — top 5 pinned should be the post keywords.
7. Add **Featured** items.
8. Set **location, open-to-work and contact** settings.
9. Run the checklist.

## Headline formula (up to 220 characters)

**Target title | specialty or domain | proof point | keyword**

| Weak | Strong |
|---|---|
| Accountant at ABC Co., Ltd. | Senior Accountant \| Manufacturing & SAP FI \| Cut month-end close 9→5 days \| IFRS/TFRS |
| Looking for opportunities | Data Analyst \| SQL · Power BI · Python \| Retail & e-commerce analytics \| Bangkok |
| วิศวกร | Project Engineer \| EPC & Solar PV \| 12 MW delivered on time \| PMP \| EEC Thailand |

Do not write "unemployed", "seeking", or only the employer name. Write the headline in English even if the About has Thai, because most searches are in English.

## About section — 4 short paragraphs

1. **Hook** (first 2 lines show before "see more") — who you are + strongest result.
2. **What you do** — domain, typical problems you solve, tools.
3. **Proof** — 3 bullet results with numbers.
4. **Call to action** — what you are open to and how to contact you.

Optional: a short Thai paragraph at the end for Thai-company recruiters ("ยินดีพูดคุยเรื่องโอกาสงานด้าน …").

Example hook:
> I help manufacturers close their books faster and pass audits cleanly. 6 years in accounting for automotive parts; cut month-end close from 9 to 5 days with SAP automation.

## Thai market keywords (examples by function)

These are recruiter search terms, kept as written — not text to paste in unchanged. Use only the ones that are true for you.

| Function | Keywords recruiters search |
|---|---|
| Finance / accounting | TFRS, IFRS, SAP FI/CO, month-end closing, consolidation, BOI, transfer pricing, CPA (ผู้สอบบัญชีรับอนุญาต) |
| Software / IT | Java, .NET, React, Node.js, AWS / Azure, Kubernetes, SAP ABAP, PDPA, ISO 27001 |
| Data | SQL, Power BI, Tableau, Python, data warehouse, dbt, Looker |
| Engineering / manufacturing | Lean, Six Sigma, TPM, IATF 16949, ISO 9001, EEC, PLC, AutoCAD |
| HR | HRBP, C&B, payroll, Thai labour law, SSO, PVD, talent acquisition |
| Sales / marketing | B2B, key account, modern trade, e-commerce (Shopee / Lazada / TikTok Shop), CRM, LINE OA |
| Supply chain | procurement, S&OP, WMS, customs, BOI, FTA, Incoterms |

Language skills: list Thai (Native), English with level, plus Japanese / Chinese if any — Japanese companies are a large employer group in Thailand and search JLPT levels.

## Featured

Pin 2–4: a portfolio link, a public case study or article, a presentation, a certificate. Nothing confidential from an employer.

## Recommendations

Ask for 2–3, from a manager, a client and a peer — one each. Make it easy: send a 2-line brief of what to mention (the project, the result with a number) and offer to write one back. Recruiters read these as references before they call; an empty section reads as "nobody would".

## Settings

- Location: city (e.g. Bangkok, Thailand) — recruiters filter by it
- Open to work: "Recruiters only" if still employed (your employer's recruiters may still see it — LinkedIn says it tries to hide it but cannot guarantee)
- Custom URL: linkedin.com/in/firstname-lastname
- Photo: face filling ~60% of the frame, plain background; banner 1,584 × 396 px with domain or city — keep the left third clear where the photo overlaps on desktop (banner size as commonly published; LinkedIn help page for personal profiles not found on 2026-10-23 → รอยืนยัน)
- Contact: email you check; no phone number in public fields

## Checklist

- [ ] Headline has target title + 2 keywords + proof
- [ ] About first 2 lines stand alone
- [ ] Each role has 2–4 result bullets
- [ ] Top 5 skills match job-post keywords
- [ ] Profile and CV dates and titles match exactly
- [ ] No confidential numbers (client names, unpublished revenue) without permission

ข้อความภาษาไทย (ย่อหน้าไทยท้าย About) → `human-writing` `references/thai-grammar.md` หัวข้อ 4 ระดับ สมัครงาน

Related: `resume-th-en` · `salary-negotiation` · `interview-prep`.
