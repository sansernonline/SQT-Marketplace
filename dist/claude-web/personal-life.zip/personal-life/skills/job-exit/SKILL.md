---
name: job-exit
description: Use when laid off, resigning or signing an exit agreement
---

# Job Exit — the employee's side (ถูกเลิกจ้าง · ถูกขอให้ลาออก · ลาออกเอง)

> **One rule:** sign nothing on the day. Ask for time to read, keep the evidence, and compare every number with the rights table below first. This skill puts facts and documents in order; it never decides whether a dismissal was fair.

General information, not legal advice (ข้อมูลทั่วไป ไม่ใช่คำปรึกษากฎหมาย). The law behind the numbers is the Labour Protection Act (พ.ร.บ.คุ้มครองแรงงาน พ.ศ. 2541 and amendments). Its sections, the severance table and notice rules live in `labour-law-basics` (e-commerce) and are **not restated here**, so there is one copy to keep current.

## Use when / not when

| Situation | Use |
|---|---|
| HR calls a meeting and hands over a termination letter · asked to sign a resignation or a "mutual agreement" · quitting and wants final pay right | this skill |
| How many days of severance, notice rules, section numbers | `labour-law-basics` (e-commerce, if installed) sections 4–5 |
| The employer's side: how to terminate correctly | `labour-law-basics`, "Termination checklist" in its reference |
| Unemployment benefit details, section 39 contributions | `social-security-th` (e-commerce, if installed) |
| Preparing a complaint or a visit to a lawyer | `legal-help-prep` |
| Starting the next job | `new-job-first-90-days` |
| Is the dismissal fair, how much to sue for | a labour lawyer or the labour office — this skill only lists the facts to bring |

## 1 · On the day — step back

Say, in writing if possible: "ขอรับเอกสารกลับไปอ่านก่อนนะครับ/คะ จะตอบภายในวันที่ …". Pressure to sign today ("ถ้าไม่เซ็นวันนี้จะไม่ได้อะไรเลย") is a reason to slow down, not to hurry. Ask for copies of everything shown in the meeting.

## 2 · Keep the evidence (before access is cut)

- [ ] Employment contract, offer letter, job description, work rules (ข้อบังคับเกี่ยวกับการทำงาน)
- [ ] Payslips for the last 12 months, bonus and commission terms
- [ ] The termination letter, or the resignation or agreement form they want signed — note whether a reason is written in it
- [ ] Warning letters, if any, with dates
- [ ] Chats and emails about the exit, as screenshots with date and time
- [ ] Time records if overtime is unpaid

Keep only your own employment papers. Copying company data you have no right to take can create a new problem.

## 3 · Rights table — check every row before signing

| Item | What to check | Rule lives in |
|---|---|---|
| Severance (ค่าชดเชย) | Days of service from the start date (probation counts) × the band in the table | `labour-law-basics` §5 (ม.118, ม.119 exceptions) |
| Pay in lieu of notice (สินจ้างแทนการบอกกล่าวล่วงหน้า) | Was notice given on or before a pay day? If not, how much is owed | `labour-law-basics` §4 (ม.17, ม.17/1) |
| Wages, overtime, commission still owed | Amounts and the pay date | `labour-law-basics` §4 (ม.70) |
| Unused annual leave | Days left this year, paid out | `labour-law-basics` §4 (ม.67) |
| Bonus and benefits in the contract | Pro-rata rules in the contract or work rules | the contract |
| Provident fund (กองทุนสำรองเลี้ยงชีพ) | Vesting of the employer's share, keep or move | the fund's rules · `retirement-plan` (trading-finance, if installed) |
| Unemployment benefit | Laid off and resigned are paid differently; register in time (section 5) | `social-security-th` · sso.go.th |
| Tax on the final pay | Severance under the labour law has its own tax treatment | section 5 · `labour-law-basics` `references/leave-and-severance.md` item 9 (e-commerce, if installed) or an accountant |
| Work certificate (หนังสือรับรองการทำงาน) | Ask for it; the employer must issue one on request | `labour-law-basics` termination checklist |

Write the expected amount next to each row, and the section from the "Rule lives in" column (ม.118 · ม.17 · ม.67 …) so the user can check it, even when `labour-law-basics` is not installed. A row you cannot work out stays `[ตรวจ]` and goes to the labour office or a lawyer; do not guess it.

## 4 · Papers they ask you to sign

- **Resignation letter (ใบลาออก) when you did not choose to leave:** severance in the table is for a termination by the employer. Signing a resignation can be read as leaving by choice, which changes severance and the unemployment rate. Ask the labour office before signing (section 6) (รอยืนยัน).
- **Mutual agreement or release (ข้อตกลงเลิกจ้าง · หนังสือสละสิทธิ์/ปลดเปลื้อง):** compare the sum with the rights table first. A clause saying you give up all further claims needs a lawyer or the labour office to read it before you sign.
- Sign only the version you read. Write the date. Keep a copy or a photo of the signed page.

## 5 · The first 30 days after leaving

- **Register as unemployed within 30 days** of the last working day, on the Department of Employment's site (the SSO page names e-service.doe.go.th). Registering later still works, but the benefit counts only from the day you register. The benefit needs at least 6 months of contributions within the 15 months before leaving. sso.go.th, unemployment benefit page, viewed 2026-11-10.
- **How much is paid** differs for laid off and for resigned or contract ended. The figures and the wage cap are kept in `social-security-th`. The SSO page viewed 2026-11-10 still shows 50% for up to 180 days (laid off), 30% for up to 90 days (resigned) and a 15,000 บาท cap, while `social-security-th` records a newer rate and cap from 2568–2569. Ask 1506 which one applies to you (รอยืนยัน).
- **Keep social security under section 39:** possible if you paid under section 33 for at least 12 months; apply within 6 months of leaving (form สปส. 1-20). sso.go.th, section 39 page, viewed 2026-11-10.
- **Tax on severance:** severance under the labour law for leaving not by choice is exempt up to the last 400 days' wages and no more than 600,000 บาท; with 5 years of service or more you may choose to tax it separately from other income on the ภ.ง.ด.91 attachment. Revenue Department, PND 91 instructions for tax year 2568, viewed 2026-11-10. Details → `labour-law-basics` `references/leave-and-severance.md` item 9 (e-commerce, if installed); working it out with your own figures and the withholding → an accountant.

## 6 · Where to complain

| Channel | What it does | Contact |
|---|---|---|
| Department of Labour Protection and Welfare (กรมสวัสดิการและคุ้มครองแรงงาน) | Questions about rights; complaints about unpaid money | hotline **1546** (or 1506 then 3) |
| Labour inspector (พนักงานตรวจแรงงาน), form **คร.7** | When the employer does not pay wages, overtime, holiday pay, severance or a deposit owed. File with the inspector where you worked or where the employer is based, or online; decided within 60 days, extendable by 30 | provincial labour office · online via s90.labour.go.th/e_request |
| Free legal aid | Before signing a release, or when going to the labour court | see `legal-help-prep`, section 6 |

Preparing the visit (facts table, deadlines, contact log) → `legal-help-prep`.

## Quitting by choice (ลาออกเอง)

1. Give written notice following the contract; the minimum notice rule is in `labour-law-basics` §4.
2. Before the last day, list the final pay items from the rights table (wages, leave, bonus terms, provident fund) and ask HR for the pay date in writing.
3. Ask for the work certificate and the 50 ทวิ for the year.
4. Unemployment and section 39 → section 5.

## Check before sending

- [ ] The first line tells the user not to sign today
- [ ] Every number points to `labour-law-basics` or an official page with date; none restated from memory
- [ ] Every rights row names its section (ม.118 severance · ม.17 notice · ม.67 leave)
- [ ] Every row the agent could not compute is `[ตรวจ]`
- [ ] Says it is not legal advice, and no ruling on fairness

## References

- [`references/worked-example.md`](references/worked-example.md) — open for a full example of a "mutual agreement" offer
- [`references/sources.md`](references/sources.md) — official pages viewed 2026-11-10 (SSO · Revenue Department · labour office)
