---
name: polite-message-th-en
description: Use for an awkward everyday message in Thai or English
---

# Polite Messages in Thai and English

Say the hard thing clearly. Politeness belongs in the wording, not in hiding the request.

## Workflow

1. **Situation**: what the message is for (ask / decline / chase payment / apologise / complain / follow up), who it goes to, through which channel (LINE, email, letter), and what the user wants to happen
2. **Register**: choose it from the relationship using the register table. When unsure, go one step more formal; it is easier to relax later
3. **Tone level**: choose it on the tone ladder. The first contact is level 1 or 2. Move up one level per reminder, never two
4. **Draft**: if the user has a voice profile (next section), write in that voice. Start from [references/templates.md](references/templates.md). Every message needs: greeting → context in one line → **the request or point, with a date** → a softener → sign-off
5. **Check**: the request is in the first 3 lines; there is one ask per message; numbers, dates and amounts are exact; there is nothing the user would regret if it were forwarded
6. Give both Thai and English when the reader may use either. They are written for the same tone, not translated word for word

## Voice profile — sound like the user, not like a template

A message sent in the user's name must read as theirs. The profile lives in the user's own file `~/.claude/voice-profile.md`, never in this plugin, because it holds their real writing. Read it before drafting. If it is missing, use the register table and offer once to build one.

**Build it from real sent messages, 15–30 of them** (LINE chats, emails, letters the user is happy with). Fewer than 3 samples → say so and ask for 3. Do not guess a voice; a guessed voice is the generic tone the user wants to avoid.

| Trait | Capture exactly |
|---|---|
| Greeting · sign-off | The real form: "สวัสดีครับคุณเอ" vs "คุณเอครับ" · "ขอบคุณครับ" vs name only |
| Particles · pronouns | ครับ/ค่ะ/นะครับ — where and how often · ผม / เรา / ชื่อเล่น |
| Sentence length · ask timing | Short or long · which line the request lands on |
| Softeners | How often รบกวน / ขออนุญาต / just checking appear |
| Their own words | What they call their product or service, phrases they repeat verbatim |
| **Never uses** | Words and structures absent from every sample. This matters most: one phrase the user never says tells the reader someone else wrote it |
| Sample | One short real message, verbatim, as the reference |

**Every edit the user makes to a draft is a signal.** Ask in one line what the change was about, then append it to the profile with the date (`Updated: 2026-11-10 — cut "อาจจะตกหล่นไป", user: sounds fake`). Append, do not overwrite, so a correction never needs making twice.

Keep out of the profile: account numbers, ID numbers, phone numbers, addresses and anything about the people the messages went to. Store the user's words only, and replace names in the sample with roles.

## Thai register table

| Element | Casual (friend, peer) | Polite (colleague, customer, เจ้าของร้าน) | Formal (senior, official, ผู้ใหญ่, letter) |
|---|---|---|---|
| End particle | ครับ / ค่ะ, sometimes นะครับ / นะคะ | ครับ / ค่ะ at the opening, the close, and after the request; not on every sentence (`human-writing` `references/thai-grammar.md` f4, f6) | ครับ / ค่ะ; in letters, no particle, formal verbs instead |
| "You" | เธอ / ชื่อเล่น / พี่ / น้อง | คุณ + first name | ท่าน, or คุณ + full name + position |
| "I" | เรา / ชื่อเล่น | ผม / ดิฉัน (ฉัน in LINE) | ผม / ดิฉัน / กระผม (very formal) |
| Asking | ช่วย...หน่อยได้ไหม | รบกวน...ด้วยครับ/ค่ะ | ขอความกรุณา... / ใคร่ขอความอนุเคราะห์... |
| Permission | ขอ...นะ | ขออนุญาต...ครับ/ค่ะ | ขออนุญาต... / จึงเรียนมาเพื่อโปรดพิจารณา |
| Thanks | ขอบใจนะ / ขอบคุณนะ | ขอบคุณมากครับ/ค่ะ | ขอขอบพระคุณเป็นอย่างสูง |
| Sorry | โทษที / ขอโทษนะ | ขออภัยครับ/ค่ะ / ขอโทษด้วยครับ/ค่ะ | ขออภัยเป็นอย่างสูง / ต้องขออภัยในความไม่สะดวก |

Notes:
- **รบกวน** literally means "to disturb". It is the default polite opener for a request: รบกวนส่ง...ภายในวันศุกร์ได้ไหมครับ
- **ขออนุญาต** before doing something to someone: ขออนุญาตทวงถาม... (permission to follow up) softens a payment chase
- **ท่าน** sounds stiff in LINE between peers. Keep it for seniors and for formal letters
- For formal letters (หนังสือราชการ), use `doc-thai-official` in `e-commerce` (if installed)

## English register in brief

| Casual | Polite (default) | Formal |
|---|---|---|
| Can you…? | Could you…? / Would you be able to…? | I would be grateful if you could… |
| Sorry, I can't | Unfortunately I won't be able to… | I regret that I am unable to… |
| Just checking… | I wanted to follow up on… | I am writing to follow up on… |

## Softening phrases

| Thai | English | Use |
|---|---|---|
| ไม่ทราบว่า...สะดวกไหมครับ/คะ | Would it be possible to…? | Before a request |
| ถ้าไม่เป็นการรบกวน | If it's not too much trouble | A favour |
| เข้าใจว่าช่วงนี้อาจจะยุ่ง | I understand things may be busy | Chasing a slow reply |
| อาจจะตกหล่นไป | It may have slipped through | Assuming no bad intent |
| ขอบคุณล่วงหน้านะครับ/คะ | Thanks in advance | Closing a request |
| เสียดายมากที่ครั้งนี้... | I'm sorry that this time… | Declining |

Do not stack softeners. One or two per message; more sounds sarcastic or unsure.

## Tone ladder

| Level | Name | Thai marker | English marker | When |
|---:|---|---|---|---|
| 1 | Gentle | อาจจะตกหล่นไป, รบกวนช่วยดู... | Just a gentle reminder… | First nudge, a good relationship |
| 2 | Clear | ขอติดตามเรื่อง... ครบกำหนดวันที่... | Following up on… which was due on… | First formal follow-up |
| 3 | Firm | ขอความกรุณาดำเนินการภายในวันที่... | Please arrange this by… | Second reminder, no reply |
| 4 | Final | หากไม่ได้รับภายในวันที่... จำเป็นต้อง... | If we do not receive this by…, we will… | Last notice: state the consequence |
| 5 | Formal action | A letter (หนังสือทวงถาม), registered post | Formal demand letter | Hand to a lawyer or a debt process |

Rules for the ladder:
- Every level states the **exact amount, the reference and the date**
- Level 4 names a consequence the user **will really carry out**. An empty threat ruins level 5
- Stay polite at every level. Firm means specific and dated, not rude

## Worked example — chasing an unpaid invoice (LINE, to a small client)

- Day +3 after the due date, level 1: "สวัสดีครับคุณเอ ขออนุญาตทวงถามใบแจ้งหนี้ INV-2026-031 ยอด 18,500 บาท ครบกำหนดวันที่ 30 ก.ย. ครับ อาจจะตกหล่นไป รบกวนช่วยตรวจสอบให้หน่อยนะครับ ขอบคุณครับ"
- Day +7, level 2: "...ขอติดตามใบแจ้งหนี้ INV-2026-031 ยอด 18,500 บาท ซึ่งครบกำหนดวันที่ 30 ก.ย. ครับ ยังไม่เห็นยอดเข้า รบกวนแจ้งวันที่คาดว่าจะโอนด้วยนะครับ"
- Day +10, level 3: "...ขอความกรุณาโอนชำระภายในวันศุกร์ที่ 16 ต.ค. นี้ครับ หากมีปัญหาเรื่องเอกสารแจ้งได้เลยครับ"
- Day +20, level 4: "...หากไม่ได้รับชำระภายในวันที่ 31 ต.ค. ผมจำเป็นต้องหยุดงานส่วนที่เหลือไว้ก่อนจนกว่าจะเคลียร์ยอดนี้ครับ"

Chasing several credit customers at once (check which payments already arrived, grade each payer, a summary table before any draft) → `doc-quotation` section 6 (plugin `e-commerce`, if installed). This skill then words each message.

Related: `meeting` (plugin `personal-life`, Leg 2 — written follow-up after a meeting). Optional, if installed: `inbox-triage` (plugin `personal-life` — which messages to answer first) · `doc-thai-official` and `doc-quotation` (plugin `e-commerce` — formal letters and quotes).

## Sources

- Voice profile idea: anthropics/knowledge-work-plugins `small-business/shared/voice-profile.md` (Apache-2.0 · read 2026-11-10 · reworded, not copied) https://github.com/anthropics/knowledge-work-plugins/blob/main/small-business/shared/voice-profile.md
