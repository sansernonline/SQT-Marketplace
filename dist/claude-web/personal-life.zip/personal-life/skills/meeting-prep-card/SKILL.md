---
name: meeting-prep-card
description: Use when a meeting that matters is about 15 minutes away. One card with goal, three questions, asks.
---

# Meeting Prep Card

One page, fifteen minutes before you walk in. If you cannot fill the goal line, the meeting is not ready.

## Workflow (15 minutes)

1. **Read the invite** — organiser, attendees, agenda, attachments. No agenda → ask for one or propose one (wording below).
2. **Pick the meeting type** from the table — it sets what "done" looks like.
3. **Pull context** — last meeting's summary and open actions (`meeting-summary`), recent mail thread, the numbers you might be asked.
4. **Fill the card** (template below).
5. **Bring the card** to the meeting and tick it during; it becomes the skeleton for the summary.

## Meet, write or wait — the gate before the card

| Found in step 1–2 | Verdict | What to do instead |
|---|---|---|
| No decision, no open question, no ask that needs these people together | **Async** | Write the update and send it; propose cancelling with that text attached |
| A decision is needed but the options, numbers or the decider are not ready | **Not ready** | Move the meeting; send what is missing and a date |
| A decision, a disagreement to settle, or a relationship that needs a face | **Meet** | Fill the card |

Apply the gate to meetings the user organises; for meetings the user is invited to, it decides whether to attend or send a written input.

**Go, or send it in writing — by numbers.** Go when either is true:
1. The user **owns the decision** (the one who says yes or no), or
2. **Value of the decision > people-hours in the room × hourly rate.** Room cost = attendees × meeting hours × hourly rate (monthly pay ÷ working hours per month, the user's own figures; use the average of the room if unknown, marked `(รอยืนยัน)`). Value of the decision = what the user would gain or avoid losing in baht if this meeting changes the outcome (the user's estimate, starting value, not yet measured).

Example: 6 people × 1 hour × 400 baht = 2,400 baht; a decision that moves a 50,000 baht quote passes, a status round with no decision does not. Neither is true → send a written input (the Async row) and offer to join only if a question comes back. Close call (value within about 2 times the room cost, starting value, not yet measured) → the user decides. No script needed; it is one multiplication.

> **If the meeting is a day or more away** (decision meetings): draft a one-page note or your questions to send about 24 hours ahead — people decide faster when they have read it. Draft only; send only when the user says send.

## Meeting types

| Type | Goal sounds like | Your prep focus |
|---|---|---|
| Decision | "We choose A or B today" | Options, recommendation, cost of delay, who decides |
| Status / update | "Everyone knows where X stands" | Could it be a written update instead? Bring blockers only |
| Problem-solving | "We agree the cause and next step" | Facts and data; separate symptoms from causes |
| Negotiation (vendor, salary, landlord) | "Agreement on price/terms within my range" | Your target, your walk-away, their likely asks, BATNA (best alternative if no deal) |
| Relationship / 1:1 | "I understand their priorities" | Two open questions, one thing to give |
| Client / ผู้ใหญ่ (senior) meeting | "They approve / feel heard" | Lead with the conclusion; short deck; Thai courtesy — greet the most senior first, let them speak first |

## The card

```
Meeting: ______  Date/time: ______  Type: ______
Goal (what is true when I leave): ______________________
Three questions I must ask:
  1. ______  2. ______  3. ______
Context: people (role, last interaction) · last decisions · open actions · numbers
My asks (what · from whom): ______
Likely objections → my answer: ______
Walk-away line (if it goes nowhere): ______
Next step I will propose: ______ by ______
```

## Useful lines

- No agenda: "เพื่อให้ใช้เวลาได้คุ้ม ขอเสนอวาระ 3 ข้อ … ถ้ามีเรื่องอื่นเพิ่มได้เลยครับ/ค่ะ" / "To use the time well, may I suggest three items …"
- Walk-away: "เรื่องนี้ขอกลับไปเช็กข้อมูลแล้วแจ้งภายในวันศุกร์นะครับ/คะ" / "Let me confirm the figures and come back by Friday."
- Ending a drifting meeting: "Before we close — what did we decide, and who does what next?"

## Worked example

Landlord meeting, Saturday 10:00, lease renewal. Type: negotiation.
- Goal: renew 1 year at ≤ 15,000/month (current 14,000; landlord hinted 16,500).
- Questions: 1) what drives the increase? 2) will the aircon be serviced before renewal? 3) can the deposit roll over unchanged?
- Context: paid on time 24 months; similar units in the building listed 15,000–15,500 (screenshots saved).
- Asks: aircon service in writing; 2-year term option at 15,000.
- Walk-away: "ขอคิดดูก่อน แล้วแจ้งภายในวันพุธ" — then view two other units.
- Next step: signed renewal by 25th.

## Rules

- Fits on one page or it does not get used
- No goal → propose an agenda or decline politely; for-your-information (FYI) meetings can often be a document
- Recurring meetings: one running card per meeting, updated each week
- Never put passwords, salaries of others, or personal data you do not need on the card

Related: `meeting-summary` (after) · `calendar-audit` (meetings worth keeping) · `polite-message-th-en` (agenda request, decline).
