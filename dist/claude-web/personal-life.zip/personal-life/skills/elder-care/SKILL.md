---
name: elder-care
description: Use when a Thai family cares for an elderly parent
---

# Elder Care (Thailand)

Organise, remind and prepare. This skill never diagnoses, never suggests a medicine and never changes a dose — it copies what the doctor and the medicine label say and turns worries into questions for the next appointment.

General information, not medical or legal advice — ask the doctor or pharmacist (เภสัชกร) about medicines and the local องค์การปกครองส่วนท้องถิ่น (อปท.) or สำนักงานหลักประกันสุขภาพแห่งชาติ (สปสช.) about rights.

**Privacy:** the profile card holds the ID number, blood group, conditions and allergies. Keep it in a private place (`important-docs`, or a locked note), not in a shared family folder. Never post the ID number or medical details to a group chat; a shareable week table shows "ยา ตามตาราง" and a time, not drug names.

## Workflow

1. **Profile** — one page: name, ID number, blood group, allergies, conditions, health-coverage scheme and main hospital, doctors, emergency contacts (template in [references/care-templates.md](references/care-templates.md))
2. **Medicines (summary)** — bring the actual bag of medicines (ถุงยาเดิม) to every appointment so the doctor can reconcile; copy each medicine into the table in [references/care-templates.md](references/care-templates.md) exactly as the label or ใบรายการยา says; never change, skip or double a dose — questions go to the doctor or pharmacist. For the full daily schedule, label-word guide and refill method use `medication-schedule`
3. **Appointments** — put every ใบนัด in the family calendar with who drives; note fasting instructions (งดน้ำงดอาหาร)
4. **Questions for the doctor** — collect during the month: new symptoms with date, falls, sleep, appetite, side effects noticed. Ask: what is each medicine for, what side effects to watch, what to do if a dose is missed, when to come back sooner
5. **Rights check** — the table below, once a year and when anything changes
6. **Home safety** — run the checklist once, then every 6 months
7. **Handoff note** — whenever someone else takes over for a day or more

## Rights and welfare

| Right | Who / amount | How |
|---|---|---|
| เบี้ยยังชีพผู้สูงอายุ (old-age allowance) | 60–69 ปี 600 · 70–79 ปี 700 · 80–89 ปี 800 · 90+ ปี 1,000 บาท/เดือน | Register at the อปท. (เทศบาล/อบต./สำนักงานเขต in Bangkok) where the person is in the ทะเบียนบ้าน; people turning 60 in the next fiscal year register in advance. Paid on the 10th of each month (earlier working day if a holiday). A 2568 report of new bands 700/850/1,000/1,250 is disputed; prd.go.th and Bangkok Biznews (9 Oct 2569) still show 600–1,000 — checked 2026-10-22, confirm with the อปท. (รอยืนยัน) |
| Eligibility condition | Under the ระเบียบกระทรวงมหาดไทย พ.ศ. 2566 the allowance is for people without other state pensions/welfare; the "ไม่มีรายได้เพียงพอ" criterion and later amendments (รอยืนยัน the current rule with the อปท.) | |
| บัตรทอง / หลักประกันสุขภาพแห่งชาติ (Universal Coverage Scheme, UCS) | Thai citizens without another scheme | สปสช. hotline 1330; check or change the registered hospital in the สปสช. app / LINE @nhso |
| สิทธิข้าราชการ (Civil Servant Medical Benefit Scheme, CSMBS) | Parents of a government officer are covered via the officer | กรมบัญชีกลาง; register the parents in the officer's family data |
| ประกันสังคม | Insured under มาตรา 33 / 39 continue their own cover; pension or lump sum at 55+ after leaving work | สำนักงานประกันสังคม hotline 1506 — see `e-commerce` `social-security-th` (if installed) |
| Children's tax deduction for parents | ลดหย่อนบิดามารดา 30,000 บาท/คน (parent 60+, income ≤ 30,000/yr); parents' health insurance premium up to 15,000 | `trading-finance` `tax-deduction-planner` (if installed) |
| Other | ศูนย์ช่วยเหลือสังคม 1300; disability card (บัตรคนพิการ) if eligible; travel discounts (รอยืนยัน current list) | |

ตรวจล่าสุด 2026-10-06 · แหล่ง: https://www.dop.go.th · https://www.prd.go.th/th/content/category/detail/id/31/iid/484396 · https://www.thairath.co.th/lifestyle/lifestyle45plus/2717071 · https://www.rd.go.th

## Home safety checklist (falls are the main risk)

- [ ] Bathroom: grab bars by toilet and shower, non-slip mat or floor coating, shower chair, no step at the door if possible
- [ ] Bedroom on the ground floor if stairs are hard; bed height so feet are flat on the floor when sitting
- [ ] Night lights from bed to toilet; light switch reachable from bed
- [ ] Remove loose rugs, cables across walkways, clutter on stairs; handrails on both sides of stairs
- [ ] Phone or call bell within reach; emergency numbers large on the wall: 1669 ambulance
- [ ] One named person in charge of medicines, checked against the table
- [ ] Water heater temperature not scalding; gas stove with auto shut-off or switch to induction
- [ ] Shoes with closed heels and non-slip soles; walking aid at the right height (ask the physiotherapist)

## Worked example

Mother, 78, Bangkok, บัตรทอง at a district hospital, blood pressure and diabetes, 5 medicines. Family set-up: medicine table copied from the hospital list; pill organiser filled Sunday by the eldest; appointments every 3 months — the second child drives and brings the medicine bag and the question list (dizzy when standing up, twice this month, dates noted). Rights: เบี้ยยังชีพ 700 บาท/เดือน (age 70–79) paid on the 10th; turns 80 next year → amount moves to 800 automatically by age band (confirm with the เขต office). Tax: the daughter who supports her claims ลดหย่อนบิดามารดา 30,000 (one child per parent).

## Related

`kids-school` (one family calendar) · `meal-plan-grocery` (soft, low-salt menus) · `home-maintenance` (grab bars, lighting as a job) · `personal-life` `important-docs` (ID, ทะเบียนบ้าน, hospital card, will) · `trading-finance` `tax-deduction-planner` · `personal-life` `medication-schedule` (full medicine schedule and refills) · `personal-life` `doctor-visit-prep` (symptom list, questions and visit record)
