# Elder care templates

## Contents

- Profile card
- Medication table
- Appointment and question log
- Caregiver handoff note

## Profile card

Private: holds the ID number and health data. Keep it in the user's own private file or locked note, not committed and not posted to a group chat.

| | |
|---|---|
| ชื่อ-นามสกุล | |
| เลขบัตรประชาชน | |
| วันเกิด / อายุ | |
| กรุ๊ปเลือด | |
| แพ้ยา / แพ้อาหาร | |
| โรคประจำตัว | |
| สิทธิการรักษา | บัตรทอง / ข้าราชการ / ประกันสังคม / ประกันเอกชน |
| โรงพยาบาลหลัก / HN | |
| แพทย์ประจำ | |
| ผู้ติดต่อฉุกเฉิน 1 / 2 | |

## Medication table (copy from the label — do not change)

| ชื่อยา | ความแรง | ใช้สำหรับ | เวลา (เช้า/กลางวัน/เย็น/ก่อนนอน) | ก่อน/หลังอาหาร | แพทย์ที่สั่ง | ยาหมดวันที่ | หมายเหตุจากแพทย์/เภสัชกร |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Any change in this table is made only after the doctor or pharmacist says so — write who said it and the date in the last column.

## Appointment and question log

| วันนัด | โรงพยาบาล / แผนก | งดน้ำงดอาหาร? | ใครพาไป | คำถามที่จะถาม | สิ่งที่แพทย์บอก | นัดครั้งต่อไป |
|---|---|---|---|---|---|---|
| | | | | | | |

Symptom diary (for the questions column): date · what happened · how long · what was done.

## Caregiver handoff note

```
ส่งต่อการดูแล: คุณ ______ · จาก ______ ถึง ______ · วันที่ ______

วันนี้: กินยาแล้ว (เวลา) ______ · มื้ออาหาร ______ · ขับถ่าย ______ · นอน ______
อาการที่ต้องจับตา: ______
ยาต่อไป: (ตามตารางยา) ______ เวลา ______
นัดหมายที่ใกล้ถึง: ______
ถ้าฉุกเฉิน: โทร 1669 · โรงพยาบาล ______ · แจ้ง ______ (เบอร์) ______
บัตรประชาชน/บัตรโรงพยาบาล/ถุงยาอยู่ที่: ______
ห้ามลืม: ______
```
