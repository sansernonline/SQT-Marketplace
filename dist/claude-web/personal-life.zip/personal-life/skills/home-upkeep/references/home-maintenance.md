<!-- merged from skill `home-maintenance` on 2026-11-27 · description was: Use when a Thai home needs a maintenance schedule -->
# Home Maintenance (Thai climate)

General information, not engineering advice. Electrical, gas, structural and roof work goes to a licensed or insured technician.

## The Thai year in three seasons

| Season | Months | What it does to a house | Do before it starts |
|---|---|---|---|
| Hot (ฤดูร้อน) | mid-Feb – mid-May | Aircon runs 10+ h/day, pumps work hardest, water pressure drops | Aircon service, pump check, tank clean |
| Rainy (ฤดูฝน) | mid-May – mid-Oct | Roof leaks, blocked gutters, flooding, termites swarm, damp and mould | Roof, gutters, drains, termite check, flood kit — **by April** |
| Cool (ฤดูหนาว) | mid-Oct – mid-Feb | Dry, cheapest time for contractors outside holidays | Painting, waterproofing, big repairs |

## Workflow

1. **Inventory** the house: number of aircons (BTU, room, install year), water tank (size, material), pump, water heater, roof type, appliances under warranty — use the inventory table in [references/maintenance-calendar.md](maintenance-calendar.md)
2. **Generate the 12-month calendar** from the reference, adjusted for the inventory (more aircons → stagger cleanings so the bill is spread)
3. **Put each job in the family calendar** 2 weeks ahead with the contractor's number
4. **After each job** record date, cost and who did it — next quote is compared against it
5. **Warranties** — keep receipt + warranty card photo in `family-legal`; diary the expiry date one month ahead so faults are claimed while covered

## Core intervals

| Job | Interval | Why | Typical cost |
|---|---|---|---|
| Aircon filter rinse (self) | every 2–4 weeks | Clogged filter = more power, less cooling | free |
| Aircon full clean (ล้างแอร์) | every 3–6 months; 3 if near a road, pets, or 8+ h/day use | Dirty coil can add 10–25% electricity (รอยืนยัน) | 500–1,000 บาท/unit wall type (รอยืนยัน) |
| Water tank clean (ล้างแท็งก์น้ำ) | every 1–2 years | Sediment, algae | (รอยืนยัน) |
| Pump check — pressure switch, check valve, noise, cycling | every 6 months | A pump that cycles on and off with taps closed = leak | |
| Termite inspection (ปลวก) | yearly; bait/soil treatment contract often 1–3 years | Swarms after first rains | contract (รอยืนยัน) |
| Roof, flashing, gutters (รางน้ำ), downpipes | every March–April | Leaves block gutters → overflow into ceiling | |
| Drains and grease trap (บ่อดักไขมัน) | every 3 months | Smell, flooding | |
| Septic tank (บ่อเกรอะ/ถังบำบัด) emptying | every 2–5 years by use; call the เขต/เทศบาล service | Overflow | (รอยืนยัน) local fee |
| RCD / ELCB test button (เครื่องตัดไฟรั่ว) | monthly press of the test button | Shock protection | free |
| Water heater earth and RCD check | yearly by electrician | Shock risk in the shower | |
| Smoke detector battery, fire extinguisher gauge | 6 months / yearly | | |
| Exterior repaint, waterproof coating | 5–7 years, in cool season | Walls crack and absorb rain | |

Costs vary by city and size — get 2 quotes; a figure marked (รอยืนยัน) is a planning guess, not a price.

ตรวจล่าสุด 2026-10-26 · Season months are long-run averages (the hot season has started late Feb to early Mar in recent years); check the TMD seasonal outlook at https://www.tmd.go.th/forecast/seasonal each year. Prices and the aircon electricity figure have no official source and stay (รอยืนยัน). Details: [`sources.md`](sources.md).

## Contractor quote checklist

Before paying anything, every quote must show:

- [ ] Contractor's full name, ID card or company registration number, address, phone, LINE
- [ ] Scope in items: what is included and **what is not** (scaffolding, debris removal, materials grade, paint brand and code)
- [ ] Quantities and unit prices, not one lump sum
- [ ] Start date, duration, what happens if it rains
- [ ] Payment schedule tied to finished stages — deposit ≤ 30% (common practice), final payment after inspection
- [ ] Warranty on workmanship (e.g. 6–12 months on leaks) in writing
- [ ] Who pays if they damage something; insurance for high work
- [ ] 2–3 quotes for anything over ~10,000 บาท; compare in one table (scope · price · warranty · timeline · reviews)

For a formal quotation format see `e-commerce` `thai-business-docs` (if installed); for a written agreement on a big job see `e-commerce` `thai-business-docs` (if installed).

## Compare quotes by numbers (`decision-desk/decision-scoring`, command `score`)

1. **Iron rules (กฎเหล็ก), drop the quote before scoring:** no written quotation (a verbal price only) · deposit above 30% (common practice, not law) · contractor identity or phone missing. Put them in `must` as `equals` or `max`, for example `{"criterion":"written quote 1=yes","equals":1}` and `{"criterion":"deposit %","max":30}`.
2. **Criteria (default weights, starting value, not yet measured, the user changes them):** total price in baht, same scope for every quote (low, 0.40) · workmanship warranty in months (high, 0.25) · reviews or references 1–5, user's score (high, 0.20) · days to finish (low, 0.15).
3. **Run:** `node decide.mjs score quotes.json`. Compare only quotes with the same scope; if scope differs, fix the scope first, because the cheapest quote is often the one that leaves things out.
4. **Unstable or close** (`ยังไม่นิ่ง`, `สูสี`) → ask the top two contractors for the missing item (warranty in writing, a firm date), then rerun. The user picks; the score is supporting data.

## Related

`household-money` (spike traced to aircon) · `vehicle-care.md` · `family-legal` · `trading-finance` `budget-and-debt` (if installed) (sinking fund: set aside 1% of house value a year for repairs — a common rule of thumb)

## References

- [`worked-example.md`](worked-example.md) — open when you want a filled-in aircon schedule and quote comparison
- [`sources.md`](sources.md) — open when you must re-check season dates

## เรียกเป็นคำสั่ง

`/personal-life:home-upkeep <"schedule" | job to quote> [house type, aircon count]`

Run `home-upkeep` with the `home-manager` agent for: **the user's request**

If vehicles are mentioned, add their tax, พระราชบัญญัติคุ้มครองผู้ประสบภัยจากรถ (พ.ร.บ.), สถานตรวจสภาพรถเอกชน (ตรอ.) and service dates from `vehicle-care.md`. Output a month-by-month table plus the jobs due in the next 90 days; quotes are compared with the contractor quote checklist.
