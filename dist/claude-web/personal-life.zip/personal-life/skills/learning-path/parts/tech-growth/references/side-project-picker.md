<!-- merged from skill `side-project-picker` on 2026-11-27 · description was: Use when choosing a portfolio side project -->
# Side Project Picker

Pick the project you will finish. A shipped small project teaches more than an abandoned big one.

## Workflow

1. **Learning goal**: which 1–2 skills should this project exercise? Take them from the active `learning-path` plan if one exists
2. **Constraints**: the hours available (default: 2 weekends ≈ 16 hours), the stack the user already knows, and any budget for hosting (default ฿0)
3. **Candidates**: collect 3–5 ideas. Use the user's own annoyances first (a real problem has a real user), then the idea bank in [references/idea-bank.md](idea-bank.md)
4. **Name the assumptions** of the top 2–3 ideas in two kinds: facts about the world (the API is free, the data is public, someone will use it) and the user's ability (can deploy, can learn the new library in a weekend). An idea resting on two or more unchecked ones scores F no higher than 2. Lock one thing (the stack or the data) and let the rest move. Same test as `thesis-writing`, "Topic test"
5. **Score** each one with the matrix below. Pick the highest. On a tie, pick the one the user would actually use
6. **Cut scope** with the rules below until the plan fits the hours
7. **Write the done definition** before writing any code, in the project's `README.md`
8. **Two-weekend plan**: weekend 1 is a walking skeleton (the thinnest version that works end to end), deployed and still ugly. Weekend 2 is the core feature, the done list, and a write-up
9. **Ship and log**: a public repo or demo link, a 5-line write-up of what was learned, and a line in `learning-log.md`

## Scoring matrix (1–5 each)

| Criterion | Weight | 1 | 5 |
|---|---:|---|---|
| **Learning value**: exercises the target skill directly | ×3 | The skill is a side detail | The skill is the core of the project |
| **Finishable in 2 weekends** | ×3 | Needs months, or something unknown blocks it | The skeleton is obvious, with 1 new thing at most |
| **Usefulness**: someone (even only the user) will use it | ×2 | A demo nobody opens again | Used weekly |
| **Portfolio value**: tells a reader something | ×1 | A tutorial clone | A real problem with a short write-up and a live demo |

**Score by script, not by hand** (`decision-desk/decision-scoring`, command `score`): `node decide.mjs score ideas.json` (a copy of [references/score-example.json](score-example.json) with the user's ideas). Weights 3:3:2:1 divided by 9 are a default, not yet measured; the user may change them. Iron rule (กฎเหล็ก): an idea with F below 2 is dropped, not scored. The script also moves each weight ±20% and says whether rank 1 is stable (`นิ่ง`) or not (`ยังไม่นิ่ง`, `สูสี`); if not stable, the user decides between the top two. A second iron rule (กฎเหล็ก) stays from the old hand formula: the script's 0–100 is relative among the candidates only, so also add 3L+3F+2U+1P from the raw 1–5 scores (max 45) for the winner. Below 25 = no idea is good enough, pick other ideas, even if it ranks 1 (both ideas that pass above score 39 and 35). The same formula gave the same winner as the script on the example below.

Worked example (Go REST API, 16 hours, scored table): [references/worked-example.md](side-project-picker/worked-example.md)

## Scope-cutting rules

1. **One user, one main flow.** Remove sign-up, roles and settings. Use a single hard-coded user or a secret link
2. **Storage**: a file or SQLite before a database server
3. **No admin screens.** Edit the data directly
4. **Only one new thing.** If the project needs a new language *and* a new framework *and* a new cloud, pick 1 and use familiar tools for the rest
5. **Fake what is not the lesson**: mock a payment, hard-code a list, skip email
6. **Cut by time**: anything not working by the end of weekend 1 that is not the core moves to a `later.md` list
7. **Polish last.** Styling happens only after the done list is ticked

## Done definition (template, in `README.md`)

```markdown
## Done when
- [ ] The core flow works end to end: <one sentence>
- [ ] Deployed or runnable with one command: <link or command>
- [ ] 3 or more automated tests on the core logic
- [ ] README: what it does, how to run it, one screenshot
- [ ] Write-up (5 lines): what I learned, what I would do differently
## Not doing (this version)
- <cut 1>
- <cut 2>
```

## Rules

- A project is finished when the done list is ticked, not when it is perfect
- Keep a list of ideas for later. Never expand scope mid-build
- A project that misses its 2 weekends gets 1 more weekend with stricter cuts. Then ship it as it is, or drop it with a note
- Prefer projects that run on free tiers. Add a budget alert to any cloud account

Related: `learning-path` (where the goal comes from, and a project after the exam), `tech-radar.md` (new tools worth trying), and `project-bootstrap` and `code-craft` in `software-development`.
