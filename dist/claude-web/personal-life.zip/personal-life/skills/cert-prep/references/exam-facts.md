# Exam facts for common certifications

Always re-check on the vendor page before booking. Exam versions, prices and pass marks change, and prices differ by country.

| Exam | Format | Questions | Time | Pass mark | Price (USD) | Valid for |
|---|---|---:|---:|---|---:|---|
| AWS Solutions Architect – Associate (SAA-C03 — aws.amazon.com shows no SAA-C04 on 2026-10-22; third-party sites claiming one are not confirmed) | Multiple choice / multiple response | 65 (50 scored + 15 unscored) | 130 min | 720 / 1000 (scaled, compensatory) | 150 | 3 years (รอยืนยัน) |
| Microsoft Azure Administrator (AZ-104) | Mixed, may include case studies | 40–60 | 100 min | 700 / 1000 | 165 (price varies by country, รอยืนยัน for Thailand) | 1 year, renewed by a free online assessment on Microsoft Learn (opens 6 months before expiry) |
| Certified Kubernetes Administrator (CKA) | Performance-based, live terminal, kubernetes.io/docs allowed | 15–25 tasks (รอยืนยัน) | 2 hours | 66% | 445 (includes 1 retake and 2 killer.sh simulator sessions) | 2 years |
| Certified Kubernetes Application Developer (CKAD) | Performance-based | (รอยืนยัน — not published) | 2 hours | 66% | 445 | 2 years |
| Google Cloud Associate Cloud Engineer | Multiple choice / multiple select | 50–60 | 2 hours | Not published | 125 | 3 years (source: cloud.google.com/learn/certification/cloud-engineer, ตรวจ 22 ต.ค. 2569) |
| Scrum.org Professional Scrum Master I (PSM I) | Multiple choice, multiple answer, true/false | 80 | 60 min | 85% | 200 | Does not expire. The attempt password does not expire either |

## Domain weights

**AWS SAA-C03**: Design Secure Architectures 30% · Design Resilient Architectures 26% · Design High-Performing Architectures 24% · Design Cost-Optimized Architectures 20%.

**CKA**: Troubleshooting 30% · Cluster Architecture, Installation & Configuration 25% · Services & Networking 20% · Workloads & Scheduling 15% · Storage 10%.

**AZ-104**: 5 domains — identities and governance, storage, compute, virtual networking, monitoring (weights: รอยืนยัน, take them from the current study guide).

ตรวจล่าสุด 2026-10-22 (SAA, CKA, CKAD) · แหล่ง: https://aws.amazon.com/certification/certified-solutions-architect-associate/ · https://docs.linuxfoundation.org/tc-docs/certification/faq-cka-ckad-cks · ตรวจ 2026-10-06 · https://docs.aws.amazon.com/aws-certification/latest/examguides/solutions-architect-associate-03.html · https://training.linuxfoundation.org/certification/certified-kubernetes-administrator-cka/ · https://www.scrum.org/assessments/professional-scrum-master-i-certification (figures confirmed via scrum.org forum pages) · AZ-104 figures from secondary sources (https://trainingcamp.com/what-is-azure-administrator/), so confirm them on learn.microsoft.com
