---
name: meeting
description: Prepare or summarize a meeting — a one-page prep card before; decisions, action items and open questions after.
argument-hint: <prep|summary> [meeting name or notes]
disable-model-invocation: true
---

Use `meeting-prep-card` or `meeting-summary` with the `meeting-prep` agent: **$ARGUMENTS**

- `prep` — build the one-page card before the meeting
- `summary` — capture decisions and action items right after
