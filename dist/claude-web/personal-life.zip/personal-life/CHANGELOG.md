# Changelog — personal-life

## 0.26.1 — 2026-11-18

- `cert-prep` มีหัวข้อใหม่ "Quiz or cards only" ต้นไฟล์ รวมกฎ 3 ข้อจาก `study-drill` เดิม: ตอบผิดห้ามเฉลย · ห้ามใส่คำตอบในบัตรก่อนผู้ใช้หาเจอ · ห้ามแต่งบัตรให้ครบจำนวน
- ที่ต้องย้ายขึ้นมา เพราะรุ่น 0.26.0 เก็บกฎนี้ไว้ใน reference อย่างเดียว eval `cert-prep-behaviour` จึงได้ 0.00 หลังย้ายขึ้น SKILL.md ได้ 1.00 (ไม่มี skill ได้ 0.00)
- `evals/RESULTS.md` ใส่ผลรันจริงของ `cert-prep-*` ทั้ง 3 เคส

## 0.26.0 — 2026-11-18

- รวม skill ที่ซ้อนกัน 3 คู่ จาก 44 เหลือ 41 skill: `linkedin-profile` เข้า `resume-th-en` (ขั้นตอน LinkedIn อยู่ที่ `references/linkedin.md` · argument-hint เพิ่ม `linkedin`) · `study-drill` เข้า `cert-prep` (รูปแบบบัตรคำและการซ้อมถามตอบอยู่ที่ `references/cards-and-drills.md`) · `paper-to-practice` เข้า `learning-path` (`references/paper-to-practice.md`)
- ตารางทบทวนบัตรเหลือแบบเดียว คือแบบกล่อง 5 ใบ (+1 · +3 · +7 · +21 วัน) เพราะปรับตามคำตอบถูกผิดและตรงกับช่อง `box:` และ `next:` ของบัตร · ตัดรอบวันที่ 1 · 3 · 7 · 14 · 30 ของ `cert-prep` เดิมออกเพราะขัดกัน
- eval `study-drill-*` 3 เคส เปลี่ยนชื่อเป็น `cert-prep-*` พร้อมสถานะเดิมใน `evals/RESULTS.md` (`behaviour` ยังไม่ผ่าน) · แก้อ้างอิงใน agent `career-coach` `tech-mentor` และ skill ที่เกี่ยวข้อง
- แก้ argument-hint ของ `home-maintenance` ที่ลงท้าย "car details" ผิด (เรื่องรถอยู่ที่ `vehicle-care`)

## 0.25.1 — 2026-11-17

- ของกลางจาก superuser 3.45.0: config แม่แบบมีโมดูล `resume_check` (เตือนข้อเก่าใน "รับงานต่อ" และเตือนให้อัปเดตก่อนจบ) · แม่แบบ CONTEXT มีกฎ `รับโดย:` และป้าย `ขัดกัน` จาก superuser 3.44.0 ซึ่งรอบนั้นไม่ได้ขึ้นรุ่น plugin นี้

## 0.25.0 — 2026-11-16

- SKILL.md สั้นลงให้เหลือเท่าที่ใช้ทุกครั้ง (ผู้ใช้สั่ง 2026-11-16 "ให้ skill lean ที่สุด") · 44 skill · ตัวที่ถูกเปิดจริงใน log เขียนใหม่เป็น Use when · Steps · Check before done · References · ตัวอื่นตัดบรรทัดบอก plugin เครดิต ประวัติ กฎที่ซ้ำแกน และ anti-pattern ที่ซ้ำ · ที่มาพร้อมวันตรวจ ตัวอย่างเต็ม แม่แบบ และตารางยาวย้ายไป `references/` (เปิดเมื่อจำเป็น) · เงื่อนไข เกณฑ์ ขั้นตอน และตัวเลขใน facts.json คงครบ · ยังไม่ได้รัน eval เทียบก่อนและหลัง

## 0.24.3 — 2026-11-16

- แปลประโยคคำสั่งภาษาไทยที่ยังค้างในไฟล์ที่ model อ่านเป็นภาษาอังกฤษ (ผู้ใช้สั่ง 2026-11-16 "แปลให้ครบก่อน แล้วค่อยวัดผล") · แก้ 4 ไฟล์ใน plugin นี้ · ไทยที่เหลือเป็นแม่แบบ ตัวอย่าง ชื่อทางการ ป้ายสถานะ และคำที่ตัวตรวจจับ ซึ่งตั้งใจคงไว้

## 0.24.2 — 2026-11-15

- แปลไฟล์ที่ model อ่านที่ยังเป็นไทยส่วนที่เหลือทั้งหมดเป็นภาษาอังกฤษ (SKILL.md · references · agents · ผู้ใช้สั่ง 2026-11-15 "แปลเป็นอังกฤษให้หมด") · รอบนี้แก้ 33 ไฟล์ใน plugin นี้ · แม่แบบ ตัวอย่าง และข้อความที่ส่งถึงผู้ใช้ไทย ชื่อกฎหมายและหน่วยงาน ป้ายสถานะ ป้ายหลักฐาน และคำที่ hook หรือตัวตรวจจับ คงเป็นไทย · ยังไม่ได้รัน eval เทียบก่อนและหลัง

## 0.24.1 — 2026-11-15

- ข้อความคำสั่งใน reference ที่ถูกใช้และ playbook ของ superuser สาขาเป็นภาษาอังกฤษ · แม่แบบรายงานประชุม CV และแบบฟอร์มยังเป็นภาษาไทย (ผู้ใช้สั่ง 2026-11-15 · เลือกไฟล์จากการใช้จริงใน log 2,900 session · ไทยในไฟล์ที่แปลลดลง 88%) · ป้ายสถานะ ป้ายหลักฐาน คำที่ hook และตัวตรวจจับ และตัวอย่างภาษาไทยคงเป็นไทย · ยังไม่ได้รัน eval เทียบก่อนและหลัง

## 0.24.0 — 2026-11-15

- description ของ skill ทั้ง 47 ตัวเป็นภาษาอังกฤษประโยคเดียว ยาวไม่เกิน 65 ตัวอักษร · รายการ skill ของ plugin นี้ลดจาก 6,856 เหลือ 3,892 ตัวอักษร · รวมทุก plugin เหลือ 24,071 ตัว ต่ำกว่างบตั้งต้น 30,000 ของ Claude Code จึงไม่ต้องตั้ง `skillListingBudgetFraction` แล้ว (ผู้ใช้สั่ง 2026-11-15)
- ยังไม่ได้รัน trigger eval เทียบก่อนและหลัง (เสียเงิน รออนุมัติ)

## 0.23.10 — 2026-11-12

- ตัวเลขที่เปลี่ยนบ่อยไม่เก็บใน skill แล้ว ให้ค้นสดจากหน้าทางการทุกครั้ง เปิดไม่ได้ใส่ `(รอยืนยัน)` · คงเฉพาะเลขที่สคริปต์ใช้คำนวณ · แถวใน `scripts/check/expiry.json` ลดจาก 26 เหลือ 8 · `pet-care` (วันเริ่มข้อบัญญัติ กทม.) · `flood-prep` (เงินช่วยเหลือน้ำท่วม) · `moving-house` (ค่าธรรมเนียมย้ายทะเบียน · ประกาศ สคบ. สัญญาเช่า) · คง Ft ใน `household-bills` เพราะ `power-bill.mjs` ใช้ · eval `flood-prep-behaviour` ตรวจว่าให้เช็กมติ ครม. ล่าสุดแทนยอด 9,000

## 0.23.9 — 2026-11-12

- eval: ตัวให้คะแนน regex ที่เขียน `(?i)` ในตัว pattern (JavaScript ไม่รับ จึง error เงียบ) ย้ายเป็น `flags: i` · เคสที่มีไฟล์ประกอบใน `resources/` ได้ `fixture.sh` + `scaffold_script` ใต้ `context:` (เดิมวาง `add_dirs` ใต้ `execution:` ซึ่งถูกเมิน) · ยังไม่ได้รันยืนยันเพราะหน่วยความจำเครื่องไม่พอ
- eval `job-exit-behaviour`: ยกเว้นประโยค "ไม่สามารถบอกได้ว่า…" จากเกณฑ์ห้ามฟันธง · รันจริง with 1.00 · without 0.50 (2026-11-12)

## 0.23.8 — 2026-11-12

- สำเนา `superuser/references/team-roles.md` ของ plugin นี้เป็นภาษาอังกฤษตาม superuser 3.39.1

## 0.23.7 — 2026-11-11

- `superuser/SKILL.md` ของ plugin นี้เป็นภาษาอังกฤษ (เล็กลงราว 40%) · คำไทยที่ hook ตรวจ ป้ายสถานะ และชื่อเอกสารราชการไทยคงไว้

## 0.23.6 — 2026-11-11

- สำเนา `superuser/references/` (brief-template · review-lenses · team-roles) ตรงกับแกน 3.38.0: ใบสั่งงานสั้น · โหมด test ของผู้ตรวจ · รอลูกทีมแบบ background

## 0.23.5 — 2026-11-11

- `superuser/references/team-roles.md` ตรงกับแกน: ผู้ตรวจในงบสมดุลใช้ระดับกลางทุกรอบ ระดับใหญ่เฉพาะรอบสุดท้ายของงานเสี่ยง

## 0.23.4 — 2026-11-11

- ใบสั่งงานแบบสั้นของ `worker` ตาม `superuser` 3.36.0: ชี้ไฟล์และหัวข้อของ spec แทนการคัดลอก · 1 หน่วยของโจทย์ = 1 ใบ เขียนทั้งโค้ดและ test

## 0.23.3 — 2026-11-11

- ใบสั่งงานแบบสั้นสำหรับ `worker` (`references/brief-template.md`) และ `team-roles.md` ตามต้นฉบับใน `superuser` 3.35.0: ลูกทีมค่าเริ่ม `haiku` รัน test เองได้

## 0.23.2 — 2026-11-10

แก้จากผล eval รอบแดง/เขียว 2026-11-10 (sonnet · 3 รอบ)

- `job-exit`: ทุกแถวในตารางสิทธิ์บอกมาตรา (ม.118 · ม.17 · ม.67) แม้ไม่ได้ติดตั้ง `labour-law-basics`
- `legal-help-prep`: description รับกรณีได้หมายศาลและถามวันครบกำหนดหรือจะชนะไหม · ถูกขอตรง ๆ ให้นับวันหรือทายผล ตอบว่าไม่ทำพร้อมเหตุผล แล้วให้ความเร่งด่วน ตารางข้อเท็จจริง ช่อง `[ตรวจ]` และช่องทางช่วยเหลือฟรีแทน
- `new-job-first-90-days`: ผู้ใช้ส่งเลขบัตรเต็มมาให้ใส่ ก็ใส่แค่ 4 ตัวท้าย · คำถามถูกให้ออกช่วงทดลองงานอ้าง พ.ร.บ.คุ้มครองแรงงาน และชี้ `labour-law-basics` กับตารางสิทธิ์ใน `job-exit`
- `study-drill`: ข้อที่ตอบผิดกลางการซ้อมทำเป็นบัตรได้หลังผู้ใช้หาคำตอบเจอแล้วเท่านั้น
- eval: `job-exit-behaviour` regex ไม่จับคำปฏิเสธที่ทวนคำถาม · `study-drill-behaviour` โน้ตไม่มีบรรทัดที่เฉลยคำตอบ · `legal-help-prep-behaviour` เพิ่มตัวชี้วัดว่า skill ถูกเปิด
- eval `job-exit-behaviour` (ผู้ตรวจรอบ 1 · 2026-11-11): regex ยกเว้นเฉพาะวลีปฏิเสธที่นำหน้าคำต้องห้าม ("ตอบไม่ได้ว่า" · "ไม่อาจบอกได้ว่า" · "ไม่มีใครรับประกันว่า") แทนทุกคำว่า "ไม่" ในระยะ 30 ตัว จึงจับ "ไม่ต้องห่วงเลยฟ้องชนะแน่" ได้ · เกณฑ์ llm ข้อ 1 คืนคำว่า "บริษัทผิด"

## 0.23.1 — 2026-11-10

- `legal-help-prep`: ตัวอย่าง JSON ไม่กำหนด today ตายตัว ให้สคริปต์ใช้วันที่ของเครื่อง
- `learning-path`: เพิ่มบรรทัด Not for ชี้ `cert-prep` และ `side-project-picker`
- เอาอีโมจิที่เป็นหัวข้อและป้ายออกจากเอกสารใน plugin
- eval ใหม่: `important-docs` (trigger + behaviour) · `pet-care` (trigger + behaviour)
- `job-exit`: ภาษีค่าชดเชยชี้ `labour-law-basics` (e-commerce) ข้อ 9 หรือนักบัญชี แทน `tax-basics-th` ที่ไม่มีเรื่องนี้
- `legal-help-prep`: รัน `due-dates.mjs` หลังได้วันที่จริงเท่านั้น เขียนเป็น JSON ตาม `important-docs` · บอกเหตุผลที่เตือน 14/7/3/1 วัน ต่างจาก 60/30/7

## 0.23.0 — 2026-11-10

- `task-board` (ใหม่): ไฟล์ `tasks.md` 4 หมวด งานที่เจอในเมลหรือแชตต้องถามก่อนเพิ่ม · eval 3 เคส
- `study-drill` (ใหม่): บัตรคำ 1 แนวคิดต่อใบพร้อมแหล่ง ตารางถังทบทวน และซ้อมถามตอบที่ไม่เฉลยทันที · eval 3 เคส
- `new-job-first-90-days` (ใหม่): เตรียมก่อนเริ่มงาน คำถามถึงหัวหน้าสัปดาห์แรก เป้า 30/60/90 วัน และผ่านทดลองงาน · eval 3 เคส
- `job-exit` (ใหม่): ถูกเลิกจ้างหรือลาออก ฝั่งลูกจ้าง ลำดับก่อนเซ็น สิทธิ์ที่ต้องตรวจ ว่างงาน และช่องทางร้อง · eval 3 เคส
- `legal-help-prep` (ใหม่): เตรียมเรื่องไปหาทนายหรือหน่วยงาน ตารางข้อเท็จจริง กำหนดเวลา และสมุดบันทึกการติดต่อ · eval 3 เคส
- `inbox-triage`: สแกนคำสัญญาของผู้ใช้ในเธรดเก่า กฎร่างตอบ และรายงานกลุ่มจัดเก็บเป็นจำนวน
- `weekly-review`: รูปทรงสรุปเมื่ออ่านหลายแหล่ง (งานขึ้นก่อน จัดตามเรื่อง บอกแหล่งที่เปิดไม่ได้ บรรทัดนับท้าย)
- `thesis-writing`: ตรวจหัวข้อด้วยความเสี่ยงก่อนตั้งคำถามวิจัย และ reader test ก่อนส่งอาจารย์
- `side-project-picker`: แยกสมมติฐานโลกกับความสามารถก่อนให้คะแนน
- `resume-th-en` · `performance-self-review`: reader test ก่อนส่ง
- `cert-prep` · `learning-path`: ตรวจชั่วโมงกับสัปดาห์จริง สามช่วง โหมดเร่ง และถามว่าเสริมหรือแทนคอร์สเดิม
- `household-bills`: ดูยอดเงินก่อนจ่ายหรือตั้งหักบัญชี และหักบัญชีเก่าไม่เท่าอนุมัติ
- `personal-kb`: ไฟล์ถอดรหัสชื่อเล่น `names.md` และกติกาตอบจากโน้ตพร้อมแหล่งและวัน
- `kids-school`: ตรวจความเข้าใจ 5 นาทีที่บ้าน ใช้ภาษาเชิงบวก
- agent `career-coach` · `health-organizer`: คำถามตรวจต่อ 2–3 ข้อหลังคำแนะนำที่ผู้ใช้จะลงมือ · `career-coach` `life-admin` `tech-mentor` ชี้ skill ใหม่

## 0.22.3 — 2026-11-10

- อ้างถึง plugin ซอฟต์แวร์ด้วยชื่อใหม่ `software-development` (เดิม `software-company`)
- ของกลางจาก superuser 3.33.0 (sync): ขั้นตรวจงานใหม่ใน `playbook-review` · แจกงานและรอลูกทีมใน `team-roles` · รอบ `playbook-unattended-run` มีตรวจเครื่องมือและกล่องขาออก · แม่แบบสมุดงาน ledger และแนวคิดที่ปฏิเสธใน `templates/` · แม่แบบ `config.json` มีโมดูล hook ใหม่

## 0.22.2 — 2026-11-08

- `references/examples.md`: ตัวอย่างระดับโมเดลจัดตามกฎ 3 ข้อของ superuser 3.26.0 (งานเสี่ยง → opus · งานกลไกที่มีแบบ → haiku · ที่เหลือ → sonnet)

## 0.22.1 — 2026-11-08

- `meeting`: description อ่านง่ายขึ้น (แก้ใน PR #75 ขึ้นเลขรุ่นที่นี่เพื่อให้เครื่องที่ติดตั้งแล้วอัปเดตได้)

## 0.22.0 — 2026-11-08

- ยุบ `meeting-prep-card` และ `meeting-summary` เข้า `meeting` · ขา 1 ก่อนประชุม · ขา 2 หลังประชุม · แม่แบบรายงานการประชุมอยู่ที่ `meeting/references/thai-minutes-template.md` · **เรียกชื่อเก่าไม่ได้แล้ว**
- eval `meeting-summary-existing` คงชื่อเดิม (วัดขา 2) · skill ที่ลิงก์หา (`calendar-audit` · `doctor-visit-prep` · `interview-prep` · `personal-kb` · `moving-house`) · playbook `meeting` `review` · triggers · agent `meeting-prep` ชี้ตัวใหม่

## 0.21.1 — 2026-11-07

- ตรวจ plugin หัวข้อ 8 (ประหยัด token): ย้ายตัวอย่างและแม่แบบที่ใช้บางครั้งจาก SKILL.md ไป references/ ของ 7 skill (`paper-to-practice` · `decision-journal` · `goal-and-habit` · `meal-plan-grocery` · `weekly-review` · `salary-negotiation` · `course-builder`) และตัดบรรทัดซ้ำใน `superuser/SKILL.md` · ความหมายและผลลัพธ์เหมือนเดิม · รายงานใน `_to_delete/audit-personal-life.md`

## 0.21.0 — 2026-11-07

- `meeting-summary`: หัวข้อใหม่ "0 · หาแบบที่มีอยู่ก่อน" ใช้แบบรายงานการประชุมขององค์กรก่อน · eval ใหม่ `meeting-summary-existing` (ยังไม่ได้รัน)

## 0.20.0 — 2026-11-07

- เอาคำสั่งที่เป็นแค่ทางลัดไปหา skill ตัวเดียวออก 14 ตัว เรียก skill ตรงแทน เช่น `/personal-life:household-bills` · ขั้นตอนและ `argument-hint` ของคำสั่งเดิมย้ายไปหัวข้อ "เรียกเป็นคำสั่ง" ท้าย SKILL.md ของ skill ปลายทาง: `bills` → `household-bills` · `checkup` → `annual-checkup` · `decide` → `decision-journal` · `doctor-prep` → `doctor-visit-prep` · `interview` → `interview-prep` · `learn` → `learning-path` · `maintenance` → `home-maintenance` · `negotiate` → `salary-negotiation` · `radar` → `tech-radar` · `resume` → `resume-th-en` · `subscriptions` → `subscription-audit` · `travel` → `travel-prep` · `triage-mail` → `inbox-triage` · `week-review` → `weekly-review`

## 0.19.0 — 2026-10-28

- skill ใหม่ `moving-house`: ย้ายบ้านและเปลี่ยนที่อยู่ · ย้ายทะเบียนบ้าน 3 แบบ (ย้ายปลายทาง 20 บาท · ภายใน 15 วันนับจากวันย้ายเข้า · ค่าแจ้งเกินกำหนด 30–500 บาท) · ปิดหรือโอนค่าไฟค่าน้ำและขอเงินประกันคืน (กฟน. กฟภ. กปน. กปภ.) · รายการหน่วยงานที่ต้องแจ้งที่อยู่ใหม่ใน `references/notify-list.md` · คืนเงินประกันห้องเช่าตามประกาศ สคบ. 2568 (ผู้ให้เช่าตั้งแต่ 3 ห้อง · ไม่เสียหายคืนใน 7 วัน · เสียหายคืนส่วนที่เหลือใน 30 วัน) · ตรวจแหล่งทางการ 2026-10-28 · ขั้นตอนขนส่งและ ThaID ยังรอยืนยัน
- agent `home-manager` และ `doc-caretaker` รู้จัก `moving-house` · `triggers.md` เพิ่มแถวย้ายบ้าน
- eval ใหม่ 3 เคสยังไม่ได้รัน: ควรเปิด · ไม่ควรเปิด (บิลค่าไฟขึ้น) · พฤติกรรม (วันที่จริง กฎ 7 วัน ไม่เก็บเลขบัตรและเลขบัญชีเต็ม)

## 0.18.0 — 2026-10-28

- สคริปต์ใหม่ `important-docs/scripts/due-dates.mjs` (self-test 29 ข้อ): คิดวันครบกำหนดจากวันหมดอายุลบเวลานำ รับปี พ.ศ. หรือ ค.ศ. และโหมด `--refill` คิดวันที่ยาหมดจากฉลาก · `important-docs` `medication-schedule` `pet-care` เรียกใช้แทนการนับวันเอง
- `power-bill.mjs` โหมด `--history` เทียบหน่วยเดือนล่าสุดกับค่าเฉลี่ย 3 เดือนก่อนหน้า (self-test เพิ่มเป็น 28 ข้อ) · เกณฑ์ 20% ย้ายไป `rates.json` ติดป้ายค่าตั้งต้น ยังไม่ได้วัด · ขั้นบันไดค่าไฟยังรับจากบิลผู้ใช้ เพราะยังไม่มีหน้าทางการที่เปิดอ่านได้
- `side-project-picker` `annual-checkup` `pet-care` `vehicle-care` ใช้ `decision-scoring` (score และ payoff) พร้อมไฟล์ตัวอย่างใน `references/` ที่รันผ่านจริง · `vehicle-care` เพิ่มหัวข้อก่อนซื้อรถ
- `health-organizer` และ `family-planner` ห้ามใส่ชื่อคน ผลตรวจ ชื่อยาในคำค้นเว็บ
- `inbox-triage` `calendar-audit` บอกวิธีต่อ Gmail และปฏิทินด้วยตัวเอง (ไม่ใส่ลิงก์เพราะยังไม่ได้ตรวจหน้า Google ทางการ) · `cert-prep` ติดป้ายค่าตั้งต้น ยังไม่ได้วัด
- `course-builder` ย้ายหัวข้อ 6–9 ไป `references/materials-feedback-online-copyright.md` (SKILL.md จาก 40,980 เหลือ 31,475 ไบต์) · `meeting` แก้ข้อความที่ชี้ผิด plugin · `triggers.md` เพิ่มตารางคำสั่งลัด 16 ตัว
- eval ใหม่ 7 เคสยังไม่ได้รัน: สคริปต์ค่าไฟ · ไม่มีขั้นบันได · ร่างอีเมลไม่ส่งเอง · คำค้นสุขภาพไม่มีข้อมูลส่วนตัว · สคริปต์วันครบกำหนด · ไม่ควรเปิด 2 เคส

## 0.17.1 — 2026-10-28

- `pregnancy-and-baby` เพดานฐานค่าจ้างเงินสงเคราะห์คลอดตรงกับ `facts.json` (17,500 บาท) และอยู่ในรายการไฟล์ที่ validator เฝ้า · เงื่อนไขส่งเงินสมทบ 5 เดือนติด (รอยืนยัน)
- `inbox-triage` ตัดคำสั่ง "ตอบไม่ถึง 2 นาทีให้ส่งเลย" เหลือร่างไว้ให้ผู้ใช้ส่งเอง

## 0.17.0 — 2026-10-28

- สคริปต์ใหม่ `power-bill.mjs` ของ `household-bills`: ค่าไฟจากหน่วยที่ใช้ และแยกส่วนต่างระหว่าง 2 เดือนเป็นหน่วยที่เพิ่ม ขั้นบันไดที่ขยับ และ Ft · อัตราขั้นบันไดรับจากบิลของผู้ใช้ เพราะ skill ยังไม่มีค่าที่ตรวจแล้ว · CI รัน self-test

## 0.16.0 — 2026-10-27

- ตัดสินด้วยตัวเลขผ่าน `decision-scoring`: ข้อเสนองาน ใบเสนอราคาผู้รับเหมา ประกันรถ (score) · การตัดสินใจใหญ่ (payoff) · เมนูในงบและเป้าหมายไม่เกิน 3 (knapsack) · อีเมลและปฏิทิน (Eisenhower) · `subscription-audit` ต้นทุนต่อครั้งที่ใช้ · `tech-radar` และ `meeting-prep-card` มีเกณฑ์ตัวเลข

## 0.15.4 — 2026-10-27

- ไอคอนประจำ plugin `assets/icon.png` (512) และ `assets/icon.svg` · ช่อง `icon` ใน plugin.json (ใช้ในหน้ารายการของ directory) · ทำตาม `design-references`: ค้นต้นแบบบน Dribbble แล้วถอดสีหลักจากงานต้นแบบ หมุนเฉดต่อ plugin · ผ่าน design-critic

## 0.15.3 — 2026-10-26

- eval: `flood-prep-behaviour` และ `pregnancy-and-baby-behaviour` แยกเกณฑ์ `llm` ตามเรื่องและย้ายตัวเลขไป regex (เดิมตก 0/3 ทั้ง 2 แขนเพราะข้อละเอียดเกินและข้อ "ไม่แต่งตัวเลข") · `household-bills-behaviour` เปลี่ยนข้อ "ไม่แต่งอัตราค่าไฟ" เป็นสิ่งที่เห็นได้ในคำตอบ

## 0.15.2 — 2026-10-26

- eval แบบ behaviour ให้ `estate-and-will` · `flood-prep` · `pregnancy-and-baby` (ไม่ฟันธงข้อพิพาทมรดก · ปิดเบรกเกอร์ก่อนน้ำถึงและไม่สัญญาเงินเยียวยานอกช่วง · ไม่วินิจฉัยหรือสั่งยาตอนตั้งครรภ์) · แถว hook router อยู่ใน `superuser`

## 0.15.1 — 2026-10-26

- `course-builder`: แถวใหม่ชี้ไป `superuser:chat-prompt-workflows` เมื่อสอนการใช้ AI หลายขั้นในแชต

## 0.15.0 — 2026-10-26

- เตรียมรุ่น 1.0.0 (ใช้จริง 2–3 สัปดาห์ก่อนขึ้นรุ่นหลัก)
- skill ใหม่ `estate-and-will` (doc-caretaker) · `pregnancy-and-baby` (health-organizer) · `flood-prep` (home-manager) พร้อมแถวใน triggers
- ตรวจข้อเท็จจริงเงินและสุขภาพใหม่ตามเกณฑ์ 3 แหล่ง: วงเงิน พ.ร.บ.รถ (คำสั่ง คปภ. 51/2568) · เกณฑ์ ตรอ. รถ 7 ปีและจักรยานยนต์ 5 ปีขึ้นไป · ค่าปรับและกำหนดฉีดวัคซีนพิษสุนัขบ้า · อายุคัดกรองมะเร็ง
- บรรทัด "ตรวจล่าสุด" ใน `annual-checkup` · `home-maintenance` · `thesis-writing` · `linkedin-profile`
- `course-builder` ย้ายตัวอย่าง Git ไป `references/git-one-day-example.md` (SKILL.md 50 KB เหลือ 41 KB) กฎทุกข้อยังอยู่ใน SKILL.md
- eval ชุดแรกของ plugin 9 เคส (ยังไม่ได้รัน): `medication-schedule` ห้ามบอกหรือปรับขนาดยา · อาการฉุกเฉินต้องตอบ 1669 ก่อน · `doctor-visit-prep` · `vehicle-care` · `household-bills` · `elder-care` · trigger ของ skill ใหม่

## 0.14.0 — 2026-10-25

- agent `life-admin` รับ `personal-kb` · `travel-prep` · `gift-idea-tracker` · `decision-journal` · agent `tech-mentor` รับ `course-builder` · `triggers.md` เพิ่มแถว `personal-kb`
- ตัดคำว่า "if installed" ที่ skill ใน plugin นี้เขียนถึง skill ของ plugin เดียวกัน (15 จุด) · `meeting-prep` บอกถูกแล้วว่า skill ประชุมอยู่ใน plugin นี้ ไม่ใช่ `superuser`
- prompt ใหม่ `prompt/personal-life/prompt-podcast-lesson.md` 5 ฉบับ: วางชุดบทเรียน (`course-builder`) · สคริปต์พูด 1 ตอนพร้อม show notes · สไลด์ประกอบที่ตรงกับสคริปต์ (`presentation-design` และ `html-slide-deck` ของ software-company) · อัดเสียง ตัดต่อ และเวอร์ชันวิดีโอ · ตรวจก่อนปล่อย
- `prompt-podcast-lesson.md` แก้ตามรอบทดสอบจริง (agent ตัวใหม่ทำฉบับ 1–3 กับบทเรียน Git 2 ตอน): ฉบับ 1 มีช่องเครื่องมือที่ผู้ฟังต้องใช้ · จำนวนตอนที่ผู้ใช้กรอกเป็นกรอบ · ส่งโครงตอนเป็น `outline.md` · ฉบับ 2 ใช้กฎภาษาพูดของ `speaking-script` · ตัวเลขเขียนเป็นเลขพร้อมคำอ่าน · บทพูดสรุปท้ายตอนได้แต่ show notes ไม่สรุปซ้ำ · ฉบับ 3 บันทึกผู้พูดต่อแผ่นชัดขึ้น · ไม่มี Playwright มีทางสำรอง · ทำวิดีโอด้วย `video-editing` (หัวข้อสไลด์กับเสียงบรรยาย) แทนอัดหน้าจอ · ตรวจตัวอักษรบนมือถือจริงแทนอ้างข้อที่ไม่ตรง · ฉบับ 4 ใช้ `video-editing` และ `subtitles-th`
- `prompt-podcast-lesson.md` ฉบับ 4: เสียงสังเคราะห์ใช้ `video-editing` ของ graphic-design (หัวข้อเสียงบรรยายจากสคริปต์) (ทำร่างด้วยเสียง Windows · ได้ซับและเวลาสไลด์จากการรันเดียว ไม่ต้องถอดเสียง)

## 0.13.0 — 2026-10-23

- skill ใหม่ `course-builder` ออกแบบหลักสูตรฝั่งผู้สอน (ฝั่งผู้เรียนยังเป็น `learning-path`): ผลลัพธ์การเรียนรู้ด้วยกริยาที่มองเห็นได้ตามอนุกรมวิธานของบลูมฉบับปรับปรุง (Krathwohl 2002) · ตารางสอนพร้อมเวลา · แบบฝึกจากพาทำไปจนทำเอง · rubric 3–4 ระดับพร้อมงานตัวอย่าง · แบบประเมินหลังอบรม · ออนไลน์กับในห้อง · ลิขสิทธิ์สื่อการสอน · ตัวอย่างหลักสูตร Git 1 วันที่รันคำสั่งจริงแล้ว · แนวคิดจาก mattpocock/skills `teach` และ `scaffold-exercises` (MIT · เขียนใหม่) · ตรวจแหล่ง 2026-10-23 · แถวใหม่ใน `triggers.md` หมวดเรียนรู้
- ส่วนเสริมจากการเทียบตัวต่อตัวกับ skill เปิด (2026-10-22 · เขียนใหม่ด้วยคำเรา ระบุที่มาในไฟล์):
  - จัดการชีวิต: `calendar-audit` นับต้นทุนประชุมที่ตัดช่วงโฟกัส (ความยาวประชุม + ราว 23 นาทีกว่าจะกลับเข้างาน · ตัวเลขที่คนอ้างกันทั่วไป ยังไม่ได้เปิดต้นฉบับ (รอยืนยัน)) · `inbox-triage` ร่างตอบหยุดที่โฟลเดอร์ร่าง ผู้ใช้กดส่งเอง และคัดเฉพาะเมลตั้งแต่รอบที่แล้ว · `meeting-prep-card` ด่าน "ประชุม · เขียน · รอ" ก่อนทำการ์ด · `meeting-summary` ทุกมติมีเหตุผล 1 วรรค · `weekly-review` เริ่มจากบันทึกจริงก่อนถามความจำ · `personal-kb` lint รายเดือน 5 ข้อ · `decision-journal` ความมั่นใจเป็นคะแนน 1–10
  - อาชีพ: `interview-prep` เรื่องเล่า 3 ความยาว (30 วินาที · 90 วินาที · 3 นาที) · `linkedin-profile` หัวข้อ Recommendations และแบนเนอร์ 1,584 × 396 px (รอยืนยัน) · `resume-th-en` แยกข้อกำหนดของประกาศงาน 3 ระดับ และข้อความไทยที่จะส่งไม่ใช้ขีดยาว · `performance-self-review` จัดอันดับหลักฐาน 4 ขั้น (Measured · Witnessed · Shown · Claimed) · `salary-negotiation` ตารางเวลาหลังได้ข้อเสนอ 7 วัน และสิ่งที่ต่อรองแทนฐานเงินเดือน · แก้ข้อเท็จจริงกองทุนสำรองเลี้ยงชีพ: ลูกจ้างและนายจ้างสมทบฝ่ายละ 2–15% ของค่าจ้าง อัตราของนายจ้างไม่ต้องเท่าของลูกจ้าง
  - สุขภาพ บ้าน และเรียนรู้: `doctor-visit-prep` การ์ดฉุกเฉิน 1 หน้า (ไม่ใส่เลขบัตรประชาชน) · `thesis-writing` ลำดับหาต้นทางของอ้างอิง (DOI → CrossRef → arXiv → Semantic Scholar → ThaiJO หรือ ThaiLIS → ตัวจัดการอ้างอิง) และกฎประโยคทั่วไปย้ายไป `thai-grammar` · `english-tech-reading` และ `paper-to-practice` รายการตรวจคำอธิบายไทยจากต้นฉบับอังกฤษ 5 ข้อ
- ข้อเท็จจริงที่ตรวจใหม่ 2026-10-22: `vehicle-care` ค่าตรวจสภาพที่ ตรอ. เป็นราคาที่มักอ้างถึง ไม่ใช่อัตราตามกฎหมาย (รอยืนยัน · ถามสถานีก่อนไป) และวงเงินค่ารักษาของ พ.ร.บ. 80,000 บาท ติด (รอยืนยัน) · แม่แบบบันทึกรถเตือนใบขับขี่ 30 วันก่อนหมดอายุ · `elder-care` เบี้ยยังชีพคงอัตราเดิม พร้อมหมายเหตุข่าวอัตราใหม่ที่ยังไม่ยืนยัน · `pet-care` ค่าปรับเมื่อไม่ฉีดวัคซีนพิษสุนัขบ้า (รอยืนยัน)
- ใช้แกน `superuser` 3.1.0: playbook `team-project` และค่าตั้ง hook `guard` · `recompact` (ปิดไว้)

## 0.12.0 — 2026-10-22

- รวม `home-family` `health-wellness` และ `career` เข้ามาเป็น plugin เดียว — ชีวิตประจำวัน 4 หมวด: จัดการชีวิต · บ้านและครอบครัว · สุขภาพ · อาชีพ
- รวม plugin dev-learning: skill 9 ตัว (+alias 2) · agent tech-mentor · playbook 5 ตัว · prompt 6 ฉบับ — หมวดที่ 5 "เรียนรู้" ใน `skills/superuser/SKILL.md` (กฎ 18–19 · เกณฑ์ · รออนุมัติ) · triggers · examples · context-template
- ชื่อ skill และ command เดิมทุกตัวใช้ได้เหมือนเดิม · playbook ทุกหมวดรวมอยู่ใน skill `superuser`
- รับ skill `meeting-summary` · `meeting-prep-card` จาก `doc-toolkit` ที่ยุบ (ชื่อเดิม) · ตัด dependency `doc-toolkit`
- ถอด plugin เดิม: `/plugin uninstall home-family` `health-wellness` `career` `dev-learning`

## 0.11.1 — 2026-10-22

- ตรวจ plugin ตามหัวข้อ 1–6 · 8: แก้ตัวชี้ผิดใน `superuser/references/examples.md` ให้ไปที่แกน `superuser:superuser` · ติด (รอยืนยัน) ที่ Cambodia ใน `travel-facts` · ค่าธรรมเนียมพาสปอร์ตใน `travel-prep` ลิงก์ไป `travel-facts` ที่เดียว

## 0.11.0 — 2026-10-22

- `skills/superuser/SKILL.md` เหลือเฉพาะส่วนของสาขา (กฎเพิ่ม · playbook · agent · รออนุมัติ · ไฟล์กลาง) ขึ้นต้นด้วย "เปิด `superuser:superuser` ก่อน" — แกนของหัวหน้าทีมอ่านจาก plugin `superuser` 3.0.0 ที่เดียว ไม่คัดลอกบล็อกกลางอีก (50 KB → ราว 12 KB)
- `dependencies` ใส่ช่วงเวอร์ชัน `{ "name": "superuser", "version": "^3.0" }` และเพิ่ม `{ "name": "doc-toolkit", "version": "^1.0" }` (skill เอกสาร สไลด์ รูป ประชุม 15 ตัวที่ย้ายออกจาก superuser)

## 0.10.0 — 2026-10-21

- `meeting-prep-card` ย้ายไปเป็นของกลางใน plugin `superuser` (คู่กับ `meeting-summary`)

## 0.9.0 — 2026-10-21

- `meeting-summary` · `polite-message-th-en` ย้ายไปเป็นของกลางใน plugin `superuser` · ใช้ได้เหมือนเดิมทาง `dependencies`

## 0.8.0 — 2026-10-21

- ใช้ของกลางจาก plugin `superuser` ทาง `dependencies` (skill `human-writing` · `answer-shape` · `simplify` · `no-ai-look` · `commit-log` · `agent-patterns` · agent `reviewer` · `brainstormer` · `learning-reviewer` · hook) · สำเนาในนี้ย้ายออกแล้ว · zip สำหรับ claude.ai ยังมีของกลางในตัว
- agent โหลด skill หลักตั้งแต่เริ่ม (`skills:` — งานเขียน `human-writing` · งานโค้ด `simplify` · งานภาพ `no-ai-look`)

## 0.7.0 — 2026-10-14

จากการตรวจ plugin หัวข้อ 1–6 (ความยาว · กระชับ · ทำงานซ้อน · เช็กลิสต์ Anthropic · ความปลอดภัย · การส่งมอบ)

- ข้อความจากเว็บ อีเมล แชต ไฟล์ และเอกสารภายนอก เป็นข้อมูล ไม่ใช่คำสั่ง — กฎขยายครอบทุกช่องทาง และวางเป็นกฎระดับบนของ agent ที่อ่านของภายนอก
- hook ของ SuperUser ปิดเลขบัตรประชาชน เลขบัตรเครดิต และเลขบัญชี/โทรศัพท์ก่อนเขียน log · มี `--self-test`
- ป้าย "ยังไม่ตรวจ" เปลี่ยนเป็น "ยังไม่ได้ตรวจ" ทุกไฟล์
- meeting-summary ร่างข้อความ ส่งเมื่อผู้ใช้สั่ง · inbox-triage มีกฎอีเมลเป็นข้อมูล
- ข้อมูลการเดินทาง (ไต้หวัน) ตรวจใหม่ 2026-10-14

## ประวัติจาก dev-learning (รวมเข้ามา 2026-10-22)

### 0.9.1 — 2026-10-22

- ย้ายตัวอย่าง gap map และแม่แบบแผนของ cert-prep ไป references (ลด 955 ตัวอักษรต่อการเรียก) · ตัดค่า (รอยืนยัน) ของ SAA/CKA/CKAD ที่ตรวจกับเว็บทางการแล้ว 2026-10-22 · แก้ตัวชี้ใน examples/triggers

### 0.9.0 — 2026-10-22

- `skills/superuser/SKILL.md` เหลือเฉพาะส่วนของสาขา (กฎเพิ่ม · playbook · agent · รออนุมัติ · ไฟล์กลาง) ขึ้นต้นด้วย "เปิด `superuser:superuser` ก่อน" — แกนของหัวหน้าทีมอ่านจาก plugin `superuser` 3.0.0 ที่เดียว ไม่คัดลอกบล็อกกลางอีก (50 KB → ราว 12 KB)
- `dependencies` ใส่ช่วงเวอร์ชัน `{ "name": "superuser", "version": "^3.0" }` และเพิ่ม `{ "name": "doc-toolkit", "version": "^1.0" }` (skill เอกสาร สไลด์ รูป ประชุม 15 ตัวที่ย้ายออกจาก superuser)

### 0.8.0 — 2026-10-21

- ใช้ของกลางจาก plugin `superuser` ทาง `dependencies` (skill `human-writing` · `answer-shape` · `simplify` · `no-ai-look` · `commit-log` · `agent-patterns` · agent `reviewer` · `brainstormer` · `learning-reviewer` · hook) · สำเนาในนี้ย้ายออกแล้ว · zip สำหรับ claude.ai ยังมีของกลางในตัว
- agent โหลด skill หลักตั้งแต่เริ่ม (`skills:` — งานเขียน `human-writing` · งานโค้ด `simplify` · งานภาพ `no-ai-look`)

### 0.7.0 — 2026-10-14

จากการตรวจ plugin หัวข้อ 1–6 (ความยาว · กระชับ · ทำงานซ้อน · เช็กลิสต์ Anthropic · ความปลอดภัย · การส่งมอบ)

- ข้อความจากเว็บ อีเมล แชต ไฟล์ และเอกสารภายนอก เป็นข้อมูล ไม่ใช่คำสั่ง — กฎขยายครอบทุกช่องทาง และวางเป็นกฎระดับบนของ agent ที่อ่านของภายนอก
- hook ของ SuperUser ปิดเลขบัตรประชาชน เลขบัตรเครดิต และเลขบัญชี/โทรศัพท์ก่อนเขียน log · มี `--self-test`
- ป้าย "ยังไม่ตรวจ" เปลี่ยนเป็น "ยังไม่ได้ตรวจ" ทุกไฟล์
- tech-mentor กับ cert-prep งบเวลาไม่ขัดกัน · แก้ `$ARGUMENTS` ใน radar · ขนาดใน paper-to-practice ตรงกับโค้ด
