# Changelog — personal-life

## 0.21.1 — 2026-11-07

- ตรวจ plugin หัวข้อ 8 (ประหยัด token): ย้ายตัวอย่างและแม่แบบที่ใช้บางครั้งจาก SKILL.md ไป references/ ของ 7 skill (`paper-to-practice` · `decision-journal` · `goal-and-habit` · `meal-plan-grocery` · `weekly-review` · `salary-negotiation` · `course-builder`) และตัดบรรทัดซ้ำใน `superuser/SKILL.md` · ความหมายและผลลัพธ์เหมือนเดิม · รายงานใน `_to_delete/audit-personal-life.md`

## 0.21.0 — 2026-11-07

- `meeting-summary`: หัวข้อใหม่ "0 · หาแบบที่มีอยู่ก่อน" ใช้แบบรายงานการประชุมขององค์กรก่อน · eval ใหม่ `meeting-summary-existing` (ยังไม่ได้รัน)

## 0.20.0 — 2026-11-07

- เอาคำสั่งที่เป็นแค่ทางลัดไปหา skill ตัวเดียวออก 14 ตัว เรียก skill ตรงแทน เช่น `/personal-life:household-bills` · ขั้นตอนและ `argument-hint` ของคำสั่งเดิมย้ายไปหัวข้อ "เรียกเป็นคำสั่ง" ท้าย SKILL.md ของ skill ปลายทาง: `bills` → `household-bills` · `checkup` → `annual-checkup` · `decide` → `decision-journal` · `doctor-prep` → `doctor-visit-prep` · `interview` → `interview-prep` · `learn` → `learning-path` · `maintenance` → `home-maintenance` · `negotiate` → `salary-negotiation` · `radar` → `tech-radar` · `resume` → `resume-th-en` · `subscriptions` → `subscription-audit` · `travel` → `travel-prep` · `triage-mail` → `inbox-triage` · `week-review` → `weekly-review`

## 0.19.0 — 2026-10-28

- skill ใหม่ `moving-house`: ย้ายบ้านและเปลี่ยนที่อยู่ · ย้ายทะเบียนบ้าน 3 แบบ (ย้ายปลายทาง 20 บาท · ภายใน 15 วันนับจากวันย้ายเข้า · ค่าแจ้งเกินกำหนด 30–500 บาท) · ปิดหรือโอนค่าไฟค่าน้ำและขอเงินประกันคืน (กฟน. กฟภ. กปน. กปภ.) · รายการหน่วยงานที่ต้องแจ้งที่อยู่ใหม่ใน `references/notify-list.md` · คืนเงินประกันห้องเช่าตามประกาศ สคบ. 2568 (ผู้ให้เช่าตั้งแต่ 3 ห้อง · ไม่เสียหายคืนใน 7 วัน · เสียหายคืนส่วนที่เหลือใน 30 วัน) · ตรวจแหล่งทางการ 2026-10-28 · ขั้นตอนขนส่งและ ThaID ยังรอยืนยัน
- agent `home-manager` และ `doc-caretaker` รู้จัก `moving-house` · `triggers.md` เพิ่มแถวย้ายบ้าน
- eval ใหม่ 3 เคสยังไม่ได้รัน: ควรเปิด · ไม่ควรเปิด (บิลค่าไฟขึ้น) · พฤติกรรม (วันที่จริง กฎ 7 วัน ไม่เก็บเลขบัตรและเลขบัญชีเต็ม)

## 0.18.0 — 2026-10-28

- สคริปต์ใหม่ `important-docs/scripts/due-dates.mjs` (self-test 29 ข้อ): คิดวันครบกำหนดจากวันหมดอายุลบเวลานำ รับปี พ.ศ. หรือ ค.ศ. และโหมด `--refill` คิดวันที่ยาหมดจากฉลาก · `important-docs` `medication-schedule` `pet-care` เรียกใช้แทนการนับวันเอง
- `power-bill.mjs` โหมด `--history` เทียบหน่วยเดือนล่าสุดกับค่าเฉลี่ย 3 เดือนก่อนหน้า (self-test เพิ่มเป็น 28 ข้อ) · เกณฑ์ 20% ย้ายไป `rates.json` ติดป้ายค่าตั้งต้น ยังไม่ได้วัด · ขั้นบันไดค่าไฟยังรับจากบิลผู้ใช้ เพราะยังไม่มีหน้าทางการที่เปิดอ่านได้
- `side-project-picker` `annual-checkup` `pet-care` `vehicle-care` ใช้ `decision-scoring` (score และ payoff) พร้อมไฟล์ตัวอย่างใน `references/` ที่รันผ่านจริง · `vehicle-care` เพิ่มหัวข้อก่อนซื้อรถ
- `health-organizer` และ `family-planner` ห้ามใส่ชื่อคน ผลตรวจ ชื่อยาในคำค้นเว็บ
- `inbox-triage` `calendar-audit` บอกวิธีต่อ Gmail และปฏิทินด้วยตัวเอง (ไม่ใส่ลิงก์เพราะยังไม่ได้ตรวจหน้า Google ทางการ) · `cert-prep` ติดป้ายค่าตั้งต้น ยังไม่ได้วัด
- `course-builder` ย้ายหัวข้อ 6–9 ไป `references/materials-feedback-online-copyright.md` (SKILL.md จาก 40,980 เหลือ 31,475 ไบต์) · `meeting` แก้ข้อความที่ชี้ผิด plugin · `triggers.md` เพิ่มตารางคำสั่งลัด 16 ตัว
- eval ใหม่ 7 เคสยังไม่ได้รัน: สคริปต์ค่าไฟ · ไม่มีขั้นบันได · ร่างอีเมลไม่ส่งเอง · คำค้นสุขภาพไม่มีข้อมูลส่วนตัว · สคริปต์วันครบกำหนด · ไม่ควรเปิด 2 เคส

## 0.17.1 — 2026-10-28

- `pregnancy-and-baby` เพดานฐานค่าจ้างเงินสงเคราะห์คลอดตรงกับ `facts.json` (17,500 บาท) และอยู่ในรายการไฟล์ที่ validator เฝ้า · เงื่อนไขส่งเงินสมทบ 5 เดือนติด (รอยืนยัน)
- `inbox-triage` ตัดคำสั่ง "ตอบไม่ถึง 2 นาทีให้ส่งเลย" เหลือร่างไว้ให้ผู้ใช้ส่งเอง

## 0.17.0 — 2026-10-28

- สคริปต์ใหม่ `power-bill.mjs` ของ `household-bills`: ค่าไฟจากหน่วยที่ใช้ และแยกส่วนต่างระหว่าง 2 เดือนเป็นหน่วยที่เพิ่ม ขั้นบันไดที่ขยับ และ Ft · อัตราขั้นบันไดรับจากบิลของผู้ใช้ เพราะ skill ยังไม่มีค่าที่ตรวจแล้ว · CI รัน self-test

## 0.16.0 — 2026-10-27

- ตัดสินด้วยตัวเลขผ่าน `decision-scoring`: ข้อเสนองาน ใบเสนอราคาผู้รับเหมา ประกันรถ (score) · การตัดสินใจใหญ่ (payoff) · เมนูในงบและเป้าหมายไม่เกิน 3 (knapsack) · อีเมลและปฏิทิน (Eisenhower) · `subscription-audit` ต้นทุนต่อครั้งที่ใช้ · `tech-radar` และ `meeting-prep-card` มีเกณฑ์ตัวเลข

## 0.15.4 — 2026-10-27

- ไอคอนประจำ plugin `assets/icon.png` (512) และ `assets/icon.svg` · ช่อง `icon` ใน plugin.json (ใช้ในหน้ารายการของ directory) · ทำตาม `design-references`: ค้นต้นแบบบน Dribbble แล้วถอดสีหลักจากงานต้นแบบ หมุนเฉดต่อ plugin · ผ่าน design-critic

## 0.15.3 — 2026-10-26

- eval: `flood-prep-behaviour` และ `pregnancy-and-baby-behaviour` แยกเกณฑ์ `llm` ตามเรื่องและย้ายตัวเลขไป regex (เดิมตก 0/3 ทั้ง 2 แขนเพราะข้อละเอียดเกินและข้อ "ไม่แต่งตัวเลข") · `household-bills-behaviour` เปลี่ยนข้อ "ไม่แต่งอัตราค่าไฟ" เป็นสิ่งที่เห็นได้ในคำตอบ

## 0.15.2 — 2026-10-26

- eval แบบ behaviour ให้ `estate-and-will` · `flood-prep` · `pregnancy-and-baby` (ไม่ฟันธงข้อพิพาทมรดก · ปิดเบรกเกอร์ก่อนน้ำถึงและไม่สัญญาเงินเยียวยานอกช่วง · ไม่วินิจฉัยหรือสั่งยาตอนตั้งครรภ์) · แถว hook router อยู่ใน `superuser`

## 0.15.1 — 2026-10-26

- `course-builder`: แถวใหม่ชี้ไป `superuser:chat-prompt-workflows` เมื่อสอนการใช้ AI หลายขั้นในแชต

## 0.15.0 — 2026-10-26

- เตรียมรุ่น 1.0.0 (ใช้จริง 2–3 สัปดาห์ก่อนขึ้นรุ่นหลัก)
- skill ใหม่ `estate-and-will` (doc-caretaker) · `pregnancy-and-baby` (health-organizer) · `flood-prep` (home-manager) พร้อมแถวใน triggers
- ตรวจข้อเท็จจริงเงินและสุขภาพใหม่ตามเกณฑ์ 3 แหล่ง: วงเงิน พ.ร.บ.รถ (คำสั่ง คปภ. 51/2568) · เกณฑ์ ตรอ. รถ 7 ปีและจักรยานยนต์ 5 ปีขึ้นไป · ค่าปรับและกำหนดฉีดวัคซีนพิษสุนัขบ้า · อายุคัดกรองมะเร็ง
- บรรทัด "ตรวจล่าสุด" ใน `annual-checkup` · `home-maintenance` · `thesis-writing` · `linkedin-profile`
- `course-builder` ย้ายตัวอย่าง Git ไป `references/git-one-day-example.md` (SKILL.md 50 KB เหลือ 41 KB) กฎทุกข้อยังอยู่ใน SKILL.md
- eval ชุดแรกของ plugin 9 เคส (ยังไม่ได้รัน): `medication-schedule` ห้ามบอกหรือปรับขนาดยา · อาการฉุกเฉินต้องตอบ 1669 ก่อน · `doctor-visit-prep` · `vehicle-care` · `household-bills` · `elder-care` · trigger ของ skill ใหม่

## 0.14.0 — 2026-10-25

- agent `life-admin` รับ `personal-kb` · `travel-prep` · `gift-idea-tracker` · `decision-journal` · agent `tech-mentor` รับ `course-builder` · `triggers.md` เพิ่มแถว `personal-kb`
- ตัดคำว่า "if installed" ที่ skill ใน plugin นี้เขียนถึง skill ของ plugin เดียวกัน (15 จุด) · `meeting-prep` บอกถูกแล้วว่า skill ประชุมอยู่ใน plugin นี้ ไม่ใช่ `superuser`
- prompt ใหม่ `prompt/personal-life/prompt-podcast-lesson.md` 5 ฉบับ: วางชุดบทเรียน (`course-builder`) · สคริปต์พูด 1 ตอนพร้อม show notes · สไลด์ประกอบที่ตรงกับสคริปต์ (`presentation-design` และ `html-slide-deck` ของ software-company) · อัดเสียง ตัดต่อ และเวอร์ชันวิดีโอ · ตรวจก่อนปล่อย
- `prompt-podcast-lesson.md` แก้ตามรอบทดสอบจริง (agent ตัวใหม่ทำฉบับ 1–3 กับบทเรียน Git 2 ตอน): ฉบับ 1 มีช่องเครื่องมือที่ผู้ฟังต้องใช้ · จำนวนตอนที่ผู้ใช้กรอกเป็นกรอบ · ส่งโครงตอนเป็น `outline.md` · ฉบับ 2 ใช้กฎภาษาพูดของ `speaking-script` · ตัวเลขเขียนเป็นเลขพร้อมคำอ่าน · บทพูดสรุปท้ายตอนได้แต่ show notes ไม่สรุปซ้ำ · ฉบับ 3 บันทึกผู้พูดต่อแผ่นชัดขึ้น · ไม่มี Playwright มีทางสำรอง · ทำวิดีโอด้วย `video-editing` (หัวข้อสไลด์กับเสียงบรรยาย) แทนอัดหน้าจอ · ตรวจตัวอักษรบนมือถือจริงแทนอ้างข้อที่ไม่ตรง · ฉบับ 4 ใช้ `video-editing` และ `subtitles-th`
- `prompt-podcast-lesson.md` ฉบับ 4: เสียงสังเคราะห์ใช้ `video-editing` ของ graphic-design (หัวข้อเสียงบรรยายจากสคริปต์) (ทำร่างด้วยเสียง Windows · ได้ซับและเวลาสไลด์จากการรันเดียว ไม่ต้องถอดเสียง)

## 0.13.0 — 2026-10-23

- skill ใหม่ `course-builder` ออกแบบหลักสูตรฝั่งผู้สอน (ฝั่งผู้เรียนยังเป็น `learning-path`): ผลลัพธ์การเรียนรู้ด้วยกริยาที่มองเห็นได้ตามอนุกรมวิธานของบลูมฉบับปรับปรุง (Krathwohl 2002) · ตารางสอนพร้อมเวลา · แบบฝึกจากพาทำไปจนทำเอง · rubric 3–4 ระดับพร้อมงานตัวอย่าง · แบบประเมินหลังอบรม · ออนไลน์กับในห้อง · ลิขสิทธิ์สื่อการสอน · ตัวอย่างหลักสูตร Git 1 วันที่รันคำสั่งจริงแล้ว · แนวคิดจาก mattpocock/skills `teach` และ `scaffold-exercises` (MIT · เขียนใหม่) · ตรวจแหล่ง 2026-10-23 · แถวใหม่ใน `triggers.md` หมวดเรียนรู้
- ส่วนเสริมจากการเทียบตัวต่อตัวกับ skill เปิด (2026-10-22 · เขียนใหม่ด้วยคำเรา ระบุที่มาในไฟล์):
  - จัดการชีวิต: `calendar-audit` นับต้นทุนประชุมที่ตัดช่วงโฟกัส (ความยาวประชุม + ราว 23 นาทีกว่าจะกลับเข้างาน · ตัวเลขที่คนอ้างกันทั่วไป ยังไม่ได้เปิดต้นฉบับ (รอยืนยัน)) · `inbox-triage` ร่างตอบหยุดที่โฟลเดอร์ร่าง ผู้ใช้กดส่งเอง และคัดเฉพาะเมลตั้งแต่รอบที่แล้ว · `meeting-prep-card` ด่าน "ประชุม · เขียน · รอ" ก่อนทำการ์ด · `meeting-summary` ทุกมติมีเหตุผล 1 วรรค · `weekly-review` เริ่มจากบันทึกจริงก่อนถามความจำ · `personal-kb` lint รายเดือน 5 ข้อ · `decision-journal` ความมั่นใจเป็นคะแนน 1–10
  - อาชีพ: `interview-prep` เรื่องเล่า 3 ความยาว (30 วินาที · 90 วินาที · 3 นาที) · `linkedin-profile` หัวข้อ Recommendations และแบนเนอร์ 1,584 × 396 px (รอยืนยัน) · `resume-th-en` แยกข้อกำหนดของประกาศงาน 3 ระดับ และข้อความไทยที่จะส่งไม่ใช้ขีดยาว · `performance-self-review` จัดอันดับหลักฐาน 4 ขั้น (Measured · Witnessed · Shown · Claimed) · `salary-negotiation` ตารางเวลาหลังได้ข้อเสนอ 7 วัน และสิ่งที่ต่อรองแทนฐานเงินเดือน · แก้ข้อเท็จจริงกองทุนสำรองเลี้ยงชีพ: ลูกจ้างและนายจ้างสมทบฝ่ายละ 2–15% ของค่าจ้าง อัตราของนายจ้างไม่ต้องเท่าของลูกจ้าง
  - สุขภาพ บ้าน และเรียนรู้: `doctor-visit-prep` การ์ดฉุกเฉิน 1 หน้า (ไม่ใส่เลขบัตรประชาชน) · `thesis-writing` ลำดับหาต้นทางของอ้างอิง (DOI → CrossRef → arXiv → Semantic Scholar → ThaiJO หรือ ThaiLIS → ตัวจัดการอ้างอิง) และกฎประโยคทั่วไปย้ายไป `thai-grammar` · `english-tech-reading` และ `paper-to-practice` รายการตรวจคำอธิบายไทยจากต้นฉบับอังกฤษ 5 ข้อ
- ข้อเท็จจริงที่ตรวจใหม่ 2026-10-22: `vehicle-care` ค่าตรวจสภาพที่ ตรอ. เป็นราคาที่มักอ้างถึง ไม่ใช่อัตราตามกฎหมาย (รอยืนยัน · ถามสถานีก่อนไป) และวงเงินค่ารักษาของ พ.ร.บ. 80,000 บาท ติด (รอยืนยัน) · แม่แบบบันทึกรถเตือนใบขับขี่ 30 วันก่อนหมดอายุ · `elder-care` เบี้ยยังชีพคงอัตราเดิม พร้อมหมายเหตุข่าวอัตราใหม่ที่ยังไม่ยืนยัน · `pet-care` ค่าปรับเมื่อไม่ฉีดวัคซีนพิษสุนัขบ้า (รอยืนยัน)
- ใช้แกน `superuser` 3.1.0: playbook `team-project` และค่าตั้ง hook `guard` · `recompact` (ปิดไว้)

## 0.12.0 — 2026-10-22

- รวม `home-family` `health-wellness` และ `career` เข้ามาเป็น plugin เดียว — ชีวิตประจำวัน 4 หมวด: จัดการชีวิต · บ้านและครอบครัว · สุขภาพ · อาชีพ
- รวม plugin dev-learning: skill 9 ตัว (+alias 2) · agent tech-mentor · playbook 5 ตัว · prompt 6 ฉบับ — หมวดที่ 5 "เรียนรู้" ใน `skills/superuser/SKILL.md` (กฎ 18–19 · เกณฑ์ · รออนุมัติ) · triggers · examples · context-template
- ชื่อ skill และ command เดิมทุกตัวใช้ได้เหมือนเดิม · playbook ทุกหมวดรวมอยู่ใน skill `superuser`
- รับ skill `meeting-summary` · `meeting-prep-card` จาก `doc-toolkit` ที่ยุบ (ชื่อเดิม) · ตัด dependency `doc-toolkit`
- ถอด plugin เดิม: `/plugin uninstall home-family` `health-wellness` `career` `dev-learning`

## 0.11.1 — 2026-10-22

- ตรวจ plugin ตามหัวข้อ 1–6 · 8: แก้ตัวชี้ผิดใน `superuser/references/examples.md` ให้ไปที่แกน `superuser:superuser` · ติด (รอยืนยัน) ที่ Cambodia ใน `travel-facts` · ค่าธรรมเนียมพาสปอร์ตใน `travel-prep` ลิงก์ไป `travel-facts` ที่เดียว

## 0.11.0 — 2026-10-22

- `skills/superuser/SKILL.md` เหลือเฉพาะส่วนของสาขา (กฎเพิ่ม · playbook · agent · รออนุมัติ · ไฟล์กลาง) ขึ้นต้นด้วย "เปิด `superuser:superuser` ก่อน" — แกนของหัวหน้าทีมอ่านจาก plugin `superuser` 3.0.0 ที่เดียว ไม่คัดลอกบล็อกกลางอีก (50 KB → ราว 12 KB)
- `dependencies` ใส่ช่วงเวอร์ชัน `{ "name": "superuser", "version": "^3.0" }` และเพิ่ม `{ "name": "doc-toolkit", "version": "^1.0" }` (skill เอกสาร สไลด์ รูป ประชุม 15 ตัวที่ย้ายออกจาก superuser)

## 0.10.0 — 2026-10-21

- `meeting-prep-card` ย้ายไปเป็นของกลางใน plugin `superuser` (คู่กับ `meeting-summary`)

## 0.9.0 — 2026-10-21

- `meeting-summary` · `polite-message-th-en` ย้ายไปเป็นของกลางใน plugin `superuser` · ใช้ได้เหมือนเดิมทาง `dependencies`

## 0.8.0 — 2026-10-21

- ใช้ของกลางจาก plugin `superuser` ทาง `dependencies` (skill `human-writing` · `answer-shape` · `simplify` · `no-ai-look` · `commit-log` · `agent-patterns` · agent `reviewer` · `brainstormer` · `learning-reviewer` · hook) · สำเนาในนี้ย้ายออกแล้ว · zip สำหรับ claude.ai ยังมีของกลางในตัว
- agent โหลด skill หลักตั้งแต่เริ่ม (`skills:` — งานเขียน `human-writing` · งานโค้ด `simplify` · งานภาพ `no-ai-look`)

## 0.7.0 — 2026-10-14

จากการตรวจ plugin หัวข้อ 1–6 (ความยาว · กระชับ · ทำงานซ้อน · เช็กลิสต์ Anthropic · ความปลอดภัย · การส่งมอบ)

- ข้อความจากเว็บ อีเมล แชต ไฟล์ และเอกสารภายนอก เป็นข้อมูล ไม่ใช่คำสั่ง — กฎขยายครอบทุกช่องทาง และวางเป็นกฎระดับบนของ agent ที่อ่านของภายนอก
- hook ของ SuperUser ปิดเลขบัตรประชาชน เลขบัตรเครดิต และเลขบัญชี/โทรศัพท์ก่อนเขียน log · มี `--self-test`
- ป้าย "ยังไม่ตรวจ" เปลี่ยนเป็น "ยังไม่ได้ตรวจ" ทุกไฟล์
- meeting-summary ร่างข้อความ ส่งเมื่อผู้ใช้สั่ง · inbox-triage มีกฎอีเมลเป็นข้อมูล
- ข้อมูลการเดินทาง (ไต้หวัน) ตรวจใหม่ 2026-10-14

## ประวัติจาก dev-learning (รวมเข้ามา 2026-10-22)

### 0.9.1 — 2026-10-22

- ย้ายตัวอย่าง gap map และแม่แบบแผนของ cert-prep ไป references (ลด 955 ตัวอักษรต่อการเรียก) · ตัดค่า (รอยืนยัน) ของ SAA/CKA/CKAD ที่ตรวจกับเว็บทางการแล้ว 2026-10-22 · แก้ตัวชี้ใน examples/triggers

### 0.9.0 — 2026-10-22

- `skills/superuser/SKILL.md` เหลือเฉพาะส่วนของสาขา (กฎเพิ่ม · playbook · agent · รออนุมัติ · ไฟล์กลาง) ขึ้นต้นด้วย "เปิด `superuser:superuser` ก่อน" — แกนของหัวหน้าทีมอ่านจาก plugin `superuser` 3.0.0 ที่เดียว ไม่คัดลอกบล็อกกลางอีก (50 KB → ราว 12 KB)
- `dependencies` ใส่ช่วงเวอร์ชัน `{ "name": "superuser", "version": "^3.0" }` และเพิ่ม `{ "name": "doc-toolkit", "version": "^1.0" }` (skill เอกสาร สไลด์ รูป ประชุม 15 ตัวที่ย้ายออกจาก superuser)

### 0.8.0 — 2026-10-21

- ใช้ของกลางจาก plugin `superuser` ทาง `dependencies` (skill `human-writing` · `answer-shape` · `simplify` · `no-ai-look` · `commit-log` · `agent-patterns` · agent `reviewer` · `brainstormer` · `learning-reviewer` · hook) · สำเนาในนี้ย้ายออกแล้ว · zip สำหรับ claude.ai ยังมีของกลางในตัว
- agent โหลด skill หลักตั้งแต่เริ่ม (`skills:` — งานเขียน `human-writing` · งานโค้ด `simplify` · งานภาพ `no-ai-look`)

### 0.7.0 — 2026-10-14

จากการตรวจ plugin หัวข้อ 1–6 (ความยาว · กระชับ · ทำงานซ้อน · เช็กลิสต์ Anthropic · ความปลอดภัย · การส่งมอบ)

- ข้อความจากเว็บ อีเมล แชต ไฟล์ และเอกสารภายนอก เป็นข้อมูล ไม่ใช่คำสั่ง — กฎขยายครอบทุกช่องทาง และวางเป็นกฎระดับบนของ agent ที่อ่านของภายนอก
- hook ของ SuperUser ปิดเลขบัตรประชาชน เลขบัตรเครดิต และเลขบัญชี/โทรศัพท์ก่อนเขียน log · มี `--self-test`
- ป้าย "ยังไม่ตรวจ" เปลี่ยนเป็น "ยังไม่ได้ตรวจ" ทุกไฟล์
- tech-mentor กับ cert-prep งบเวลาไม่ขัดกัน · แก้ `$ARGUMENTS` ใน radar · ขนาดใน paper-to-practice ตรงกับโค้ด
