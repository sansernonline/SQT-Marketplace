---
name: quotation
description: Draft a Thai quotation, invoice or receipt — VAT, total in digits and Thai words, payment terms — as .docx.
argument-hint: <customer> <items and prices> [terms]
disable-model-invocation: true
---

Run `doc-quotation` with the `thai-doc-writer` agent for: **$ARGUMENTS**

Confirm VAT rate and payment terms before producing the final document; amounts in digits and Thai words must match exactly.
