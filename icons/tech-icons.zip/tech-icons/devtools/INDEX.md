# ไอคอน devtools

**572 ไอคอน** · SVG มีสีในตัว — โลโก้เครื่องมือของนักพัฒนา

```html
<img src="devtools/postgresql.svg">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `A` · 39 ไอคอน

`aarch64`  `adonisjs`  `aerospike`  `aframe`  `aftereffects`  `akka`  `algolia`  `almalinux`  `alpinejs`  `anaconda`  `android`  `androidstudio`  `angular`  `angularjs`  `angularmaterial`  `ansible`  `ansys`  `antdesign`  `apache`  `apacheairflow`  `apachekafka`  `apachespark`  `apex`  `apl`  `apollographql`  `appcelerator`  `apple`  `appwrite`  `archlinux`  `arduino`  `argocd`  `artixlinux`  `astro`  `atom`  `awk`  `axios`  `azure`  `azuredevops`  `azuresqldatabase`

## `B` · 19 ไอคอน

`babel`  `babylonjs`  `backbonejs`  `ballerina`  `bamboo`  `bash`  `bazel`  `beats`  `behance`  `bevyengine`  `biome`  `bitbucket`  `blazor`  `blender`  `bootstrap`  `bower`  `browserstack`  `bulma`  `bun`

## `C` · 43 ไอคอน

`c`  `cairo`  `cakephp`  `canva`  `capacitor`  `carbon`  `cassandra`  `centos`  `ceylon`  `chakraui`  `chartjs`  `chrome`  `circleci`  `clarity`  `clickhouse`  `clion`  `clojure`  `clojurescript`  `cloudflare`  `cloudflareworkers`  `cloudrun`  `cmake`  `cobol`  `codeac`  `codecov`  `codeigniter`  `codepen`  `coffeescript`  `composer`  `confluence`  `consul`  `contao`  `corejs`  `cosmosdb`  `couchbase`  `couchdb`  `cpanel`  `cplusplus`  `crystal`  `csharp`  `css3`  `cucumber`  `cypressio`

## `D` · 29 ไอคอน

`d3js`  `dart`  `datadog`  `datagrip`  `dataspell`  `datatables`  `dbeaver`  `debian`  `delphi`  `denojs`  `detaspace`  `devicon`  `digitalocean`  `discloud`  `discordjs`  `django`  `djangorest`  `docker`  `doctrine`  `dot-net`  `dotnetcore`  `dovecot`  `dreamweaver`  `dropwizard`  `drupal`  `duckdb`  `dyalog`  `dynamodb`  `dynatrace`

## `E` · 16 ไอคอน

`eclipse`  `ecto`  `elasticsearch`  `electron`  `eleventy`  `elixir`  `elm`  `emacs`  `embeddedc`  `ember`  `entityframeworkcore`  `envoy`  `erlang`  `eslint`  `expo`  `express`

## `F` · 22 ไอคอน

`facebook`  `fastapi`  `fastify`  `faunadb`  `feathersjs`  `fedora`  `fiber`  `figma`  `filamentphp`  `filezilla`  `firebase`  `firebird`  `firefox`  `flask`  `flutter`  `forgejo`  `fortran`  `foundation`  `framermotion`  `framework7`  `fsharp`  `fusion`

## `G` · 33 ไอคอน

`gardener`  `gatling`  `gatsby`  `gazebo`  `gcc`  `gentoo`  `ghost`  `gimp`  `git`  `gitbook`  `github`  `githubactions`  `githubcodespaces`  `gitkraken`  `gitlab`  `gitpod`  `gitter`  `gleam`  `glitch`  `go`  `godot`  `goland`  `google`  `googlecloud`  `googlecolab`  `gradle`  `grafana`  `grails`  `graphql`  `groovy`  `grpc`  `grunt`  `gulp`

## `H` · 16 ไอคอน

`hadoop`  `handlebars`  `harbor`  `hardhat`  `harvester`  `haskell`  `haxe`  `helm`  `heroku`  `hibernate`  `homebrew`  `hoppscotch`  `html5`  `htmx`  `hugo`  `hyperv`

## `I` · 9 ไอคอน

`ie10`  `ifttt`  `illustrator`  `inertiajs`  `influxdb`  `inkscape`  `insomnia`  `intellij`  `ionic`

## `J` · 20 ไอคอน

`jaegertracing`  `jamstack`  `jasmine`  `java`  `javascript`  `jeet`  `jekyll`  `jenkins`  `jest`  `jetbrains`  `jetpackcompose`  `jhipster`  `jira`  `jiraalign`  `jquery`  `json`  `jule`  `julia`  `junit`  `jupyter`

## `K` · 17 ไอคอน

`k3os`  `k3s`  `k6`  `kaggle`  `kaldi`  `kalilinux`  `karatelabs`  `karma`  `kdeneon`  `keras`  `kibana`  `knexjs`  `kotlin`  `krakenjs`  `ktor`  `kubeflow`  `kubernetes`

## `L` · 18 ไอคอน

`labview`  `laminas`  `laravel`  `laraveljetstream`  `latex`  `leetcode`  `libgdx`  `linkedin`  `linux`  `linuxmint`  `liquibase`  `livewire`  `llvm`  `lodash`  `logstash`  `love2d`  `lua`  `lumen`

## `M` · 27 ไอคอน

`magento`  `mapbox`  `mariadb`  `markdown`  `materializecss`  `materialui`  `matlab`  `matplotlib`  `mattermost`  `maven`  `maya`  `memcached`  `mercurial`  `meteor`  `microsoftsqlserver`  `minitab`  `mithril`  `mobx`  `mocha`  `modx`  `moleculer`  `mongodb`  `mongoose`  `monogame`  `moodle`  `msdos`  `mysql`

## `N` · 31 ไอคอน

`nano`  `nats`  `neo4j`  `neovim`  `nestjs`  `netbeans`  `netbox`  `netlify`  `networkx`  `newrelic`  `nextjs`  `nginx`  `ngrok`  `ngrx`  `nhibernate`  `nim`  `nimble`  `nixos`  `nodejs`  `nodemon`  `nodered`  `nodewebkit`  `nomad`  `norg`  `notion`  `npm`  `npss`  `nuget`  `numpy`  `nuxt`  `nuxtjs`

## `O` · 16 ไอคอน

`oauth`  `objectivec`  `ocaml`  `ohmyzsh`  `okta`  `openal`  `openapi`  `opencl`  `opencv`  `opengl`  `openstack`  `opensuse`  `opentelemetry`  `opera`  `oracle`  `ory`

## `P` · 45 ไอคอน

`p5js`  `packer`  `pandas`  `passport`  `perl`  `pfsense`  `phalcon`  `phoenix`  `photonengine`  `photoshop`  `php`  `phpstorm`  `pixijs`  `playwright`  `plotly`  `pm2`  `pnpm`  `podman`  `poetry`  `polygon`  `portainer`  `postcss`  `postgresql`  `postman`  `powershell`  `premierepro`  `primeng`  `prisma`  `processing`  `processwire`  `prolog`  `prometheus`  `protractor`  `proxmox`  `pug`  `pulsar`  `pulumi`  `puppeteer`  `purescript`  `putty`  `pycharm`  `pypi`  `pytest`  `python`  `pytorch`

## `Q` · 6 ไอคอน

`qodana`  `qt`  `qtest`  `quarkus`  `quasar`  `qwik`

## `R` · 36 ไอคอน

`r`  `rabbitmq`  `racket`  `radstudio`  `rails`  `railway`  `rancher`  `raspberrypi`  `reach`  `react`  `reactbootstrap`  `reactnative`  `reactnavigation`  `reactrouter`  `readthedocs`  `realm`  `rect`  `redhat`  `redis`  `redux`  `reflex`  `remix`  `renpy`  `replit`  `rexx`  `rider`  `rocksdb`  `rockylinux`  `rollup`  `ros`  `rspec`  `rstudio`  `ruby`  `rubymine`  `rust`  `rxjs`

## `S` · 48 ไอคอน

`safari`  `salesforce`  `sanity`  `sass`  `scala`  `scalingo`  `scikitlearn`  `sdl`  `selenium`  `sema`  `sentry`  `sequelize`  `shopware`  `shotgrid`  `sketch`  `slack`  `socketio`  `solidity`  `solidjs`  `sonarqube`  `sourceengine`  `sourcetree`  `spack`  `spicedb`  `spring`  `spss`  `spyder`  `sqlalchemy`  `sqldeveloper`  `sqlite`  `ssh`  `stackblitz`  `stackoverflow`  `stenciljs`  `storybook`  `streamlit`  `styledcomponents`  `stylus`  `subversion`  `sulu`  `supabase`  `surrealdb`  `svelte`  `svgo`  `swagger`  `swift`  `swiper`  `symfony`

## `T` · 27 ไอคอน

`tailwindcss`  `talos`  `tauri`  `teleport`  `tensorflow`  `terraform`  `terramate`  `tex`  `thealgorithms`  `threedsmax`  `threejs`  `thymeleaf`  `titaniumsdk`  `tmux`  `tomcat`  `tortoisegit`  `towergit`  `traefikmesh`  `traefikproxy`  `travis`  `trello`  `trpc`  `turbo`  `twilio`  `twitter`  `typescript`  `typo3`

## `U` · 6 ไอคอน

`ubuntu`  `unifiedmodelinglanguage`  `unity`  `unix`  `unrealengine`  `uwsgi`

## `V` · 23 ไอคอน

`v8`  `vaadin`  `vagrant`  `vala`  `vault`  `veevalidate`  `vercel`  `vertx`  `vim`  `visualbasic`  `visualstudio`  `vite`  `vitejs`  `vitess`  `vitest`  `vscode`  `vscodium`  `vsphere`  `vuejs`  `vuestorefront`  `vuetify`  `vulkan`  `vyper`

## `W` · 13 ไอคอน

`waku`  `wasm`  `web3js`  `webflow`  `webgpu`  `weblate`  `webpack`  `webstorm`  `windows11`  `windows8`  `wolfram`  `woocommerce`  `wordpress`

## `X` · 4 ไอคอน

`xamarin`  `xcode`  `xd`  `xml`

## `Y` · 5 ไอคอน

`yaml`  `yarn`  `yii`  `yugabytedb`  `yunohost`

## `Z` · 4 ไอคอน

`zend`  `zig`  `zsh`  `zustand`
