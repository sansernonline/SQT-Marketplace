# ไอคอน gis

**65 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="platform/gis/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `cli` · 6 ไอคอน

`gdal`  `imposm`  `lastools`  `mapnik`  `mdal`  `pdal`

## `data` · 5 ไอคอน

`ban`  `here`  `ign`  `openstreetmap`  `overturemaps`

## `database` · 1 ไอคอน

`postgis`

## `desktop` · 2 ไอคอน

`maptunik`  `qgis`

## `format` · 2 ไอคอน

`geopackage`  `geoparquet`

## `geocoding` · 4 ไอคอน

`addok`  `gisgraphy`  `nominatim`  `pelias`

## `java` · 1 ไอคอน

`geotools`

## `javascript` · 8 ไอคอน

`cesium`  `geostyler`  `keplerjs`  `leaflet`  `maplibre`  `ol-ext`  `openlayers`  `turfjs`

## `misc` · 1 ไอคอน

`gis`

## `mobile` · 3 ไอคอน

`mergin`  `qfield`  `smash`

## `ogc` · 3 ไอคอน

`ogc`  `wfs`  `wms`

## `organization` · 1 ไอคอน

`osgeo`

## `python` · 2 ไอคอน

`geopandas`  `pysal`

## `routing` · 4 ไอคอน

`graphhopper`  `osrm`  `pgrouting`  `valhalla`

## `server` · 22 ไอคอน

`actinia`  `baremaps`  `deegree`  `g3w-suite`  `geohealthcheck`  `geomapfish`  `geomesa`  `geonetwork`  `geonode`  `georchestra`  `geoserver`  `geowebcache`  `kepler`  `mapproxy`  `mapserver`  `mapstore`  `mviewer`  `pg_tileserv`  `pycsw`  `pygeoapi`  `qgis-server`  `zooproject`
