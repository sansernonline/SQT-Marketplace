# ไอคอน onprem

**173 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="platform/onprem/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `aggregator` · 2 ไอคอน

`fluentd`  `vector`

## `analytics` · 17 ไอคอน

`beam`  `databricks`  `dbt`  `dremio`  `flink`  `hadoop`  `hive`  `metabase`  `norikra`  `powerbi`  `presto`  `singer`  `spark`  `storm`  `superset`  `tableau`  `trino`

## `auth` · 3 ไอคอน

`boundary`  `buzzfeed-sso`  `oauth2-proxy`

## `cd` · 3 ไอคอน

`spinnaker`  `tekton-cli`  `tekton`

## `certificates` · 2 ไอคอน

`cert-manager`  `lets-encrypt`

## `ci` · 9 ไอคอน

`circleci`  `concourseci`  `droneci`  `github-actions`  `gitlabci`  `jenkins`  `teamcity`  `travisci`  `zuulci`

## `client` · 3 ไอคอน

`client`  `user`  `users`

## `compute` · 2 ไอคอน

`nomad`  `server`

## `container` · 8 ไอคอน

`containerd`  `crio`  `docker`  `firecracker`  `gvisor`  `k3s`  `lxc`  `rkt`

## `database` · 20 ไอคอน

`cassandra`  `clickhouse`  `cockroachdb`  `couchbase`  `couchdb`  `dgraph`  `druid`  `duckdb`  `hbase`  `influxdb`  `janusgraph`  `mariadb`  `mongodb`  `mssql`  `mysql`  `neo4j`  `oracle`  `postgresql`  `qdrant`  `scylla`

## `dns` · 2 ไอคอน

`coredns`  `powerdns`

## `etl` · 1 ไอคอน

`embulk`

## `gitops` · 3 ไอคอน

`argocd`  `flagger`  `flux`

## `groupware` · 1 ไอคอน

`nextcloud`

## `iac` · 6 ไอคอน

`ansible`  `atlantis`  `awx`  `pulumi`  `puppet`  `terraform`

## `identity` · 1 ไอคอน

`dex`

## `inmemory` · 4 ไอคอน

`aerospike`  `hazelcast`  `memcached`  `redis`

## `logging` · 5 ไอคอน

`fluentbit`  `graylog`  `loki`  `rsyslog`  `syslog-ng`

## `messaging` · 1 ไอคอน

`centrifugo`

## `misc` · 1 ไอคอน

`onprem`

## `mlops` · 2 ไอคอน

`mlflow`  `polyaxon`

## `monitoring` · 14 ไอคอน

`cortex`  `datadog`  `dynatrace`  `grafana`  `humio`  `mimir`  `nagios`  `newrelic`  `prometheus-operator`  `prometheus`  `sentry`  `splunk`  `thanos`  `zabbix`

## `network` · 34 ไอคอน

`ambassador`  `apache`  `bind-9`  `caddy`  `cisco-router`  `cisco-switch-l2`  `cisco-switch-l3`  `consul`  `envoy`  `etcd`  `glassfish`  `gunicorn`  `haproxy`  `internet`  `istio`  `jbossas`  `jetty`  `kong`  `linkerd`  `mikrotik`  `nginx`  `ocelot`  `open-service-mesh`  `opnsense`  `pfsense`  `pomerium`  `powerdns`  `tomcat`  `traefik`  `tyk`  `vyos`  `wildfly`  `yarp`  `zookeeper`

## `proxmox` · 1 ไอคอน

`pve`

## `queue` · 7 ไอคอน

`activemq`  `celery`  `emqx`  `kafka`  `nats`  `rabbitmq`  `zeromq`

## `registry` · 2 ไอคอน

`harbor`  `jfrog`

## `search` · 1 ไอคอน

`solr`

## `security` · 3 ไอคอน

`bitwarden`  `trivy`  `vault`

## `storage` · 4 ไอคอน

`ceph-osd`  `ceph`  `glusterfs`  `portworx`

## `tracing` · 2 ไอคอน

`jaeger`  `tempo`

## `vcs` · 5 ไอคอน

`git`  `gitea`  `github`  `gitlab`  `svn`

## `workflow` · 4 ไอคอน

`airflow`  `digdag`  `kubeflow`  `nifi`
