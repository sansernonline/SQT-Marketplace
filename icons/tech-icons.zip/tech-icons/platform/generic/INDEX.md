# ไอคอน generic

**27 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="platform/generic/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `blank` · 1 ไอคอน

`blank`

## `compute` · 1 ไอคอน

`rack`

## `database` · 1 ไอคอน

`sql`

## `device` · 2 ไอคอน

`mobile`  `tablet`

## `misc` · 1 ไอคอน

`generic`

## `network` · 5 ไอคอน

`firewall`  `router`  `subnet`  `switch`  `vpn`

## `os` · 10 ไอคอน

`android`  `centos`  `debian`  `ios`  `linux-general`  `raspbian`  `red-hat`  `suse`  `ubuntu`  `windows`

## `place` · 1 ไอคอน

`datacenter`

## `storage` · 1 ไอคอน

`storage`

## `virtualization` · 4 ไอคอน

`qemu`  `virtualbox`  `vmware`  `xen`
