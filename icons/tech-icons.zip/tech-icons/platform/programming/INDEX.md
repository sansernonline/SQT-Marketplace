# ไอคอน programming

**74 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="platform/programming/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `flowchart` · 24 ไอคอน

`action`  `collate`  `database`  `decision`  `delay`  `display`  `document`  `input-output`  `inspection`  `internal-storage`  `loop-limit`  `manual-input`  `manual-loop`  `merge`  `multiple-documents`  `off-page-connector-left`  `off-page-connector-right`  `or`  `predefined-process`  `preparation`  `sort`  `start-end`  `stored-data`  `summing-junction`

## `framework` · 25 ไอคอน

`angular`  `backbone`  `camel`  `django`  `dotnet`  `ember`  `fastapi`  `flask`  `flutter`  `graphql`  `hibernate`  `jhipster`  `laravel`  `micronaut`  `nextjs`  `phoenix`  `quarkus`  `rails`  `react`  `spring`  `sqlpage`  `starlette`  `svelte`  `vercel`  `vue`

## `language` · 23 ไอคอน

`bash`  `c`  `cpp`  `csharp`  `dart`  `elixir`  `erlang`  `go`  `java`  `javascript`  `kotlin`  `latex`  `matlab`  `nodejs`  `php`  `python`  `r`  `ruby`  `rust`  `scala`  `sql`  `swift`  `typescript`

## `misc` · 1 ไอคอน

`programming`

## `runtime` · 1 ไอคอน

`dapr`
