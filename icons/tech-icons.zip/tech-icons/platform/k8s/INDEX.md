# ไอคอน k8s

**46 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="platform/k8s/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `chaos` · 2 ไอคอน

`chaos-mesh`  `litmus-chaos`

## `clusterconfig` · 3 ไอคอน

`hpa`  `limits`  `quota`

## `compute` · 7 ไอคอน

`cronjob`  `deploy`  `ds`  `job`  `pod`  `rs`  `sts`

## `controlplane` · 6 ไอคอน

`api`  `c-c-m`  `c-m`  `k-proxy`  `kubelet`  `sched`

## `ecosystem` · 4 ไอคอน

`external-dns`  `helm`  `krew`  `kustomize`

## `group` · 1 ไอคอน

`ns`

## `infra` · 3 ไอคอน

`etcd`  `master`  `node`

## `misc` · 1 ไอคอน

`k8s`

## `network` · 4 ไอคอน

`ep`  `ing`  `netpol`  `svc`

## `others` · 2 ไอคอน

`crd`  `psp`

## `podconfig` · 2 ไอคอน

`cm`  `secret`

## `rbac` · 7 ไอคอน

`c-role`  `crb`  `group`  `rb`  `role`  `sa`  `user`

## `storage` · 4 ไอคอน

`pv`  `pvc`  `sc`  `vol`
