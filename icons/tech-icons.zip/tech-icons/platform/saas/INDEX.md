# ไอคอน saas

**41 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="platform/saas/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `alerting` · 5 ไอคอน

`newrelic`  `opsgenie`  `pagerduty`  `pushover`  `xmatters`

## `analytics` · 3 ไอคอน

`dataform`  `snowflake`  `stitch`

## `automation` · 1 ไอคอน

`n8n`

## `cdn` · 4 ไอคอน

`akamai`  `cloudflare`  `fastly`  `imperva`

## `chat` · 8 ไอคอน

`discord`  `line`  `mattermost`  `messenger`  `rocket-chat`  `slack`  `teams`  `telegram`

## `communication` · 1 ไอคอน

`twilio`

## `crm` · 2 ไอคอน

`intercom`  `zendesk`

## `filesharing` · 1 ไอคอน

`nextcloud`

## `identity` · 2 ไอคอน

`auth0`  `okta`

## `logging` · 3 ไอคอน

`datadog`  `newrelic`  `papertrail`

## `media` · 1 ไอคอน

`cloudinary`

## `misc` · 1 ไอคอน

`saas`

## `payment` · 4 ไอคอน

`adyen`  `amazon-pay`  `paypal`  `stripe`

## `recommendation` · 1 ไอคอน

`recombee`

## `security` · 2 ไอคอน

`crowdstrike`  `sonarqube`

## `social` · 2 ไอคอน

`facebook`  `twitter`
