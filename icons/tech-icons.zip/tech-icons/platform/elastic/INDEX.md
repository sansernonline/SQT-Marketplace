# ไอคอน elastic

**45 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="platform/elastic/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `agent` · 4 ไอคอน

`agent`  `endpoint`  `fleet`  `integrations`

## `beats` · 8 ไอคอน

`apm`  `auditbeat`  `filebeat`  `functionbeat`  `heartbeat`  `metricbeat`  `packetbeat`  `winlogbeat`

## `elasticsearch` · 14 ไอคอน

`alerting`  `beats`  `elasticsearch`  `kibana`  `logstash-pipeline`  `logstash`  `machine-learning`  `map-services`  `maps`  `monitoring`  `searchable-snapshots`  `security-settings`  `sql`  `stack`

## `enterprisesearch` · 5 ไอคอน

`app-search`  `crawler`  `enterprise-search`  `site-search`  `workplace-search`

## `misc` · 1 ไอคอน

`elastic`

## `observability` · 5 ไอคอน

`apm`  `logs`  `metrics`  `observability`  `uptime`

## `orchestration` · 2 ไอคอน

`ece`  `eck`

## `saas` · 2 ไอคอน

`cloud`  `elastic`

## `security` · 4 ไอคอน

`endpoint`  `security`  `siem`  `xdr`
