# ไอคอน gcp

**123 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="cloud/gcp/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `analytics` · 11 ไอคอน

`bigquery`  `composer`  `data-catalog`  `data-fusion`  `dataflow`  `datalab`  `dataprep`  `dataproc`  `genomics`  `looker`  `pubsub`

## `api` · 3 ไอคอน

`api-gateway`  `apigee`  `endpoints`

## `compute` · 12 ไอคอน

`app-engine`  `binary-authorization`  `compute-engine`  `container-optimized-os`  `functions`  `gke-on-prem`  `gpu`  `kubernetes-engine`  `os-configuration-management`  `os-inventory-management`  `os-patch-management`  `run`

## `database` · 6 ไอคอน

`bigtable`  `datastore`  `firestore`  `memorystore`  `spanner`  `sql`

## `devtools` · 17 ไอคอน

`build`  `cloud-shell`  `code-for-intellij`  `code`  `container-registry`  `gradle-app-engine-plugin`  `ide-plugins`  `maven-app-engine-plugin`  `scheduler`  `sdk`  `service-catalog`  `source-repositories`  `tasks`  `test-lab`  `tools-for-eclipse`  `tools-for-powershell`  `tools-for-visual-studio`

## `iot` · 1 ไอคอน

`iot-core`

## `management` · 4 ไอคอน

`billing`  `project`  `quotas`  `support`

## `migration` · 2 ไอคอน

`migrate-compute-engine`  `transfer-appliance`

## `misc` · 1 ไอคอน

`gcp`

## `ml` · 22 ไอคอน

`advanced-solutions-lab`  `ai-hub`  `ai-platform-data-labeling-service`  `ai-platform`  `automl-natural-language`  `automl-tables`  `automl-translation`  `automl-video-intelligence`  `automl-vision`  `automl`  `dialog-flow-enterprise-edition`  `inference-api`  `jobs-api`  `natural-language-api`  `recommendations-ai`  `speech-to-text`  `text-to-speech`  `tpu`  `translation-api`  `vertex-ai`  `video-intelligence-api`  `vision-api`

## `network` · 25 ไอคอน

`armor`  `cdn`  `cloud-ids`  `dedicated-interconnect`  `dns`  `external-ip-addresses`  `firewall-rules`  `load-balancing`  `nat`  `network-connectivity-center`  `network-intelligence-center`  `network-security`  `network-tiers`  `network-topology`  `network`  `partner-interconnect`  `premium-network-tier`  `private-service-connect`  `router`  `routes`  `service-mesh`  `standard-network-tier`  `traffic-director`  `virtual-private-cloud`  `vpn`

## `operations` · 2 ไอคอน

`logging`  `monitoring`

## `security` · 13 ไอคอน

`access-context-manager`  `assured-workloads`  `certificate-authority-service`  `certificate-manager`  `cloud-asset-inventory`  `iam`  `iap`  `key-management-service`  `resource-manager`  `secret-manager`  `security-command-center`  `security-health-advisor`  `security-scanner`

## `storage` · 4 ไอคอน

`filestore`  `local-ssd`  `persistent-disk`  `storage`
