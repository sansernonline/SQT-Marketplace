# ไอคอน alibabacloud

**95 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="cloud/alibabacloud/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `analytics` · 5 ไอคอน

`analytic-db`  `click-house`  `data-lake-analytics`  `elatic-map-reduce`  `open-search`

## `application` · 14 ไอคอน

`api-gateway`  `bee-bot`  `blockchain-as-a-service`  `cloud-call-center`  `code-pipeline`  `direct-mail`  `log-service`  `message-notification-service`  `node-js-performance-platform`  `open-search`  `performance-testing-service`  `rd-cloud`  `smart-conversation-analysis`  `yida`

## `communication` · 2 ไอคอน

`direct-mail`  `mobile-push`

## `compute` · 15 ไอคอน

`auto-scaling`  `batch-compute`  `container-registry`  `container-service`  `elastic-compute-service`  `elastic-container-instance`  `elastic-high-performance-computing`  `elastic-search`  `function-compute`  `operation-orchestration-service`  `resource-orchestration-service`  `server-load-balancer`  `serverless-app-engine`  `simple-application-server`  `web-app-service`

## `database` · 17 ไอคอน

`apsaradb-cassandra`  `apsaradb-hbase`  `apsaradb-memcache`  `apsaradb-mongodb`  `apsaradb-oceanbase`  `apsaradb-polardb`  `apsaradb-postgresql`  `apsaradb-ppas`  `apsaradb-redis`  `apsaradb-sqlserver`  `data-management-service`  `data-transmission-service`  `database-backup-service`  `disribute-relational-database-service`  `graph-database-service`  `hybriddb-for-mysql`  `relational-database-service`

## `iot` · 4 ไอคอน

`iot-internet-device-id`  `iot-link-wan`  `iot-mobile-connection-package`  `iot-platform`

## `misc` · 1 ไอคอน

`alibabacloud`

## `network` · 9 ไอคอน

`cdn`  `cloud-enterprise-network`  `elastic-ip-address`  `express-connect`  `nat-gateway`  `server-load-balancer`  `smart-access-gateway`  `virtual-private-cloud`  `vpn-gateway`

## `security` · 18 ไอคอน

`anti-bot-service`  `anti-ddos-basic`  `anti-ddos-pro`  `antifraud-service`  `bastion-host`  `cloud-firewall`  `cloud-security-scanner`  `content-moderation`  `crowdsourced-security-testing`  `data-encryption-service`  `db-audit`  `game-shield`  `id-verification`  `managed-security-service`  `security-center`  `server-guard`  `ssl-certificates`  `web-application-firewall`

## `storage` · 8 ไอคอน

`cloud-storage-gateway`  `file-storage-hdfs`  `file-storage-nas`  `hybrid-backup-recovery`  `hybrid-cloud-disaster-recovery`  `imm`  `object-storage-service`  `object-table-store`

## `web` · 2 ไอคอน

`dns`  `domain`
