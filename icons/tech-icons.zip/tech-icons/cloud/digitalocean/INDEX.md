# ไอคอน digitalocean

**26 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="cloud/digitalocean/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `compute` · 8 ไอคอน

`containers`  `docker`  `droplet-connect`  `droplet-snapshot`  `droplet`  `k8s-cluster`  `k8s-node-pool`  `k8s-node`

## `database` · 4 ไอคอน

`dbaas-primary-standby-more`  `dbaas-primary`  `dbaas-read-only`  `dbaas-standby`

## `misc` · 1 ไอคอน

`digitalocean`

## `network` · 9 ไอคอน

`certificate`  `domain-registration`  `domain`  `firewall`  `floating-ip`  `internet-gateway`  `load-balancer`  `managed-vpn`  `vpc`

## `storage` · 4 ไอคอน

`folder`  `space`  `volume-snapshot`  `volume`
