# ไอคอน oci

**141 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="cloud/oci/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `compute` · 16 ไอคอน

`autoscale-white`  `autoscale`  `bm-white`  `bm`  `container-white`  `container`  `functions-white`  `functions`  `instance-pools-white`  `instance-pools`  `ocir-white`  `ocir`  `oke-white`  `oke`  `vm-white`  `vm`

## `connectivity` · 18 ไอคอน

`backbone-white`  `backbone`  `cdn-white`  `cdn`  `customer-datacenter`  `customer-datacntr-white`  `customer-premises-white`  `customer-premises`  `disconnected-regions-white`  `disconnected-regions`  `dns-white`  `dns`  `fast-connect-white`  `fast-connect`  `nat-gateway-white`  `nat-gateway`  `vpn-white`  `vpn`

## `database` · 18 ไอคอน

`autonomous-white`  `autonomous`  `bigdata-service-white`  `bigdata-service`  `database-service-white`  `database-service`  `dataflow-apache-white`  `dataflow-apache`  `dcat-white`  `dcat`  `dis-white`  `dis`  `dms-white`  `dms`  `science-white`  `science`  `stream-white`  `stream`

## `devops` · 6 ไอคอน

`api-gateway-white`  `api-gateway`  `api-service-white`  `api-service`  `resource-mgmt-white`  `resource-mgmt`

## `governance` · 14 ไอคอน

`audit-white`  `audit`  `compartments-white`  `compartments`  `groups-white`  `groups`  `logging-white`  `logging`  `ocid-white`  `ocid`  `policies-white`  `policies`  `tagging-white`  `tagging`

## `misc` · 1 ไอคอน

`oci`

## `monitoring` · 18 ไอคอน

`alarm-white`  `alarm`  `email-white`  `email`  `events-white`  `events`  `health-check-white`  `health-check`  `notifications-white`  `notifications`  `queue-white`  `queue`  `search-white`  `search`  `telemetry-white`  `telemetry`  `workflow-white`  `workflow`

## `network` · 16 ไอคอน

`drg-white`  `drg`  `firewall-white`  `firewall`  `internet-gateway-white`  `internet-gateway`  `load-balancer-white`  `load-balancer`  `route-table-white`  `route-table`  `security-lists-white`  `security-lists`  `service-gateway-white`  `service-gateway`  `vcn-white`  `vcn`

## `security` · 16 ไอคอน

`cloud-guard-white`  `cloud-guard`  `ddos-white`  `ddos`  `encryption-white`  `encryption`  `id-access-white`  `id-access`  `key-management-white`  `key-management`  `max-security-zone-white`  `max-security-zone`  `vault-white`  `vault`  `waf-white`  `waf`

## `storage` · 18 ไอคอน

`backup-restore-white`  `backup-restore`  `block-storage-clone-white`  `block-storage-clone`  `block-storage-white`  `block-storage`  `buckets-white`  `buckets`  `data-transfer-white`  `data-transfer`  `elastic-performance-white`  `elastic-performance`  `file-storage-white`  `file-storage`  `object-storage-white`  `object-storage`  `storage-gateway-white`  `storage-gateway`
