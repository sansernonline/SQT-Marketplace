# ไอคอน outscale

**13 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="cloud/outscale/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `compute` · 2 ไอคอน

`compute`  `direct-connect`

## `misc` · 1 ไอคอน

`outscale`

## `network` · 6 ไอคอน

`client-vpn`  `internet-service`  `load-balancer`  `nat-service`  `net`  `site-to-site-vpng`

## `security` · 2 ไอคอน

`firewall`  `identity-and-access-management`

## `storage` · 2 ไอคอน

`simple-storage-service`  `storage`
