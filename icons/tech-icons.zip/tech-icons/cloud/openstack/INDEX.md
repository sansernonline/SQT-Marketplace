# ไอคอน openstack

**51 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="cloud/openstack/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `apiproxies` · 1 ไอคอน

`ec2api`

## `applicationlifecycle` · 4 ไอคอน

`freezer`  `masakari`  `murano`  `solum`

## `baremetal` · 2 ไอคอน

`cyborg`  `ironic`

## `billing` · 1 ไอคอน

`cloudkitty`

## `compute` · 3 ไอคอน

`nova`  `qinling`  `zun`

## `containerservices` · 1 ไอคอน

`kuryr`

## `deployment` · 6 ไอคอน

`ansible`  `charms`  `chef`  `helm`  `kolla`  `tripleo`

## `frontend` · 1 ไอคอน

`horizon`

## `misc` · 1 ไอคอน

`openstack`

## `monitoring` · 2 ไอคอน

`monasca`  `telemetry`

## `multiregion` · 1 ไอคอน

`tricircle`

## `networking` · 3 ไอคอน

`designate`  `neutron`  `octavia`

## `nfv` · 1 ไอคอน

`tacker`

## `optimization` · 4 ไอคอน

`congress`  `rally`  `vitrage`  `watcher`

## `orchestration` · 5 ไอคอน

`blazar`  `heat`  `mistral`  `senlin`  `zaqar`

## `packaging` · 3 ไอคอน

`loci`  `puppet`  `rpm`

## `sharedservices` · 5 ไอคอน

`barbican`  `glance`  `karbor`  `keystone`  `searchlight`

## `storage` · 3 ไอคอน

`cinder`  `manila`  `swift`

## `user` · 1 ไอคอน

`openstackclient`

## `workloadprovisioning` · 3 ไอคอน

`magnum`  `sahara`  `trove`
