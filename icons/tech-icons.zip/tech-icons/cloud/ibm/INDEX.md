# ไอคอน ibm

**181 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="cloud/ibm/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `analytics` · 5 ไอคอน

`analytics`  `data-integration`  `data-repositories`  `device-analytics`  `streaming-computing`

## `applications` · 19 ไอคอน

`actionable-insight`  `annotate`  `api-developer-portal`  `api-polyglot-runtimes`  `app-server`  `application-logic`  `enterprise-applications`  `index`  `iot-application`  `microservice`  `mobile-app`  `ontology`  `open-source-tools`  `runtime-services`  `saas-applications`  `service-broker`  `speech-to-text`  `visual-recognition`  `visualization`

## `blockchain` · 20 ไอคอน

`blockchain-developer`  `blockchain`  `certificate-authority`  `client-application`  `communication`  `consensus`  `event-listener`  `event`  `existing-enterprise-systems`  `hyperledger-fabric`  `key-management`  `ledger`  `membership-services-provider-api`  `membership`  `message-bus`  `node`  `services`  `smart-contract`  `transaction-manager`  `wallet`

## `compute` · 5 ไอคอน

`bare-metal-server`  `image-service`  `instance`  `key`  `power-instance`

## `data` · 13 ไอคอน

`caches`  `cloud`  `conversation-trained-deployed`  `data-services`  `data-sources`  `device-identity-service`  `device-registry`  `enterprise-data`  `enterprise-user-directory`  `file-repository`  `ground-truth`  `model`  `tms-data-interface`

## `devops` · 10 ไอคอน

`artifact-management`  `build-test`  `code-editor`  `collaborative-development`  `configuration-management`  `continuous-deploy`  `continuous-testing`  `devops`  `provision`  `release-management`

## `general` · 27 ไอคอน

`cloud-messaging`  `cloud-services`  `cloudant`  `cognitive-services`  `data-security`  `enterprise`  `governance-risk-compliance`  `ibm-containers`  `ibm-public-cloud`  `identity-access-management`  `identity-provider`  `infrastructure-security`  `internet`  `iot-cloud`  `microservices-application`  `microservices-mesh`  `monitoring-logging`  `monitoring`  `object-storage`  `offline-capabilities`  `openwhisk`  `peer-cloud`  `retrieve-rank`  `scalable`  `service-discovery-configuration`  `text-to-speech`  `transformation-connectivity`

## `infrastructure` · 18 ไอคอน

`channels`  `cloud-messaging`  `dashboard`  `diagnostics`  `edge-services`  `enterprise-messaging`  `event-feed`  `infrastructure-services`  `interservice-communication`  `load-balancing-routing`  `microservices-mesh`  `mobile-backend`  `mobile-provider-network`  `monitoring-logging`  `monitoring`  `peer-services`  `service-discovery-configuration`  `transformation-connectivity`

## `management` · 15 ไอคอน

`alert-notification`  `api-management`  `cloud-management`  `cluster-management`  `content-management`  `data-services`  `device-management`  `information-governance`  `it-service-management`  `management`  `monitoring-metrics`  `process-management`  `provider-cloud-portal-service`  `push-notifications`  `service-management-tools`

## `misc` · 1 ไอคอน

`ibm`

## `network` · 21 ไอคอน

`bridge`  `direct-link`  `enterprise`  `firewall`  `floating-ip`  `gateway`  `internet-services`  `load-balancer-listener`  `load-balancer-pool`  `load-balancer`  `load-balancing-routing`  `public-gateway`  `region`  `router`  `rules`  `subnet`  `transit-gateway`  `vpc`  `vpn-connection`  `vpn-gateway`  `vpn-policy`

## `security` · 14 ไอคอน

`api-security`  `blockchain-security-service`  `data-security`  `firewall`  `gateway`  `governance-risk-compliance`  `identity-access-management`  `identity-provider`  `infrastructure-security`  `physical-security`  `security-monitoring-intelligence`  `security-services`  `trustend-computing`  `vpn`

## `social` · 5 ไอคอน

`communities`  `file-sync`  `live-collaboration`  `messaging`  `networking`

## `storage` · 2 ไอคอน

`block-storage`  `object-storage`

## `user` · 6 ไอคอน

`browser`  `device`  `integrated-digital-experiences`  `physical-entity`  `sensor`  `user`
