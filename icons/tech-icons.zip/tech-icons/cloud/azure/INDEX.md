# ไอคอน azure

**808 ไอคอน** · PNG พื้นโปร่ง 160×160

```html
<img src="cloud/azure/<กลุ่ม>/<ชื่อ>.png">
```

เปิด `contact-sheet.html` เพื่อดูรูปทั้งหมดในหน้าเดียว

---

## `aimachinelearning` · 32 ไอคอน

`ai-studio`  `anomaly-detector`  `azure-applied-ai-services`  `azure-experimentation-studio`  `azure-object-understanding`  `azure-openai`  `batch-ai`  `bonsai`  `bot-services`  `cognitive-search`  `cognitive-services-decisions`  `cognitive-services`  `computer-vision`  `content-moderators`  `custom-vision`  `face-apis`  `form-recognizers`  `genomics-accounts`  `genomics`  `immersive-readers`  `language-understanding`  `language`  `machine-learning-studio-classic-web-services`  `machine-learning-studio-web-service-plans`  `machine-learning-studio-workspaces`  `machine-learning`  `metrics-advisor`  `personalizers`  `qna-makers`  `serverless-search`  `speech-services`  `translator-text`

## `analytics` · 20 ไอคอน

`analysis-services`  `azure-data-explorer-clusters`  `azure-databricks`  `azure-synapse-analytics`  `azure-workbooks`  `data-explorer-clusters`  `data-factories`  `data-lake-analytics`  `data-lake-store-gen1`  `databricks`  `endpoint-analytics`  `event-hub-clusters`  `event-hubs`  `hd-insight-clusters`  `log-analytics-workspaces`  `power-bi-embedded`  `power-platform`  `private-link-services`  `stream-analytics-jobs`  `synapse-analytics`

## `appservices` · 8 ไอคอน

`app-service-certificates`  `app-service-domains`  `app-service-environments`  `app-service-plans`  `app-services`  `cdn-profiles`  `cognitive-search`  `notification-hubs`

## `azureecosystem` · 3 ไอคอน

`applens`  `azure-hybrid-center`  `collaborative-service`

## `azurestack` · 7 ไอคอน

`capacity`  `infrastructure-backup`  `multi-tenancy`  `offers`  `plans`  `updates`  `user-subscriptions`

## `blockchain` · 6 ไอคอน

`abs-member`  `azure-blockchain-service`  `azure-token-service`  `blockchain-applications`  `consortium`  `outbound-connection`

## `compute` · 53 ไอคอน

`app-services`  `application-group`  `automanaged-vm`  `availability-sets`  `azure-compute-galleries`  `azure-spring-apps`  `batch-accounts`  `citrix-virtual-desktops-essentials`  `cloud-services-classic`  `cloud-services`  `cloudsimple-virtual-machines`  `container-apps`  `container-instances`  `container-registries`  `container-services-deprecated`  `disk-encryption-sets`  `disk-snapshots`  `disks-classic`  `disks-snapshots`  `disks`  `function-apps`  `host-groups`  `host-pools`  `hosts`  `image-definitions`  `image-templates`  `image-versions`  `images`  `kubernetes-services`  `maintenance-configuration`  `managed-service-fabric`  `mesh-applications`  `metrics-advisor`  `os-images-classic`  `os-images`  `restore-points-collections`  `restore-points`  `sap-hana-on-azure`  `service-fabric-clusters`  `shared-image-galleries`  `spring-cloud`  `virtual-machine`  `virtual-machines-classic`  `vm-classic`  `vm-images-classic`  `vm-images`  `vm-linux`  `vm-scale-set`  `vm-scale-sets`  `vm-windows`  `vm`  `workspaces-2`  `workspaces`

## `containers` · 7 ไอคอน

`app-services`  `azure-red-hat-openshift`  `batch-accounts`  `container-instances`  `container-registries`  `kubernetes-services`  `service-fabric-clusters`

## `database` · 24 ไอคอน

`blob-storage`  `cache-for-redis`  `cosmos-db`  `data-explorer-clusters`  `data-factory`  `data-lake`  `database-for-mariadb-servers`  `database-for-mysql-servers`  `database-for-postgresql-servers`  `elastic-database-pools`  `elastic-job-agents`  `instance-pools`  `managed-databases`  `sql-databases`  `sql-datawarehouse`  `sql-managed-instances`  `sql-server-stretch-databases`  `sql-servers`  `sql-vm`  `sql`  `ssis-lift-and-shift-ir`  `synapse-analytics`  `virtual-clusters`  `virtual-datacenter`

## `databases` · 27 ไอคอน

`azure-cosmos-db`  `azure-data-explorer-clusters`  `azure-database-mariadb-server`  `azure-database-migration-services`  `azure-database-mysql-server`  `azure-database-postgresql-server-group`  `azure-database-postgresql-server`  `azure-purview-accounts`  `azure-sql-edge`  `azure-sql-server-stretch-databases`  `azure-sql-vm`  `azure-sql`  `azure-synapse-analytics`  `cache-redis`  `data-factories`  `elastic-job-agents`  `instance-pools`  `managed-database`  `oracle-database`  `sql-data-warehouses`  `sql-database`  `sql-elastic-pools`  `sql-managed-instance`  `sql-server-registries`  `sql-server`  `ssis-lift-and-shift-ir`  `virtual-clusters`

## `devops` · 18 ไอคอน

`api-connections`  `api-management-services`  `application-insights`  `artifacts`  `azure-devops`  `boards`  `change-analysis`  `cloudtest`  `code-optimization`  `devops-starter`  `devops`  `devtest-labs`  `lab-accounts`  `lab-services`  `load-testing`  `pipelines`  `repos`  `test-plans`

## `general` · 114 ไอคอน

`all-resources`  `allresources`  `azurehome`  `backlog`  `biz-talk`  `blob-block`  `blob-page`  `branch`  `browser`  `bug`  `builds`  `cache`  `code`  `commit`  `controls-horizontal`  `controls`  `cost-alerts`  `cost-analysis`  `cost-budgets`  `cost-management-and-billing`  `cost-management`  `counter`  `cubes`  `dashboard`  `dev-console`  `developertools`  `download`  `error`  `extensions`  `feature-previews`  `file`  `files`  `folder-blank`  `folder-website`  `free-services`  `ftp`  `gear`  `globe-error`  `globe-success`  `globe-warning`  `guide`  `heart`  `help-and-support`  `helpsupport`  `image`  `information`  `input-output`  `journey-hub`  `launch-portal`  `learn`  `load-test`  `location`  `log-streaming`  `management-groups`  `management-portal`  `managementgroups`  `marketplace-management`  `marketplace`  `media-file`  `media`  `mobile-engagement`  `mobile`  `module`  `power-up`  `power`  `powershell`  `preview-features`  `process-explorer`  `production-ready-database`  `quickstart-center`  `quickstartcenter`  `recent`  `region-management`  `reservations`  `resource-explorer`  `resource-group-list`  `resource-groups`  `resource-linked`  `resource`  `resourcegroups`  `scheduler`  `search-grid`  `search`  `server-farm`  `service-health`  `servicehealth`  `shareddashboard`  `ssd`  `storage-azure-files`  `storage-container`  `storage-queue`  `subscriptions`  `support`  `supportrequests`  `table`  `tag`  `tags`  `templates`  `tfs-vc-repository`  `toolbox`  `troubleshoot`  `twousericon`  `userhealthicon`  `usericon`  `userprivacy`  `userresource`  `versions`  `web-slots`  `web-test`  `website-power`  `website-staging`  `whatsnew`  `workbooks`  `workflow`

## `hybridmulticloud` · 5 ไอคอน

`azure-operator-5g-core`  `azure-operator-insights`  `azure-operator-nexus`  `azure-operator-service-manager`  `azure-programmable-connectivity`

## `identity` · 41 ไอคอน

`aad-licenses`  `access-review`  `active-directory-connect-health`  `active-directory`  `ad-b2c`  `ad-domain-services`  `ad-identity-protection`  `ad-privileged-identity-management`  `administrative-units`  `api-proxy`  `app-registrations`  `azure-active-directory`  `azure-ad-b2c`  `azure-ad-domain-services`  `azure-ad-identity-protection`  `azure-ad-privilege-identity-management`  `azure-ad-privleged-identity-management`  `azure-ad-roles-and-administrators`  `azure-information-protection`  `conditional-access`  `custom-azure-ad-roles`  `enterprise-applications`  `entra-connect`  `entra-domain-services`  `entra-id-protection`  `entra-managed-identities`  `entra-privleged-identity-management`  `entra-verified-id`  `external-identities`  `global-secure-access`  `groups`  `identity-governance`  `information-protection`  `internet-access`  `managed-identities`  `private-access`  `security`  `tenant-properties`  `user-settings`  `users`  `verifiable-credentials`

## `integration` · 34 ไอคอน

`api-connections`  `api-for-fhir`  `api-management-services`  `api-management`  `app-configuration`  `azure-api-for-fhir`  `azure-data-catalog`  `azure-databox-gateway`  `azure-service-bus`  `azure-sql-server-stretch-databases`  `azure-stack-edge`  `data-catalog`  `data-factories`  `event-grid-domains`  `event-grid-subscriptions`  `event-grid-topics`  `integration-accounts`  `integration-environments`  `integration-service-environments`  `logic-apps-custom-connector`  `logic-apps`  `partner-namespace`  `partner-registration`  `partner-topic`  `power-platform`  `relays`  `sendgrid-accounts`  `service-bus-relays`  `service-bus`  `service-catalog-managed-application-definitions`  `software-as-a-service`  `sql-data-warehouses`  `storsimple-device-managers`  `system-topic`

## `intune` · 18 ไอคอน

`azure-ad-roles-and-administrators`  `client-apps`  `device-compliance`  `device-configuration`  `device-enrollment`  `device-security-apple`  `device-security-google`  `device-security-windows`  `devices`  `ebooks`  `exchange-access`  `intune-app-protection`  `intune-for-education`  `intune`  `mindaro`  `security-baselines`  `software-updates`  `tenant-status`

## `iot` · 33 ไอคอน

`azure-cosmos-db`  `azure-databox-gateway`  `azure-iot-operations`  `azure-maps-accounts`  `azure-stack`  `device-provisioning-services`  `digital-twins`  `event-grid-subscriptions`  `event-hub-clusters`  `event-hubs`  `function-apps`  `industrial-iot`  `iot-central-applications`  `iot-edge`  `iot-hub-security`  `iot-hub`  `logic-apps`  `machine-learning-studio-classic-web-services`  `machine-learning-studio-web-service-plans`  `machine-learning-studio-workspaces`  `maps`  `notification-hub-namespaces`  `notification-hubs`  `sphere`  `stack-hci-premium`  `stream-analytics-jobs`  `time-series-data-sets`  `time-series-insights-access-policies`  `time-series-insights-environments`  `time-series-insights-event-sources`  `time-series-insights-events-sources`  `windows-10-iot-core-services`  `windows10-core-services`

## `managementgovernance` · 33 ไอคอน

`activity-log`  `advisor`  `alerts`  `application-insights`  `arc-machines`  `automation-accounts`  `azure-arc`  `azure-lighthouse`  `blueprints`  `compliance`  `cost-management-and-billing`  `customer-lockbox-for-microsoft-azure`  `diagnostics-settings`  `education`  `intune-trends`  `log-analytics-workspaces`  `machinesazurearc`  `managed-applications-center`  `managed-desktop`  `metrics`  `monitor`  `my-customers`  `operation-log-classic`  `policy`  `recovery-services-vaults`  `resource-graph-explorer`  `resources-provider`  `scheduler-job-collections`  `service-catalog-mad`  `service-providers`  `solutions`  `universal-print`  `user-privacy`

## `menu` · 1 ไอคอน

`keys`

## `migrate` · 6 ไอคอน

`azure-databox-gateway`  `azure-migrate`  `azure-stack-edge`  `cost-management-and-billing`  `data-box`  `recovery-services-vaults`

## `migration` · 6 ไอคอน

`azure-database-migration-services`  `data-box-edge`  `data-box`  `database-migration-services`  `migration-projects`  `recovery-services-vaults`

## `misc` · 1 ไอคอน

`azure`

## `mixedreality` · 2 ไอคอน

`remote-rendering`  `spatial-anchor-accounts`

## `ml` · 10 ไอคอน

`azure-open-ai`  `azure-speech-service`  `batch-ai`  `bot-services`  `cognitive-services`  `genomics-accounts`  `machine-learning-service-workspaces`  `machine-learning-studio-web-service-plans`  `machine-learning-studio-web-services`  `machine-learning-studio-workspaces`

## `mobile` · 5 ไอคอน

`app-service-mobile`  `app-services`  `mobile-engagement`  `notification-hubs`  `power-platform`

## `monitor` · 12 ไอคอน

`activity-log`  `application-insights`  `auto-scale`  `azure-monitors-for-sap-solutions`  `azure-workbooks`  `change-analysis`  `diagnostics-settings`  `log-analytics-workspaces`  `logs`  `metrics`  `monitor`  `network-watcher`

## `network` · 28 ไอคอน

`application-gateway`  `application-security-groups`  `cdn-profiles`  `connections`  `ddos-protection-plans`  `dns-private-zones`  `dns-zones`  `expressroute-circuits`  `firewall`  `front-doors`  `load-balancers`  `local-network-gateways`  `network-interfaces`  `network-security-groups-classic`  `network-watcher`  `on-premises-data-gateways`  `private-endpoint`  `public-ip-addresses`  `reserved-ip-addresses-classic`  `route-filters`  `route-tables`  `service-endpoint-policies`  `subnets`  `traffic-manager-profiles`  `virtual-network-classic`  `virtual-network-gateways`  `virtual-networks`  `virtual-wans`

## `networking` · 51 ไอคอน

`application-gateways`  `atm-multistack`  `azure-communications-gateway`  `azure-firewall-manager`  `azure-firewall-policy`  `bastions`  `cdn-profiles`  `connected-cache`  `connections`  `ddos-protection-plans`  `dns-multistack`  `dns-private-resolver`  `dns-security-policy`  `dns-zones`  `expressroute-circuits`  `firewalls`  `front-door-and-cdn-profiles`  `ip-address-manager`  `ip-groups`  `load-balancer-hub`  `load-balancers`  `local-network-gateways`  `nat`  `network-interfaces`  `network-security-groups`  `network-watcher`  `on-premises-data-gateways`  `private-link-service`  `private-link-services`  `private-link`  `proximity-placement-groups`  `public-ip-addresses-classic`  `public-ip-addresses`  `public-ip-prefixes`  `reserved-ip-addresses-classic`  `resource-management-private-link`  `route-filters`  `route-tables`  `service-endpoint-policies`  `spot-vm`  `spot-vmss`  `subnet`  `traffic-controller`  `traffic-manager-profiles`  `virtual-network-gateways`  `virtual-networks-classic`  `virtual-networks`  `virtual-router`  `virtual-wan-hub`  `virtual-wans`  `web-application-firewall-policieswaf`

## `newicons` · 7 ไอคอน

`azure-sustainability`  `connected-vehicle-platform`  `entra-connect-health`  `entra-connect-sync`  `icm-troubleshooting`  `osconfig`  `storage-actions`

## `other` · 128 ไอคอน

`aad-licenses`  `aks-istio`  `app-compliance-automation`  `app-registrations`  `aquila`  `arc-data-services`  `arc-kubernetes`  `arc-postgresql-`  `arc-sql-managed-instance`  `arc-sql-server`  `avs-vm`  `azure-a`  `azure-backup-center`  `azure-center-for-sap`  `azure-chaos-studio`  `azure-cloud-shell`  `azure-communication-services`  `azure-compute-galleries`  `azure-deployment-environments`  `azure-dev-tunnels`  `azure-edge-hardware-center`  `azure-hpc-workbenches`  `azure-load-testing`  `azure-managed-grafana`  `azure-monitor-dashboard`  `azure-network-function-manager-functions`  `azure-network-function-manager`  `azure-orbital`  `azure-quotas`  `azure-sphere`  `azure-storage-mover`  `azure-support-center-blue`  `azure-video-indexer`  `azure-virtual-desktop`  `azure-vmware-solution`  `azureattestation`  `azurite`  `backup-vault`  `bare-metal-infrastructure`  `capacity-reservation-groups`  `central-service-instance-for-sap`  `ceres`  `cloud-services-extended-support`  `community-images`  `compliance-center`  `confidential-ledgers`  `container-apps-environments`  `cost-export`  `custom-ip-prefix`  `dashboard-hub`  `data-collection-rules`  `database-instance-for-sap`  `dedicated-hsm`  `defender-cm-local-manager`  `defender-dcs-controller`  `defender-distributer-control-system`  `defender-engineering-station`  `defender-external-management`  `defender-freezer-monitor`  `defender-historian`  `defender-hmi`  `defender-industrial-packaging-system`  `defender-industrial-printer`  `defender-industrial-robot`  `defender-industrial-scale-system`  `defender-marquee`  `defender-meter`  `defender-plc`  `defender-pneumatic-device`  `defender-programable-board`  `defender-relay`  `defender-robot-controller`  `defender-rtu`  `defender-sensor`  `defender-slot`  `defender-web-guiding-system`  `device-update-iot-hub`  `disk-pool`  `edge-management`  `elastic-san`  `exchange-on-premises-access`  `express-route-traffic-collector`  `expressroute-direct`  `fhir-service`  `fiji`  `hdi-aks-cluster`  `instance-pools`  `internet-analyzer-profiles`  `kubernetes-fleet-manager`  `local-network-gateways`  `log-analytics-query-pack`  `managed-instance-apache-cassandra`  `medtech-service`  `microsoft-dev-box`  `mission-landing-zone`  `mobile-networks`  `modular-data-center`  `network-managers`  `network-security-perimeters`  `open-supply-chain-platform`  `peering-service`  `peerings`  `private-endpoints`  `reserved-capacity`  `resource-guard`  `resource-mover`  `rtos`  `savings-plans`  `scvmm-management-servers`  `sonic-dash`  `ssh-keys`  `storage-functions`  `targets-management`  `template-specs`  `test-base`  `update-management-center`  `video-analyzers`  `virtual-enclaves`  `virtual-instance-for-sap`  `virtual-visits-builder`  `vm-app-definitions`  `vm-app-versions`  `vm-image-version`  `wac`  `web-app-database`  `web-jobs`  `windows-notification-services`  `worker-container-app`

## `security` · 22 ไอคอน

`application-security-groups`  `azure-ad-authentication-methods`  `azure-ad-identity-protection`  `azure-ad-privleged-identity-management`  `azure-ad-risky-signins`  `azure-ad-risky-users`  `azure-information-protection`  `azure-sentinel`  `conditional-access`  `defender`  `detonation`  `extended-security-updates`  `extendedsecurityupdates`  `identity-secure-score`  `key-vaults`  `microsoft-defender-easm`  `microsoft-defender-for-cloud`  `microsoft-defender-for-iot`  `multifactor-authentication`  `security-center`  `sentinel`  `user-settings`

## `storage` · 26 ไอคอน

`archive-storage`  `azure-databox-gateway`  `azure-fileshares`  `azure-hcp-cache`  `azure-netapp-files`  `azure-stack-edge`  `azurefxtedgefiler`  `blob-storage`  `data-box-edge-data-box-gateway`  `data-box`  `data-lake-storage-gen1`  `data-lake-storage`  `data-share-invitations`  `data-shares`  `general-storage`  `import-export-jobs`  `netapp-files`  `queues-storage`  `recovery-services-vaults`  `storage-accounts-classic`  `storage-accounts`  `storage-explorer`  `storage-sync-services`  `storsimple-data-managers`  `storsimple-device-managers`  `table-storage`

## `web` · 20 ไอคอน

`api-center`  `api-connections`  `api-management-services`  `app-service-certificates`  `app-service-domains`  `app-service-environments`  `app-service-plans`  `app-services`  `app-space`  `azure-media-service`  `azure-spring-apps`  `cognitive-search`  `cognitive-services`  `front-door-and-cdn-profiles`  `media-services`  `notification-hub-namespaces`  `power-platform`  `search`  `signalr`  `static-apps`
