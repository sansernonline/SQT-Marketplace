# ชุดไอคอนสำหรับวาด diagram

**8,602 ไอคอน** แบ่งเป็น 5 กลุ่ม — รายละเอียดทุกกลุ่มอยู่ใน **`GROUPS.md`**

```
tech-icons/
├── GROUPS.md          ← อ่านไฟล์นี้ก่อน
├── cloud/             1,986  PNG   ผู้ให้บริการคลาวด์ 10 ราย
├── platform/            471  PNG   Kubernetes · ฐานข้อมูล · คิว · CI/CD · เฝ้าระวัง
├── brands/            3,461  SVG   โลโก้แบรนด์ + colors.json รหัสสีทางการ
├── devtools/            572  SVG   โลโก้เครื่องมือนักพัฒนา มีสีในตัว
└── ui/                2,112  SVG   ไอคอนเส้นทั่วไป ไม่ใช่โลโก้
```

ทุกโฟลเดอร์มี `INDEX.md` (รายชื่อทั้งหมด) และ `contact-sheet.html` (เปิดในเบราว์เซอร์ดูรูปทั้งหมด)

## ใช้กับ skill `diagram-figures`

```html
<div class="unit"><img src="tech-icons/cloud/aws/compute/ec2.png" alt="">
  <div class="name">Web Server</div><div class="desc">AZ-1</div></div>
```

SVG สีเดียวใน `brands/` กำหนดสีได้ด้วย CSS

```html
<img src="tech-icons/brands/docker.svg" style="filter:none">
<!-- หรือฝัง inline แล้วใส่ fill:#2496ED ตาม colors.json -->
```

## ที่มาและสัญญาอนุญาต

| กลุ่ม | ที่มา | สัญญาอนุญาต |
|---|---|---|
| `cloud/` `platform/` | mingrammer/diagrams | MIT · ไอคอนเป็นชุดสถาปัตยกรรมทางการของผู้ให้บริการแต่ละราย |
| `brands/` | Simple Icons | CC0 (สาธารณสมบัติ) · ตัวโลโก้ยังเป็นเครื่องหมายการค้าของเจ้าของ |
| `devtools/` | Devicon | MIT |
| `ui/` | Lucide | ISC |

**ทำได้** — ใช้ในผังสถาปัตยกรรม เอกสารข้อเสนอ สไลด์นำเสนอ เอกสารทางเทคนิค

**ทำไม่ได้** — ใช้ในลักษณะที่ทำให้เข้าใจว่าเจ้าของแบรนด์รับรองหรือร่วมงานด้วย ·
ดัดแปลงรูปทรงโลโก้ · ใช้เป็นส่วนหนึ่งของแบรนด์ตัวเอง

ไฟล์ PNG ถูกย่อจาก 300×300 เหลือ 160×160 และลดจำนวนสีเหลือ 192 สี เพื่อให้ขนาดรวมเล็กลง

## ตัวย่อ

- **PNG** — Portable Network Graphics
- **SVG** — Scalable Vector Graphics
- **MIT** — Massachusetts Institute of Technology License
- **CC0** — Creative Commons Zero
- **ISC** — Internet Systems Consortium License
