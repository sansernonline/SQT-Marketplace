---
name: config-and-secrets
description: Use when a project needs settings that differ between environments, or handles anything that must not be committed — connection strings, API keys, signing keys, certificates. Separates configuration from secrets, sets the precedence order, validates every setting at start-up so a missing value fails immediately instead of at 2 AM, names environment variables consistently, picks a secret store that matches the team size, makes rotation possible, and gives the order of steps for a leaked credential. Also covers why nothing in a frontend build is ever secret.
---

# Config และ Secret

> **กฎสองข้อ:**
> 1. โค้ดชุดเดียวกันต้องรันได้ทุก environment — ความต่างอยู่ที่ config เท่านั้น
> 2. secret ไม่เคยอยู่ใน git · ไม่เคยอยู่ใน log · ไม่เคยอยู่ในไฟล์ที่ส่งไปให้เบราว์เซอร์

## เมื่อไหร่ใช้ skill นี้

- เริ่มโปรเจกต์ หรือเพิ่ม environment ใหม่
- ต้องเก็บ connection string, API key, ใบรับรอง, กุญแจสำหรับเซ็น
- เจอค่าคงที่ฝังอยู่ในโค้ด (hardcode) แล้วต้องย้ายออก
- secret หลุดเข้า git หรือสงสัยว่าหลุด → ข้อ 8 ทันที

## เมื่อไหร่ **ไม่** ใช้

| โจทย์ | ไปที่ |
|---|---|
| เก็บ secret ใน pipeline · ด่านอนุมัติ | `cicd-and-release` |
| ออกแบบ login, token, สิทธิ์ผู้ใช้ | `auth-implementation-patterns` |
| กันไม่ให้ค่าอ่อนไหวโผล่ใน log | `logging-standards` |

---

## 1 · แยก config กับ secret ให้ออกก่อน

| | config | secret |
|---|---|---|
| ตัวอย่าง | ที่อยู่ API, ระดับ log, จำนวนต่อหน้า, โซนเวลา, feature flag | รหัสผ่านฐานข้อมูล, API key, กุญแจเซ็น token, ใบรับรอง |
| อยู่ใน git ได้ | ✅ ได้ | ❌ ไม่ได้เด็ดขาด |
| ใครเห็นได้ | ทั้งทีม | เฉพาะที่จำเป็น |
| หลุดแล้วเป็นไร | ไม่เป็นไร | ต้องเพิกถอนและเปลี่ยนทันที |
| เปลี่ยนบ่อย | ตามงาน | ตามรอบหมุนเวียน |

> **ถ้าตัดสินใจไม่ได้ว่าอันไหน ให้ถือว่าเป็น secret** — ต้นทุนของการระวังเกินไปคือความรำคาญเล็กน้อย
> ต้นทุนของการเดาผิดคือการที่กุญแจอยู่ในประวัติ git ตลอดไป

---

## 2 · ลำดับความสำคัญ — ค่าหลังทับค่าก่อน

```
1. ค่าเริ่มต้นในโค้ด        (ปลอดภัย ใช้ได้จริงสำหรับ dev)
2. ไฟล์ config ตาม environment  (appsettings.Production.json, config/production.yaml)
3. ตัวแปรสภาพแวดล้อม        (environment variable)
4. secret store              (Key Vault, Secrets Manager, Kubernetes secret)
5. อาร์กิวเมนต์ตอนสั่งรัน     (ใช้ตอนไล่ปัญหาเท่านั้น)
```

**ค่าเริ่มต้นต้องปลอดภัย** — ถ้าลืมตั้งค่า ระบบต้องทำงานในแบบที่เข้มงวดที่สุด
`DEBUG=false` · `ALLOWED_ORIGINS=` ว่าง · เปิด TLS ไม่ใช่ตรงกันข้าม

---

## 3 · ตรวจตอนบูต — ขาดค่าไหนให้ตายทันที

> 🚨 นี่คือข้อที่ให้ผลตอบแทนสูงที่สุดในหน้านี้
> ระบบที่บูตขึ้นมาได้ทั้งที่ config ผิด จะไปพังตอนตีสองที่ฟังก์ชันซึ่งนาน ๆ ใช้ที
> ระบบที่ **ไม่ยอมบูต** เมื่อ config ผิด ทำให้รู้ตอน deploy ซึ่งยัง rollback ได้

```ts
// Node — zod
const Env = z.object({
  NODE_ENV:      z.enum(['development', 'staging', 'production']),
  PORT:          z.coerce.number().int().positive().default(3000),
  DATABASE_URL:  z.string().url(),
  JWT_SECRET:    z.string().min(32),
  LOG_LEVEL:     z.enum(['debug','info','warn','error']).default('info'),
});

export const env = Env.parse(process.env);   // ผิด = process ตายพร้อมบอกว่าตัวไหนผิด
```

**สิ่งที่ต้องตรวจ:** มีค่าครบ · ชนิดถูก · อยู่ในช่วงที่ยอมรับ ·
กุญแจยาวพอ · ค่าที่ห้ามใช้บน production (`JWT_SECRET=dev-secret` ต้องไม่ผ่าน)

**พิมพ์สรุป config ตอนบูต** — ชื่อค่าและค่าที่ไม่ใช่ secret
ส่วน secret ให้พิมพ์แค่ว่า "มีค่าแล้ว" หรือสี่ตัวท้าย ไม่ใช่ค่าเต็ม

---

## 4 · ตั้งชื่อตัวแปรสภาพแวดล้อม

```
<ระบบ>_<กลุ่ม>_<ชื่อ>

APP_DB_HOST          APP_DB_PASSWORD
APP_REDIS_URL        APP_SMTP_PASSWORD
APP_FEATURE_NEW_CHECKOUT
```

| กฎ | เหตุผล |
|---|---|
| ตัวพิมพ์ใหญ่ ขีดล่าง | ข้อตกลงของทุกระบบปฏิบัติการ |
| มีคำนำหน้าของระบบ | กัน `PATH`, `HOME`, `USER` ของระบบชนกัน |
| ชื่อเดียวกันทุก environment | ค่าต่างได้ ชื่อห้ามต่าง ไม่งั้นย้าย environment ทีต้องแก้โค้ด |
| ใส่หน่วยในชื่อ | `APP_TIMEOUT_SECONDS` ไม่ใช่ `APP_TIMEOUT` |
| อย่าใส่ชื่อ environment ในชื่อตัวแปร | ❌ `APP_PROD_DB_HOST` |

---

## 5 · `.env` และ `.env.example`

| ไฟล์ | อยู่ใน git | หน้าที่ |
|---|:--:|---|
| `.env.example` | ✅ | รายชื่อค่าที่ต้องมี **ทั้งหมด** พร้อมคำอธิบาย และค่าตัวอย่างที่ไม่ใช่ของจริง |
| `.env` | ❌ | ค่าจริงบนเครื่องนักพัฒนาแต่ละคน |
| `.env.production` | ❌ | **ไม่ควรมีไฟล์นี้เลย** — production ใช้ secret store |

```bash
# .gitignore
.env
.env.*
!.env.example
```

```bash
# .env.example
APP_DB_HOST=localhost              # ที่อยู่ฐานข้อมูล
APP_DB_PASSWORD=change-me          # ❗ ค่าจริงอยู่ใน 1Password ห้องทีม
APP_JWT_SECRET=                    # ❗ สร้างด้วย: openssl rand -base64 48
APP_LOG_LEVEL=debug
```

**`.env.example` ต้องอัปเดตในคอมมิตเดียวกับที่เพิ่มค่าใหม่**
ไม่งั้นคนถัดไปที่ clone จะเจอ error ที่ไม่มีใครอธิบายได้

> 🚨 **`.env` ที่ `.gitignore` ไม่ทัน** — ถ้าไฟล์ถูก track ไปแล้วครั้งหนึ่ง
> การเพิ่มใน `.gitignore` ทีหลัง**ไม่ลบมันออกจากประวัติ** ต้อง `git rm --cached` และถือว่า secret หลุดแล้ว

---

## 6 · เก็บ secret ไว้ที่ไหน

| สถานการณ์ | ใช้ | หมายเหตุ |
|---|---|---|
| เครื่องนักพัฒนา | `.env` ที่ไม่เข้า git · .NET ใช้ `dotnet user-secrets` | ห้ามใช้ค่าของ production |
| ทีมเล็ก แชร์กัน | ตัวจัดการรหัสผ่านของทีม (1Password, Bitwarden) | ไม่ใช่แชต ไม่ใช่อีเมล ไม่ใช่ Google Sheet |
| production บนคลาวด์ | Azure Key Vault · AWS Secrets Manager · Google Secret Manager | ให้สิทธิ์ด้วย managed identity ไม่ใช่ key อีกอัน |
| Kubernetes | External Secrets Operator ดึงจาก vault ข้างบน | secret ของ Kubernetes เองเป็นแค่ base64 **ไม่ใช่การเข้ารหัส** |
| ต้องเก็บใน git จริง ๆ | SOPS หรือ sealed-secrets (เข้ารหัสก่อน commit) | ทางเลือกสุดท้าย |

**สิทธิ์:** แต่ละ service อ่านได้เฉพาะ secret ของตัวเอง · environment แยกกันสนิท ·
ไม่มีบัญชีไหนอ่านได้ทุกอัน นอกจากบัญชีดูแลระบบที่มีการบันทึกการเข้าถึง

---

## 7 · การหมุนเวียน (rotation)

**ออกแบบให้รองรับตั้งแต่วันแรก** — ไม่ใช่ตอนที่ต้องหมุนจริง

| ต้องมี | รายละเอียด |
|---|---|
| ใช้สองค่าพร้อมกันได้ | ระหว่างเปลี่ยน ทั้งค่าเก่าและใหม่ต้องใช้ได้ ไม่งั้นต้องปิดระบบ |
| โหลดใหม่โดยไม่ต้อง restart | หรือยอมรับว่าต้อง deploy รอบหนึ่ง และเขียนไว้ว่าต้องทำ |
| รอบเวลา | กุญแจเซ็น token 90 วัน · รหัสฐานข้อมูล 180 วัน · ใบรับรองก่อนหมดอายุ 30 วัน |
| ทำอัตโนมัติ | งานที่ต้องจำเองคืองานที่ไม่มีใครทำ |

**กุญแจสำหรับเซ็น token ต้องมี id กำกับ (key id)** เพื่อให้ตรวจ token เก่าที่ยังไม่หมดอายุได้
ระหว่างที่ token ใหม่เซ็นด้วยกุญแจใหม่แล้ว

---

## 8 · เมื่อ secret หลุด — ลำดับสำคัญกว่าความเร็ว

1. **เพิกถอนค่าเดิมก่อน** — ปิดการใช้งาน key นั้นที่ต้นทาง
2. ออกค่าใหม่ แล้ว deploy
3. ตรวจ log ย้อนหลังว่ามีการใช้จากที่ไหนที่ไม่ใช่ของเรา
4. ลบออกจากประวัติ git (`git filter-repo`) และแจ้งทุกคนให้ clone ใหม่
5. บันทึกเหตุการณ์ → `postmortem-template`

> 🚨 **ข้อ 4 ไม่ใช่ข้อ 1** — การลบ commit ไม่ได้ทำให้กุญแจปลอดภัยขึ้นเลย
> ใครก็ตามที่ fork หรือ clone ไปแล้ว รวมถึงตัวสำรองของผู้ให้บริการ ยังมีค่าเดิมอยู่
> **ถือว่าทุก secret ที่เคยเข้า git คือหลุดแล้ว** แม้ repo จะเป็น private

---

## 9 · อย่าให้ secret ไหลออกทางอื่น

| ทางรั่ว | วิธีปิด |
|---|---|
| log | รายการคำที่ต้องปิดบัง → `logging-standards` |
| ข้อความ error ที่ส่งให้ client | คืนเฉพาะ `traceId` ไม่ใช่ stack trace หรือ connection string |
| รายงาน crash / ตัวติดตามข้อผิดพลาด | ตั้งตัวกรองข้อมูลอ่อนไหวก่อนส่งออก |
| ประวัติคำสั่งใน shell | ใช้ `read -s` หรืออ่านจากไฟล์ แทนการพิมพ์ค่าลงบรรทัดคำสั่ง |
| `docker history` | อย่าใส่ secret ใน `ARG`/`ENV` ตอน build — ใช้ mount ตอนรัน |
| ไฟล์สำรองข้อมูลและ dump | เข้ารหัส และเก็บที่ที่คุมสิทธิ์ได้ |
| ภาพหน้าจอในเอกสารและ issue | ปิดบังก่อนแนบเสมอ |

---

## 10 · config ของ frontend — ไม่มีอะไรลับ

> 🚨 ทุกอย่างที่อยู่ในไฟล์ที่เบราว์เซอร์โหลด **คือข้อมูลสาธารณะ**
> ไม่ว่าจะชื่อว่า `VITE_SECRET_KEY` หรืออยู่ในไฟล์ที่ถูกย่อจนอ่านไม่ออกก็ตาม
> การย่อโค้ดไม่ใช่การเข้ารหัส เปิด DevTools ก็เห็น

| ใส่ใน frontend ได้ | ต้องอยู่ฝั่งเซิร์ฟเวอร์เท่านั้น |
|---|---|
| ที่อยู่ API · ชื่อ environment | API key ของบริการภายนอกทุกชนิด |
| กุญแจสาธารณะ (publishable key) ของผู้ให้บริการชำระเงิน | กุญแจลับ (secret key) ของผู้ให้บริการเดียวกัน |
| feature flag ที่ไม่ลับ | กฎการคิดราคา · เกณฑ์อนุมัติ |
| รหัสเว็บของตัววัดสถิติ | token ที่เรียก API ของบุคคลที่สาม |

**ต้องการเปลี่ยนค่าโดยไม่ build ใหม่** — ให้โหลด `/config.json` ตอนแอปเริ่มทำงาน
แทนการฝังค่าตอน build (`import.meta.env`) ซึ่งล็อกค่าติดไปกับไฟล์ที่ได้

---

## 11 · Anti-patterns

- ❌ **connection string ในโค้ด** แม้จะเป็นของ dev — วันหนึ่งจะมีคนคัดลอกแบบแผนนี้ไปใช้กับ production
- ❌ **`.env` ของ production วางไว้บนเซิร์ฟเวอร์** — ใครเข้าเครื่องได้ก็อ่านได้ ไม่มีบันทึกว่าใครอ่าน
- ❌ **secret เดียวกันทุก environment** — staging หลุดเท่ากับ production หลุด
- ❌ **ส่ง secret ทางแชตหรืออีเมล** — อยู่ในนั้นตลอดไป และค้นเจอด้วย
- ❌ **ไม่มี `.env.example`** — คนใหม่เสียเวลาครึ่งวันเดาว่าต้องมีค่าอะไรบ้าง
- ❌ **บูตผ่านทั้งที่ config ไม่ครบ** แล้วไปพังตอนใช้งานจริง
- ❌ **พิมพ์ config ทั้งก้อนลง log ตอนบูต** รวม secret
- ❌ **`ALLOWED_ORIGINS=*` บน production** เพราะ "ตอน dev มันติด CORS"
- ❌ **กุญแจที่ไม่เคยเปลี่ยนเลยตั้งแต่ปีแรก**

---

## 12 · ตัวย่อ

- **config** — configuration (ค่าตั้งที่ต่างกันได้ตามสภาพแวดล้อม)
- **secret** — ค่าอ่อนไหวที่ห้ามเปิดเผย เช่น รหัสผ่านหรือกุญแจ
- **environment variable** — ตัวแปรสภาพแวดล้อม ค่าที่ระบบปฏิบัติการส่งให้โปรแกรมตอนรัน
- **vault** — ที่เก็บ secret ที่เข้ารหัสและคุมสิทธิ์ได้
- **rotation** — การหมุนเวียนเปลี่ยนกุญแจตามรอบเวลา
- **TLS** — Transport Layer Security (การเข้ารหัสระหว่างทางของ HTTPS)
- **CORS** — Cross-Origin Resource Sharing (กฎที่เบราว์เซอร์ใช้ตัดสินว่าเว็บหนึ่งเรียก API ของอีกที่ได้ไหม)

## 13 · เชื่อมกับ skill อื่น

| ต้องการ | ใช้คู่กับ |
|---|---|
| secret ในขั้นตอน build และ deploy | `cicd-and-release` |
| ปิดบังค่าอ่อนไหวใน log | `logging-standards` |
| กุญแจเซ็น token · อายุ session | `auth-implementation-patterns` |
| connection string ของฐานข้อมูล | `database-design` |
| บันทึกเหตุการณ์หลัง secret หลุด | `postmortem-template` |
| ขั้นตอนตอนเกิดเหตุ | `incident-runbook-template` |

**วิธีทำจริงในแต่ละภาษาและเฟรมเวิร์ก** → `references/per-stack.md`
