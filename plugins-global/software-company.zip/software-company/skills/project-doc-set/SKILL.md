---
name: project-doc-set
description: Use when a new project needs its document set decided — which documents to write, in what order, who reads each one, and where docs, assets, mockups and qa sit beside the code. Scales the set to project size so a two-week job does not get a twelve-document package.
---

# ชุดเอกสารโปรเจกต์

> **กฎข้อเดียว:** เอกสารทุกชิ้นต้องตอบได้ว่า **ใครอ่าน** และ **อ่านแล้วตัดสินใจอะไร**
> ตอบไม่ได้ = ไม่ต้องเขียน

---

## เมื่อไหร่ใช้ skill นี้

- เปิดโปรเจกต์ใหม่ แล้วต้องตัดสินว่าจะมีเอกสารอะไรบ้าง
- โปรเจกต์เดิมมีเอกสารกระจัดกระจาย ไม่รู้ว่าอันไหนเป็นตัวจริง
- ลูกค้าถามว่า "ส่งมอบเอกสารอะไรบ้าง"
- จะเริ่มเขียนเอกสารสักชิ้น แต่ไม่แน่ใจว่าต้องมีอะไรมาก่อน

## เมื่อไหร่ **ไม่** ใช้

| สถานการณ์ | ใช้แทน |
|---|---|
| โครงโฟลเดอร์ของ**โค้ด** · README · CHANGELOG · linter | `project-bootstrap` |
| ตั้ง**ชื่อไฟล์** และเลขเวอร์ชันของเอกสาร | `document-naming` |
| ลงมือเขียนเอกสารชิ้นใดชิ้นหนึ่ง | skill ของเอกสารนั้น (ตารางข้อ 4) |
| จัดรูปแบบหน้าเอกสารให้สวย | `branded-document-design` |

---

## 1 · โครงโฟลเดอร์ระดับโปรเจกต์

**เอกสารอยู่นอก repo โค้ด** — คนละวงจรชีวิต คนละคนแก้ คนละรอบส่งมอบ

```
<ชื่อโปรเจกต์>/
├─ docs/                เอกสารที่คนอ่าน
│  ├─ figures/          รูปที่ export แล้ว — .png เท่านั้น
│  │  └─ src/           ไฟล์ต้นทางของรูป (.html · .mmd · .drawio)
│  └─ decisions/        ADR — ทำไมถึงเลือกทางนี้
├─ assets/
│  └─ brand/            โลโก้ · ไอคอน · ค่าสีแบรนด์
├─ mockups/             .html ที่เปิดแล้วกดได้จริง
├─ qa/                  test case · ผลการทดสอบ
├─ _to_delete/          ของชั่วคราวทุกอย่าง
└─ <repo>/              โค้ด — โครงข้างในดู `project-bootstrap`
```

**กฎของโฟลเดอร์:**

- **`docs/figures/src/` ห้ามหาย** — ปีหน้าต้องแก้รูป ถ้าเหลือแต่ PNG คือวาดใหม่ทั้งใบ
- **`mockups/` ทุกปุ่มต้องกดได้จริง** ปุ่มหลอกทำให้รีวิวผิด
- **ไฟล์ `.docx`/`.xlsx` อยู่ใน `docs/` และ `qa/` เท่านั้น** ไม่กระจายไปรากโปรเจกต์
- **ของชั่วคราวลง `_to_delete/`** ไม่ทิ้งไว้ปนกับของจริง

---

## 2 · เลือกชุดเอกสารตามขนาดงาน

ขนาดวัดจาก **ระยะเวลา × จำนวนคนที่ต้องเห็นพ้องกัน** ไม่ใช่จำนวนบรรทัดโค้ด

| ขนาด | ความหมาย |
|---|---|
| **S** | ≤ 2 สัปดาห์ · ทีมเดียว · ไม่มีใครนอกทีมต้องเซ็น |
| **M** | 1–3 เดือน · มีผู้ว่าจ้างภายใน · ส่งมอบเป็นรอบ |
| **L** | > 3 เดือน · ลูกค้าภายนอกเซ็นรับ · มีข้อผูกพันตามสัญญา |

| เอกสาร | รูปแบบ | ผู้อ่าน | S | M | L |
|---|---|---|:-:|:-:|:-:|
| README | `.md` ใน repo | คนที่ต้องรันโค้ด | ● | ● | ● |
| ADR | `.md` ใน `docs/decisions/` | dev รุ่นถัดไป | ● | ● | ● |
| Project Plan | `.docx` | ผู้ว่าจ้าง · ทีม | ○ | ● | ● |
| Architecture | `.docx` | dev · ops | ○ | ● | ● |
| SRS | `.docx` | dev · ผู้ว่าจ้าง | ○ | ● | ● |
| Test Plan | `.docx` | QA · ผู้ว่าจ้าง | ○ | ● | ● |
| Test Cases | `.xlsx` | QA | ○ | ● | ● |
| User Guide | `.docx` → `.pdf` | ผู้ใช้ปลายทาง | ○ | ● | ● |
| Runbook | `.md` ใน repo | ops · คนอยู่เวร | ○ | ● | ● |
| BRD | `.docx` | ฝ่ายธุรกิจ | ○ | ○ | ● |
| FSD | `.docx` | dev · QA | ○ | ○ | ● |
| Document Checklist | `.docx` | ทุกฝ่าย | ○ | ○ | ● |

● ต้องมี · ○ ไม่ต้อง เว้นแต่มีเหตุผลเฉพาะ

> **ชุด S มีแค่สองชิ้น** และนั่นถูกแล้ว — งานสองสัปดาห์ที่มาพร้อม BRD คือเอกสารที่เขียนให้ตัวเองอ่าน

---

## 3 · ลำดับการเขียน

```
README ─► Project Plan ─► BRD ─► SRS ─┬─► mockups
                                      └─► Architecture ─► ADR ─► FSD
                                                                  │
                        User Guide ◄─ Test Cases ◄─ Test Plan ◄───┘
```

**ห้ามเขียนชิ้นถัดไปก่อนชิ้นก่อนหน้าได้รับการยืนยัน** — เขียนล่วงหน้าแล้วต้องรื้อทั้งสาย

ข้อยกเว้นเดียว: **mockups ทำคู่ไปกับ SRS ได้** เพราะภาพหน้าจอคือตัวช่วยให้ SRS ถูกยืนยันเร็วขึ้น

---

## 4 · ใครเขียนชิ้นไหน ด้วย skill อะไร

| เอกสาร | agent | skill ที่ใช้ |
|---|---|---|
| README · CHANGELOG | `technical-writer` | `project-bootstrap` |
| Project Plan | `project-manager` | `branded-document-design` |
| BRD · user story | `business-analyst` | `user-story-writer` |
| SRS | `system-analyst` | `srs-writing` |
| FSD | `system-analyst` | `fsd-writing` |
| Architecture | `solution-architect` | `architecture-patterns` · `diagram-figures` |
| ADR | `solution-architect` | `adr-writer` |
| Test Plan · Test Cases | `qa-tester` | `test-case-template` |
| mockups | `ux-designer` | `web-app-design` · `ui-craft` |
| User Guide | `technical-writer` | `polished-document-style` |
| Runbook | `devops-engineer` | `incident-runbook-template` |

---

## 5 · รูปในเอกสาร — เลือกให้ถูกตั้งแต่ต้น

| รูปนี้ใครเห็น | วาดด้วย | เก็บที่ |
|---|---|---|
| อยู่ใน README · PR · เอกสารในทีม | Mermaid (`software-diagrams`) | ฝังในไฟล์ `.md` |
| อยู่ในเอกสารที่ลูกค้าเซ็น · สไลด์ · งานพิมพ์ | `diagram-figures` | `docs/figures/` + ต้นทางใน `src/` |

> **รูป Mermaid ค่าเริ่มต้นห้ามเข้าเอกสารส่งมอบ** — สีที่สุ่มตามชนิด node ไม่ได้แปลว่าอะไร
> ตัวหนังสือภาษาไทยล้นกรอบ และย่อลงหน้า A4 แล้วอ่านไม่ออก

**หัวรูปทุกใบต้องมีครบห้าอย่าง** — ชื่อ · คำขยายหนึ่งบรรทัด · เลขรูป · เวอร์ชันกับวันที่ · เจ้าของ
รูปสถาปัตยกรรมถูกก๊อปไปวางในอีเมลและสไลด์แล้วอยู่ต่ออีกเป็นปี **รูปที่ไม่มีวันที่ ไม่มีใครกล้าแก้**

---

## 6 · ธีมสีของชุดเอกสาร

ประกาศครั้งเดียวต่อโปรเจกต์ บนหัวไฟล์ต้นทางของทุกเอกสาร:

```markdown
<!-- doc-theme: accent=#5B4BE8 -->
```

`branded-document-design` · `presentation-design` · `diagram-figures` · `svg-diagram-system`
อ่านค่านี้แทนการเลือกสีเอง — เอกสาร สไลด์ และรูปทุกใบจึงเป็นชุดเดียวกัน

**สีมาจากเนื้องาน ไม่ใช่จากรสนิยม** — มีสีแบรนด์แล้วใช้สีแบรนด์ · ยังไม่มีให้เสนอโทนแล้วรอยืนยัน
ข้อยกเว้นที่ไม่เปลี่ยนตามธีม: สีโลโก้ผู้ให้บริการ · เทาโครงสร้าง · เขียวผ่าน/แดงไม่ผ่าน

---

## 7 · รายการตรวจก่อนส่งมอบชุดเอกสาร

- [ ] ทุกไฟล์ `.docx` เปิด Navigation Pane แล้ว**เห็นหัวข้อครบ** (ใช้ Heading style จริง ไม่ใช่ตัวหนา)
- [ ] ทุกเอกสารมีหน้าประวัติการแก้ไข · เลขเวอร์ชัน · วันที่ · ผู้จัดทำ
- [ ] ทุกรูปมีเลขรูปและถูกอ้างในเนื้อความอย่างน้อยหนึ่งครั้ง
- [ ] ไฟล์ต้นทางของทุกรูปอยู่ใน `docs/figures/src/`
- [ ] ตัวย่อทุกตัวกางเต็มครั้งแรกที่ปรากฏ
- [ ] ชื่อไฟล์ตรงตาม `document-naming` — ไม่มี `final2` ไม่มี `ล่าสุด`
- [ ] เอกสารในชุดอ้างเวอร์ชันของกันและกันตรงกัน
- [ ] `_to_delete/` ว่าง หรือถูกลบไปแล้ว

---

## 8 · Anti-patterns

- ❌ **เขียน BRD ให้งานสองสัปดาห์** — ข้อ 2
- ❌ **เอกสาร `.docx` ที่ไม่มี Heading style สักอัน** — navigation pane ว่าง หา TOC ไม่ได้ ไม่มีลำดับชั้น
- ❌ **เก็บแต่ PNG ไม่เก็บไฟล์ต้นทาง** — ข้อ 1
- ❌ **เอาเอกสารไปปนใน repo โค้ด** เพราะ "จะได้อยู่ที่เดียว" — แล้ว pull request จะเต็มไปด้วย binary
- ❌ **เขียน FSD ก่อน SRS ได้รับการยืนยัน**
- ❌ **มี mockup ที่ปุ่มกดไม่ได้** — ผู้รีวิวเข้าใจว่าทำได้แล้ว
- ❌ **เอกสารชิ้นเดียวตอบทุกคำถาม** — SRS ที่มีทั้ง timeline ทั้ง test case คือเอกสารที่ไม่มีใครอ่านจบ

---

## 9 · ตัวย่อ

- **ADR** — Architecture Decision Record
- **BRD** — Business Requirements Document
- **FSD** — Functional Specification Document
- **QA** — Quality Assurance
- **SRS** — Software Requirements Specification
- **TOC** — Table of Contents

---

## 10 · เชื่อมกับ skill อื่น

| ต้องการ | ใช้คู่กับ |
|---|---|
| โครงโฟลเดอร์ของโค้ดและ README | `project-bootstrap` |
| ตั้งชื่อไฟล์และจัดเวอร์ชัน | `document-naming` |
| จัดรูปแบบหน้าเอกสาร | `branded-document-design` · `polished-document-style` |
| วาดรูปให้ดูออกแบบมา | `diagram-figures` |
| เลือกว่าจะวาดรูปด้วยอะไร | `software-diagrams` |
| รายการตรวจฉบับพิมพ์ | `assets/doc-set-checklist.md` |
